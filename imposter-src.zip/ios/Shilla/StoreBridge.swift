import Foundation
import StoreKit

/// «شلّة بلس» عن طريق App Store (StoreKit 2) — نفس ردود نسخة أندرويد (BillingBridge.java):
///   offerings → { ok, available, plans: [{ id: "weekly"|"yearly"|"lifetime", price }] }
///   purchase  → { ok } أو { ok:false, reason, message }
///   restore   → { ok, entitled }   (silent: true = من غير ما نطلب تسجيل دخول Apple)
/// المنتجات: plus_weekly و plus_yearly (اشتراكات في جروب واحد) و plus_lifetime (Non-Consumable).
@MainActor
final class StoreBridge {
    static let ids = ["imposter_plus_weekly", "imposter_plus_yearly", "imposter_plus_lifetime"]

    var onEntitlement: ((Bool) -> Void)?
    private var products: [String: Product] = [:]
    private var updatesTask: Task<Void, Never>?
    private var buying = false

    /// بنسمع لأي عملية شراء أو تجديد أو إلغاء بتحصل برا التطبيق (أو اتأخرت)
    func start() {
        updatesTask = Task { [weak self] in
            for await update in Transaction.updates {
                if case .verified(let transaction) = update {
                    await transaction.finish()
                }
                await self?.refreshEntitlement(notify: true)
            }
        }
    }

    func handle(action: String, payload: String, completion: @escaping ([String: Any]) -> Void) {
        let args = (try? JSONSerialization.jsonObject(with: Data(payload.utf8))) as? [String: Any] ?? [:]
        Task { [weak self] in
            guard let self = self else { return }
            let result: [String: Any]
            switch action {
            case "offerings":
                result = await self.offerings()
            case "purchase":
                result = await self.purchase(plan: args["planId"] as? String ?? "")
            case "restore":
                let silent = (args["silent"] as? Bool) ?? false
                result = await self.restore(sync: !silent)
            default:
                result = StoreBridge.fail("bad_action", "حصلت مشكلة، جرّب تاني")
            }
            DispatchQueue.main.async { completion(result) }
        }
    }

    private func loadProducts() async -> [String: Product] {
        if products.count == StoreBridge.ids.count { return products }
        if let list = try? await Product.products(for: StoreBridge.ids) {
            for p in list { products[p.id] = p }
        }
        return products
    }

    private func offerings() async -> [String: Any] {
        let found = await loadProducts()
        var plans: [[String: Any]] = []
        for id in StoreBridge.ids {
            if let p = found[id] {
                plans.append(["id": StoreBridge.planName(id), "price": p.displayPrice])
            }
        }
        return ["ok": true, "available": !plans.isEmpty, "plans": plans]
    }

    private func purchase(plan: String) async -> [String: Any] {
        let id = "imposter_plus_" + plan
        guard StoreBridge.ids.contains(id) else { return StoreBridge.fail("bad_plan", "اختار خطة الأول") }
        if buying { return StoreBridge.fail("busy", "فيه عملية شراء شغالة بالفعل") }
        let found = await loadProducts()
        guard let product = found[id] else { return StoreBridge.fail("unavailable", "الخطة دي مش متاحة دلوقتي") }

        buying = true
        defer { buying = false }
        do {
            let result = try await product.purchase()
            switch result {
            case .success(let verification):
                guard case .verified(let transaction) = verification else {
                    return StoreBridge.fail("error", "الشراء ماتمّش، جرّب تاني")
                }
                await transaction.finish()
                await refreshEntitlement(notify: false)
                return ["ok": true, "entitled": true]
            case .userCancelled:
                return StoreBridge.fail("cancel", "اتلغى الشراء")
            case .pending:
                return StoreBridge.fail("pending", "الدفع لسه بيتأكد… «بلس» هيتفعّل أول ما يخلص")
            @unknown default:
                return StoreBridge.fail("error", "الشراء ماتمّش، جرّب تاني")
            }
        } catch {
            return StoreBridge.fail("error", "الشراء ماتمّش، جرّب تاني")
        }
    }

    private func restore(sync: Bool) async -> [String: Any] {
        var syncFailed = false
        if sync {
            do {
                try await AppStore.sync()
            } catch {
                syncFailed = true
            }
        }
        let on = await refreshEntitlement(notify: false)
        if syncFailed && !on {
            return StoreBridge.fail("error", "مقدرناش نوصل لمشترياتك دلوقتي")
        }
        return ["ok": true, "entitled": on]
    }

    @discardableResult
    private func refreshEntitlement(notify: Bool) async -> Bool {
        var on = false
        for await entitlement in Transaction.currentEntitlements {
            guard case .verified(let t) = entitlement, StoreBridge.ids.contains(t.productID) else { continue }
            if t.revocationDate != nil { continue }
            if let expires = t.expirationDate, expires < Date() { continue }
            on = true
        }
        if notify {
            let callback = onEntitlement
            let value = on
            DispatchQueue.main.async { callback?(value) }
        }
        return on
    }

    static func planName(_ productId: String) -> String {
        productId.replacingOccurrences(of: "imposter_plus_", with: "")
    }

    static func fail(_ reason: String, _ message: String) -> [String: Any] {
        ["ok": false, "reason": reason, "message": message]
    }
}
