import { useEffect, useMemo, useReducer } from 'react'
import { useApp, FREE_PLAYER_LIMIT } from '../../state/app.jsx'
import { useNav, useExitGuard } from '../../state/nav.jsx'
import { Screen, Section, Segmented, PassPrompt, Progress, TimerRing, useCountdown, Chip } from '../../components/ui.jsx'
import { IconLock, IconShuffle, IconEye, IconUsers, IconForward } from '../../components/Icons.jsx'
import { CATEGORIES } from '../../content/categories.js'
import { RANDOM, makeRound, makePairs, tallyVotes, caughtMap, scoreRound } from './logic.js'
import { ar, joinNames } from '../../lib/format.js'
import { load, save } from '../../lib/storage.js'
import { sfx } from '../../lib/sfx.js'
import { adBetweenRounds } from '../../lib/ads.js'
import { buzz, keepAwake } from '../../lib/device.js'

const DEFAULT_CONFIG = { outsiders: 1, cats: [RANDOM], timer: 0 }
const MIN_PLAYERS = 3

const fresh = {
  revealIdx: 0,
  revealOpen: false,
  pairIdx: 0,
  qRound: 1,
  voteIdx: 0,
  voteOpen: false,
  voteSel: null,
  votes: {},
  tally: {},
  caught: {},
  guessIdx: 0,
  guessPick: null,
  guesses: {},
  deltas: {},
}

function init() {
  return {
    phase: 'setup',
    config: { ...DEFAULT_CONFIG, ...load('outsider.config', {}) },
    players: [],
    round: null,
    scores: {},
    used: {},
    roundNo: 0,
  }
}

function reducer(state, a) {
  const r = state.round
  switch (a.type) {
    case 'config':
      return { ...state, config: { ...state.config, ...a.patch } }
    case 'start': {
      const { round, used } = makeRound({ players: a.players, config: state.config, plus: a.plus, used: state.used, roundNo: state.roundNo })
      const scores = a.keepScores ? state.scores : Object.fromEntries(a.players.map((p) => [p.id, 0]))
      return { ...state, phase: 'reveal', players: a.players, round: { ...round, ...fresh }, used, roundNo: state.roundNo + 1, scores }
    }
    case 'reveal_open':
      return { ...state, round: { ...r, revealOpen: true } }
    case 'reveal_next':
      if (r.revealIdx + 1 < r.order.length) return { ...state, round: { ...r, revealIdx: r.revealIdx + 1, revealOpen: false } }
      return { ...state, phase: 'questions', round: { ...r, revealOpen: false, pairIdx: 0 } }
    case 'pair_next':
      return { ...state, round: { ...r, pairIdx: Math.min(r.pairIdx + 1, r.pairs.length - 1) } }
    case 'questions_again':
      return { ...state, round: { ...r, pairs: makePairs(state.players.map((p) => p.id)), pairIdx: 0, qRound: r.qRound + 1 } }
    case 'to_vote':
      return { ...state, phase: 'vote', round: { ...r, voteIdx: 0, voteOpen: false, voteSel: null, votes: {} } }
    case 'vote_open':
      return { ...state, round: { ...r, voteOpen: true, voteSel: null } }
    case 'vote_select':
      return { ...state, round: { ...r, voteSel: a.id } }
    case 'vote_confirm': {
      if (!r.voteSel) return state
      const voter = r.order[r.voteIdx]
      const votes = { ...r.votes, [voter]: r.voteSel }
      if (r.voteIdx + 1 < r.order.length) return { ...state, round: { ...r, votes, voteIdx: r.voteIdx + 1, voteOpen: false, voteSel: null } }
      const ids = state.players.map((p) => p.id)
      const tally = tallyVotes(ids, votes)
      return { ...state, phase: 'results', round: { ...r, votes, tally, caught: caughtMap(r.outsiders, tally), voteOpen: false, voteSel: null } }
    }
    case 'to_unmask':
      return { ...state, phase: 'unmask' }
    case 'to_guess':
      return { ...state, phase: 'guess', round: { ...r, guessIdx: 0, guessPick: null } }
    case 'guess_pick': {
      if (r.guessPick) return state
      const o = r.outsiders[r.guessIdx]
      return { ...state, round: { ...r, guessPick: a.word, guesses: { ...r.guesses, [o]: { choice: a.word, correct: a.word === r.word } } } }
    }
    case 'guess_next': {
      if (r.guessIdx + 1 < r.outsiders.length) return { ...state, round: { ...r, guessIdx: r.guessIdx + 1, guessPick: null } }
      const ids = state.players.map((p) => p.id)
      const deltas = scoreRound({ ids, outsiders: r.outsiders, votes: r.votes, caught: r.caught, guesses: r.guesses })
      const scores = { ...state.scores }
      ids.forEach((id) => {
        scores[id] = (scores[id] || 0) + deltas[id]
      })
      return { ...state, phase: 'score', scores, round: { ...r, deltas } }
    }
    default:
      return state
  }
}

export default function OutsiderGame() {
  const { players, plus } = useApp()
  const [state, dispatch] = useReducer(reducer, undefined, init)
  const playing = state.phase !== 'setup' && state.phase !== 'score'
  useExitGuard(playing)

  useEffect(() => {
    save('outsider.config', state.config)
  }, [state.config])

  useEffect(() => {
    keepAwake(state.phase !== 'setup')
    return () => keepAwake(false)
  }, [state.phase])

  const byId = useMemo(() => Object.fromEntries(state.players.map((p) => [p.id, p])), [state.players])
  const nameOf = (id) => byId[id]?.name || ''

  const start = (keepScores = false) => {
    sfx.drum()
    dispatch({ type: 'start', players: keepScores ? state.players : players, plus, keepScores })
  }

  switch (state.phase) {
    case 'setup':
      return <Setup state={state} dispatch={dispatch} players={players} plus={plus} onStart={() => start(false)} />
    case 'reveal':
      return <Reveal state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'questions':
      return <Questions key={state.round.qRound} state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'vote':
      return <Vote state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'results':
      return <Results state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'unmask':
      return <Unmask state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'guess':
      return <Guess state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'score':
      return <Score state={state} nameOf={nameOf} onAgain={async () => { await adBetweenRounds(plus); start(true) }} />
    default:
      return null
  }
}

// ───────── الإعداد ─────────
function Setup({ state, dispatch, players, plus, onStart }) {
  const nav = useNav()
  const n = players.length
  const overLimit = !plus && n > FREE_PLAYER_LIMIT
  const tooFew = n < MIN_PLAYERS
  const allowed = (c) => plus || !c.plus
  const selected = state.config.cats.filter((id) => id === RANDOM || CATEGORIES.some((c) => c.id === id && allowed(c)))
  const cats = selected.length ? selected : [RANDOM]
  const twoAllowed = n >= 7
  const outsiders = state.config.outsiders === 2 && twoAllowed ? 2 : 1

  const toggleCat = (cat) => {
    if (cat && !allowed(cat)) {
      nav.navigate({ name: 'paywall' })
      return
    }
    if (!cat) {
      dispatch({ type: 'config', patch: { cats: [RANDOM] } })
      return
    }
    let next = cats.filter((c) => c !== RANDOM)
    next = next.includes(cat.id) ? next.filter((c) => c !== cat.id) : [...next, cat.id]
    dispatch({ type: 'config', patch: { cats: next.length ? next : [RANDOM] } })
  }

  const canStart = !tooFew && !overLimit
  return (
    <Screen
      title="Imposter"
      eyebrow="Everyone knows the word... except one"
      glow="saffron"
      actions={
        <button type="button" className="btn btn-primary btn-block" disabled={!canStart} onClick={onStart}>
          Start round
        </button>
      }
    >
      <Section
        title={`Players (${ar(n)})`}
        aside={
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => nav.navigate({ name: 'players' })}>
            <IconUsers size={18} /> Edit
          </button>
        }
      >
        <div className="chips">
          {players.map((p) => (
            <Chip key={p.id}>{p.name}</Chip>
          ))}
        </div>
        {tooFew ? <p className="notice">You need at least {ar(MIN_PLAYERS)} players.</p> : null}
        {overLimit ? (
          <div className="notice">
            The free version allows up to {ar(FREE_PLAYER_LIMIT)} players.
            <button type="button" className="link" onClick={() => nav.navigate({ name: 'paywall' })}>
              Unlock up to 20 with Plus
            </button>
          </div>
        ) : null}
      </Section>

      <Section title="How many Imposters?">
        <Segmented
          id="outsiders-count"
          label="Number of Imposters"
          value={outsiders}
          onChange={(v) => dispatch({ type: 'config', patch: { outsiders: v } })}
          options={[
            { value: 1, label: 'One' },
            { value: 2, label: twoAllowed ? 'Two' : 'Two (7+ players)', disabled: !twoAllowed },
          ]}
        />
      </Section>

      <Section title="Categories" hint="Pick one or more, or leave it random.">
        <div className="cat-grid">
          <button type="button" className={`cat-tile random ${cats.includes(RANDOM) ? 'on' : ''}`} aria-pressed={cats.includes(RANDOM)} onClick={() => toggleCat(null)}>
            <IconShuffle size={20} />
            <span>Random</span>
          </button>
          {CATEGORIES.map((c) => {
            const locked = !allowed(c)
            const on = cats.includes(c.id)
            return (
              <button
                key={c.id}
                type="button"
                className={`cat-tile ${on ? 'on' : ''} ${locked ? 'locked' : ''}`}
                aria-pressed={on}
                aria-label={locked ? `${c.name} (Plus)` : c.name}
                onClick={() => toggleCat(c)}
              >
                <span>{c.name}</span>
                {locked ? <IconLock size={16} /> : <small>{ar(c.words.length)}</small>}
              </button>
            )
          })}
        </div>
      </Section>

      <Section title="Question timer">
        <Segmented
          id="question-timer"
          label="Question timer"
          value={state.config.timer}
          onChange={(v) => dispatch({ type: 'config', patch: { timer: v } })}
          options={[
            { value: 0, label: 'Off' },
            { value: 60, label: '1 min' },
            { value: 90, label: '1.5 min' },
            { value: 120, label: '2 min' },
          ]}
        />
      </Section>

      <details className="rules">
        <summary>How to play</summary>
        <ol>
          <li>Pass the phone around: everyone secretly sees the word... except the Imposter.</li>
          <li>Each player asks another player a question about the word without giving it away.</li>
          <li>Everyone secretly votes for who they think the Imposter is.</li>
          <li>The Imposter tries to guess the word for bonus points.</li>
        </ol>
      </details>
    </Screen>
  )
}

// ───────── كشف السالفة ─────────
function Reveal({ state, dispatch, nameOf }) {
  const r = state.round
  const id = r.order[r.revealIdx]
  const isOut = r.outsiders.includes(id)
  const last = r.revealIdx + 1 >= r.order.length

  const open = () => {
    sfx.reveal()
    buzz(isOut ? [40, 60, 40] : 25)
    dispatch({ type: 'reveal_open' })
  }

  return (
    <Screen
      title="Imposter"
      eyebrow="Secret word"
      glow="saffron"
      actions={
        r.revealOpen ? (
          <button type="button" className="btn btn-secondary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'reveal_next' }) }}>
            {last ? 'Hide... and start the questions' : 'Hide and pass'}
          </button>
        ) : (
          <button type="button" className="btn btn-primary btn-block" onClick={open}>
            <IconEye size={22} /> Reveal
          </button>
        )
      }
    >
      <Progress value={r.revealIdx + 1} total={r.order.length} label="Who has seen it" />
      {!r.revealOpen ? (
        <PassPrompt name={nameOf(id)} hint="No peeking! Tap Reveal once you have the phone." />
      ) : (
        <div className={`reveal-card ${isOut ? 'is-out' : ''}`} key={id} aria-live="polite">
          <span className="reveal-who">{nameOf(id)}</span>
          {isOut ? (
            <>
              <span className="reveal-label">You are</span>
              <strong className="reveal-big">The Imposter!</strong>
              <p className="reveal-hint">Listen carefully and figure out the word without getting caught</p>
            </>
          ) : (
            <>
              <span className="reveal-label">The word</span>
              <strong className="reveal-big">{r.word}</strong>
              <p className="reveal-hint">Don't say the word! Ask and answer smartly to expose the Imposter</p>
            </>
          )}
          <Chip tone="ghost">Category: {r.catName}</Chip>
        </div>
      )}
    </Screen>
  )
}

// ───────── الأسئلة ─────────
function Questions({ state, dispatch, nameOf }) {
  const r = state.round
  const [asker, target] = r.pairs[r.pairIdx]
  const total = state.config.timer
  const { left } = useCountdown(total, total > 0)
  const last = r.pairIdx + 1 >= r.pairs.length

  return (
    <Screen
      title="Question time"
      eyebrow={`Question round ${ar(r.qRound)} · ${r.catName}`}
      glow="saffron"
      actions={
        last ? (
          <div className="btn-row">
            <button type="button" className="btn btn-secondary" onClick={() => { sfx.tap(); dispatch({ type: 'questions_again' }) }}>
              One more round
            </button>
            <button type="button" className="btn btn-primary" onClick={() => { sfx.drum(); dispatch({ type: 'to_vote' }) }}>
              Let's vote
            </button>
          </div>
        ) : (
          <div className="btn-row">
            <button type="button" className="btn btn-ghost" onClick={() => { sfx.drum(); dispatch({ type: 'to_vote' }) }}>
              Vote now
            </button>
            <button type="button" className="btn btn-primary" onClick={() => { sfx.tap(); dispatch({ type: 'pair_next' }) }}>
              Next <IconForward size={20} />
            </button>
          </div>
        )
      }
    >
      {total > 0 ? (
        <div className="timer-wrap">
          <TimerRing total={total} left={left} size={112} label="Question round time" />
        </div>
      ) : null}
      <div className="qa-card" key={`${r.qRound}-${r.pairIdx}`}>
        <span className="qa-verb">Question from</span>
        <strong className="qa-asker">{nameOf(asker)}</strong>
        <span className="qa-verb">to</span>
        <strong className="qa-target">{nameOf(target)}</strong>
      </div>
      <p className="big-hint">One question about the word... without giving it away!</p>
      <Progress value={r.pairIdx + 1} total={r.pairs.length} label="Questions" />
    </Screen>
  )
}

// ───────── التصويت ─────────
function Vote({ state, dispatch, nameOf }) {
  const r = state.round
  const voter = r.order[r.voteIdx]
  const candidates = state.players.filter((p) => p.id !== voter)

  return (
    <Screen
      title="Voting"
      eyebrow="Everyone votes in secret"
      glow="coral"
      actions={
        r.voteOpen ? (
          <button type="button" className="btn btn-primary btn-block" disabled={!r.voteSel} onClick={() => { sfx.tap(); buzz(20); dispatch({ type: 'vote_confirm' }) }}>
            Confirm vote
          </button>
        ) : (
          <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'vote_open' }) }}>
            Vote
          </button>
        )
      }
    >
      <Progress value={r.voteIdx + 1} total={r.order.length} label="Votes" />
      {!r.voteOpen ? (
        <PassPrompt lead="Time to vote" name={nameOf(voter)} hint="Pass the phone and keep your vote secret." color="var(--coral)" />
      ) : (
        <>
          <h2 className="ask-title">{nameOf(voter)}, who is the Imposter?</h2>
          <div className="vote-grid" role="radiogroup" aria-label="Choose a player">
            {candidates.map((p) => (
              <button
                key={p.id}
                type="button"
                role="radio"
                aria-checked={r.voteSel === p.id}
                className={`vote-btn ${r.voteSel === p.id ? 'on' : ''}`}
                onClick={() => { sfx.tap(); dispatch({ type: 'vote_select', id: p.id }) }}
              >
                {p.name}
              </button>
            ))}
          </div>
        </>
      )}
    </Screen>
  )
}

// ───────── نتيجة التصويت ─────────
function Results({ state, dispatch, nameOf }) {
  const r = state.round
  const rows = Object.entries(r.tally).sort((a, b) => b[1] - a[1])
  const max = Math.max(1, ...rows.map(([, v]) => v))
  return (
    <Screen
      title="Vote results"
      eyebrow="The votes are in"
      glow="coral"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.drum(); buzz([30, 50, 30]); dispatch({ type: 'to_unmask' }) }}>
          Reveal the Imposter
        </button>
      }
    >
      <ul className="bars">
        {rows.map(([id, v], i) => (
          <li key={id} className="bar-row" style={{ '--i': i }}>
            <span className="bar-name">{nameOf(id)}</span>
            <span className="bar-track">
              <span className="bar-fill" style={{ width: `${(v / max) * 100}%` }} />
            </span>
            <span className="bar-count">{ar(v)}</span>
          </li>
        ))}
      </ul>
    </Screen>
  )
}

// ───────── الكشف ─────────
function Unmask({ state, dispatch, nameOf }) {
  const r = state.round
  const names = r.outsiders.map(nameOf)
  const allCaught = r.outsiders.every((o) => r.caught[o])
  const noneCaught = r.outsiders.every((o) => !r.caught[o])
  useEffect(() => {
    if (allCaught) sfx.success()
    else sfx.fail()
  }, [allCaught])
  const first = r.outsiders[0]
  return (
    <Screen
      title="The truth"
      eyebrow="Moment of truth"
      glow="coral"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'to_guess' }) }}>
          {r.outsiders.length > 1 ? 'Imposters, guess the word' : `${nameOf(first)}, guess the word`}
        </button>
      }
    >
      <div className="unmask">
        <span className="unmask-lead">{r.outsiders.length > 1 ? 'The Imposters were' : 'The Imposter was'}</span>
        <strong className="unmask-names">{joinNames(names)}</strong>
        <p className={`unmask-status ${allCaught ? 'good' : 'bad'}`}>
          {allCaught ? (r.outsiders.length > 1 ? 'You caught them both!' : 'You caught them!') : noneCaught ? (r.outsiders.length > 1 ? 'They both fooled you!' : 'They fooled you!') : 'You caught one... the other got away!'}
        </p>
        <p className="big-hint">One last chance: guessing the word earns 2 bonus points.</p>
      </div>
    </Screen>
  )
}

// ───────── التخمين ─────────
function Guess({ state, dispatch, nameOf }) {
  const r = state.round
  const o = r.outsiders[r.guessIdx]
  const pickW = (w) => {
    if (r.guessPick) return
    if (w === r.word) {
      sfx.success()
      buzz([30, 40, 30])
    } else {
      sfx.fail()
      buzz(120)
    }
    dispatch({ type: 'guess_pick', word: w })
  }
  const lastOut = r.guessIdx + 1 >= r.outsiders.length
  const correct = r.guessPick === r.word
  return (
    <Screen
      title="Guess the word"
      eyebrow={`Category: ${r.catName}`}
      glow="saffron"
      actions={
        r.guessPick ? (
          <button type="button" className="btn btn-primary btn-block" onClick={() => dispatch({ type: 'guess_next' })}>
            {lastOut ? 'See scores' : 'Next Imposter'}
          </button>
        ) : null
      }
    >
      <h2 className="ask-title">{nameOf(o)}, what was the word?</h2>
      <div className="guess-grid">
        {r.options.map((w) => {
          const state2 = !r.guessPick ? '' : w === r.word ? 'right' : w === r.guessPick ? 'wrong' : 'dim'
          return (
            <button key={w} type="button" className={`guess-btn ${state2}`} disabled={!!r.guessPick} onClick={() => pickW(w)}>
              {w}
            </button>
          )
        })}
      </div>
      {r.guessPick ? (
        <p className={`guess-result ${correct ? 'good' : 'bad'}`} aria-live="polite">
          {correct ? 'Correct! Nailed it' : `Nope... the word was "${r.word}"`}
        </p>
      ) : null}
    </Screen>
  )
}

// ───────── النقط ─────────
function Score({ state, nameOf, onAgain }) {
  const nav = useNav()
  const r = state.round
  const rows = state.players.map((p) => ({ id: p.id, total: state.scores[p.id] || 0, delta: r.deltas[p.id] || 0 })).sort((a, b) => b.total - a.total || b.delta - a.delta)
  return (
    <Screen
      title="Scores"
      eyebrow={`Round ${ar(state.roundNo)} · The word was "${r.word}"`}
      glow="saffron"
      onBack={nav.goHome}
      actions={
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" onClick={nav.goHome}>
            Finish
          </button>
          <button type="button" className="btn btn-primary" onClick={onAgain}>
            New round
          </button>
        </div>
      }
    >
      <ol className="scoreboard">
        {rows.map((row, i) => (
          <li key={row.id} className={`score-row ${i === 0 && row.total > 0 ? 'lead' : ''}`} style={{ '--i': i }}>
            <span className="score-rank">{ar(i + 1)}</span>
            <span className="score-name">
              {nameOf(row.id)}
              {r.outsiders.includes(row.id) ? <small>Imposter</small> : null}
            </span>
            {row.delta > 0 ? <span className="score-delta">+{ar(row.delta)}</span> : <span className="score-delta zero">0</span>}
            <span className="score-total">{ar(row.total)}</span>
          </li>
        ))}
      </ol>
      <p className="big-hint">Everyone who voted right gets 1 point. The Imposter gets 2 points for not getting caught, and 2 more for guessing the word.</p>
    </Screen>
  )
}
