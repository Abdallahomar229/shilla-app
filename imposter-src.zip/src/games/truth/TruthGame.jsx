import { useEffect, useRef, useState } from 'react'
import { useApp } from '../../state/app.jsx'
import { useNav } from '../../state/nav.jsx'
import { Screen, Segmented } from '../../components/ui.jsx'
import { IconLock, IconUsers, IconSkip, IconForward, IconRefresh } from '../../components/Icons.jsx'
import { TRUTH_PACKS, WHO_PACKS } from '../../content/truth.js'
import { shuffle } from '../../lib/random.js'
import { ar } from '../../lib/format.js'
import { load, save } from '../../lib/storage.js'
import { sfx } from '../../lib/sfx.js'
import { adBetweenRounds } from '../../lib/ads.js'
import { buzz, keepAwake } from '../../lib/device.js'

const MODES = { truth: TRUTH_PACKS, who: WHO_PACKS }

export default function TruthGame() {
  const { players, plus } = useApp()
  const nav = useNav()
  const [mode, setMode] = useState(() => load('truth.mode', 'truth'))
  const [packId, setPackId] = useState(null)

  useEffect(() => {
    save('truth.mode', mode)
  }, [mode])

  useEffect(() => {
    keepAwake(!!packId)
    return () => keepAwake(false)
  }, [packId])

  const packs = MODES[mode]
  const pack = packs.find((p) => p.id === packId)

  if (pack) {
    return mode === 'truth' ? (
      <TruthDareDeck key={`truth-${pack.id}`} pack={pack} players={players} onChangePack={() => setPackId(null)} />
    ) : (
      <WhoDeck key={`who-${pack.id}`} pack={pack} onChangePack={() => setPackId(null)} />
    )
  }

  const open = (p) => {
    if (p.plus && !plus) {
      nav.navigate({ name: 'paywall' })
      return
    }
    sfx.tap()
    setPackId(p.id)
  }

  return (
    <Screen title="Truth or Dare" eyebrow="Pick a pack and start" glow="mint">
      <Segmented
        id="truth-mode"
        label="Game type"
        value={mode}
        onChange={(v) => {
          sfx.tap()
          setMode(v)
        }}
        options={[
          { value: 'truth', label: 'Truth or Dare' },
          { value: 'who', label: 'Most Likely To' },
        ]}
      />
      <p className="mode-hint">
        {mode === 'truth'
          ? 'On your turn, pick truth or dare. No backing out!'
          : 'Read the question out loud, then everyone points at the right person at the same time.'}
      </p>
      <div className="packs">
        {packs.map((p, i) => {
          const locked = p.plus && !plus
          const count = p.questions.length + (p.dares ? p.dares.length : 0)
          return (
            <button key={p.id} type="button" className={`pack ${locked ? 'locked' : ''}`} style={{ '--i': i }} onClick={() => open(p)} aria-label={locked ? `${p.name} (Plus)` : p.name}>
              <span className="pack-main">
                <span className="pack-name">{p.name}</span>
                <span className="pack-blurb">{p.blurb}</span>
              </span>
              <span className="pack-side">
                {locked ? <IconLock size={20} /> : <span className="pack-count">{ar(count)}</span>}
                <small>{locked ? 'Plus' : 'cards'}</small>
              </span>
            </button>
          )
        })}
      </div>
      {mode === 'truth' && players.length < 2 ? (
        <div className="notice">
          Truth or Dare needs at least 2 players.
          <button type="button" className="link" onClick={() => nav.navigate({ name: 'players' })}>
            Add players
          </button>
        </div>
      ) : null}
    </Screen>
  )
}

// A shuffled pile that reshuffles itself when it runs out
function usePile(items) {
  const pile = useRef({ order: shuffle(items.map((_, i) => i)), pos: 0 })
  return () => {
    const p = pile.current
    if (p.pos >= p.order.length) {
      p.order = shuffle(items.map((_, i) => i))
      p.pos = 0
    }
    return items[p.order[p.pos++]]
  }
}

function TruthDareDeck({ pack, players, onChangePack }) {
  const { plus } = useApp()
  const nav = useNav()
  const drawTruth = usePile(pack.questions)
  const drawDare = usePile(pack.dares || pack.questions)
  const [turn, setTurn] = useState(0)
  const [card, setCard] = useState(null) // { kind: 'truth' | 'dare', text }
  const [dealt, setDealt] = useState(0)
  const tooFew = players.length < 2
  const who = players.length ? players[turn % players.length] : null

  const pick = (kind) => {
    sfx.tap()
    buzz(20)
    setCard({ kind, text: kind === 'dare' ? drawDare() : drawTruth() })
    setDealt((d) => d + 1)
  }
  const swap = () => {
    sfx.tap()
    setCard((c) => ({ kind: c.kind, text: c.kind === 'dare' ? drawDare() : drawTruth() }))
  }
  const next = async () => {
    sfx.tap()
    const nextTurn = (turn + 1) % Math.max(1, players.length)
    // A short ad only after a full round of players (free version)
    if (nextTurn === 0) await adBetweenRounds(plus)
    setCard(null)
    setTurn(nextTurn)
  }

  let actions
  if (!card) {
    actions = (
      <div className="btn-row">
        <button type="button" className="btn btn-mint" onClick={() => pick('truth')} disabled={tooFew}>
          Truth
        </button>
        <button type="button" className="btn btn-crimson" onClick={() => pick('dare')} disabled={tooFew}>
          Dare
        </button>
      </div>
    )
  } else {
    actions = (
      <div className="btn-row">
        <button type="button" className="btn btn-secondary" onClick={swap}>
          <IconSkip size={18} /> Another one
        </button>
        <button type="button" className="btn btn-mint" onClick={next}>
          Next player <IconForward size={20} />
        </button>
      </div>
    )
  }

  return (
    <Screen
      title={pack.name}
      eyebrow="Truth or Dare"
      glow="mint"
      onBack={onChangePack}
      right={
        <button type="button" className="btn btn-ghost btn-sm" onClick={onChangePack}>
          Packs
        </button>
      }
      actions={actions}
    >
      <div className="deck-top">
        {who ? (
          <span className="turn">
            <strong>{who.name}</strong>&apos;s turn
          </span>
        ) : (
          <span className="turn">Add players to start</span>
        )}
        <span className="deck-count">#{ar(dealt || 1)}</span>
      </div>
      {card ? (
        <div className={`q-card ${card.kind === 'dare' ? 'dare' : ''}`} key={`${dealt}-${card.text}`}>
          <span className={`q-kind ${card.kind}`}>{card.kind === 'dare' ? 'Dare' : 'Truth'}</span>
          <p className="q-text">{card.text}</p>
        </div>
      ) : (
        <div className="q-card choose" key={`choose-${turn}`}>
          <p className="q-text">Truth or dare?</p>
        </div>
      )}
      {tooFew ? (
        <div className="notice">
          Add at least 2 players to take turns.
          <button type="button" className="link" onClick={() => nav.navigate({ name: 'players' })}>
            <IconUsers size={16} /> Players
          </button>
        </div>
      ) : null}
    </Screen>
  )
}

function WhoDeck({ pack, onChangePack }) {
  const { plus } = useApp()
  const [order, setOrder] = useState(() => shuffle(pack.questions.map((_, i) => i)))
  const [pos, setPos] = useState(0)
  const [count, setCount] = useState(null)
  const timer = useRef(null)
  const done = pos >= order.length

  useEffect(() => () => clearInterval(timer.current), [])

  const next = () => {
    sfx.tap()
    setCount(null)
    clearInterval(timer.current)
    setPos((p) => p + 1)
  }
  const restart = async () => {
    sfx.tap()
    await adBetweenRounds(plus)
    setOrder(shuffle(pack.questions.map((_, i) => i)))
    setPos(0)
  }
  const countdown = () => {
    if (count !== null) return
    setCount(3)
    sfx.tick()
    let n = 3
    timer.current = setInterval(() => {
      n -= 1
      if (n > 0) {
        sfx.tick()
        setCount(n)
      } else {
        clearInterval(timer.current)
        setCount(0)
        sfx.success()
        buzz([30, 40, 30])
      }
    }, 800)
  }

  const q = !done ? pack.questions[order[pos]] : null

  const actions = done ? (
    <div className="btn-row">
      <button type="button" className="btn btn-secondary" onClick={onChangePack}>
        Another pack
      </button>
      <button type="button" className="btn btn-mint" onClick={restart}>
        <IconRefresh size={20} /> Play again
      </button>
    </div>
  ) : (
    <div className="btn-row">
      <button type="button" className="btn btn-secondary" onClick={countdown} disabled={count !== null && count > 0}>
        3... 2... 1... Point!
      </button>
      <button type="button" className="btn btn-mint" onClick={next}>
        Next <IconForward size={20} />
      </button>
    </div>
  )

  return (
    <Screen
      title={pack.name}
      eyebrow="Most Likely To"
      glow="mint"
      onBack={onChangePack}
      right={
        <button type="button" className="btn btn-ghost btn-sm" onClick={onChangePack}>
          Packs
        </button>
      }
      actions={actions}
    >
      {done ? (
        <div className="deck-done">
          <strong>Pack finished!</strong>
          <p>You went through every question. Play it again in a new order, or try another pack?</p>
        </div>
      ) : (
        <>
          <div className="deck-top">
            <span className="turn">Everyone points together</span>
            <span className="deck-count">
              {ar(pos + 1)} / {ar(order.length)}
            </span>
          </div>
          <div className="q-card who" key={pos}>
            <p className="q-text">{q}</p>
            {count !== null ? <span className={`count ${count === 0 ? 'go' : ''}`} aria-live="assertive">{count === 0 ? 'Point!' : ar(count)}</span> : null}
          </div>
        </>
      )}
    </Screen>
  )
}
