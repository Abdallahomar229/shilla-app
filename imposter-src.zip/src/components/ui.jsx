import { useEffect, useRef, useState } from 'react'
import { useNav } from '../state/nav.jsx'
import { IconBack, IconLock, IconMinus, IconPlus } from './Icons.jsx'
import { ar, clock } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

// هيكل الشاشة: شريط علوي + محتوى بيتسكرول + أزرار تحت في متناول الإبهام
export function Screen({ title, eyebrow, onBack, glow = 'saffron', right, children, actions, className = '', noBack = false, headerless = false }) {
  const nav = useNav()
  return (
    <section className={`screen glow-${glow} ${className}`}>
      {!headerless && (
        <header className="topbar">
          {noBack ? (
            <span className="icon-spacer" />
          ) : (
            <button type="button" className="icon-btn" onClick={onBack || nav.back} aria-label="Back">
              <IconBack />
            </button>
          )}
          <div className="topbar-title">
            {eyebrow ? <span className="eyebrow">{eyebrow}</span> : null}
            <h1>{title}</h1>
          </div>
          <div className="topbar-right">{right}</div>
        </header>
      )}
      <div className="screen-body">
        <div className="screen-inner">{children}</div>
      </div>
      {actions ? (
        <footer className="actions">
          <div className="actions-inner">{actions}</div>
        </footer>
      ) : null}
    </section>
  )
}

export function Section({ title, hint, children, aside }) {
  return (
    <section className="section">
      <div className="section-head">
        <h2>{title}</h2>
        {aside}
      </div>
      {hint ? <p className="section-hint">{hint}</p> : null}
      {children}
    </section>
  )
}

export function Toggle({ id, checked, onChange, label, hint, locked = false, onLocked }) {
  return (
    <div className="row-toggle">
      <label htmlFor={id} className="row-label">
        <span>{label}</span>
        {hint ? <small>{hint}</small> : null}
      </label>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={!!checked}
        className={`switch ${checked ? 'on' : ''} ${locked ? 'locked' : ''}`}
        onClick={() => {
          if (locked) onLocked?.()
          else onChange(!checked)
        }}
      >
        <span className="knob">{locked ? <IconLock size={13} strokeWidth={2.4} /> : null}</span>
      </button>
    </div>
  )
}

export function Segmented({ id, value, options, onChange, label }) {
  return (
    <div className="seg" role="radiogroup" aria-label={label} id={id}>
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          className={`seg-btn ${value === o.value ? 'on' : ''}`}
          disabled={o.disabled}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

export function Stepper({ id, value, min, max, onChange, label }) {
  return (
    <div className="stepper" role="group" aria-label={label} id={id}>
      <button type="button" className="step-btn" aria-label="Decrease" disabled={value <= min} onClick={() => onChange(Math.max(min, value - 1))}>
        <IconMinus size={20} />
      </button>
      <output className="step-value" aria-live="polite">
        {ar(value)}
      </output>
      <button type="button" className="step-btn" aria-label="Increase" disabled={value >= max} onClick={() => onChange(Math.min(max, value + 1))}>
        <IconPlus size={20} />
      </button>
    </div>
  )
}

export function Sheet({ open, title, children, onClose }) {
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return undefined
    const el = ref.current?.querySelector('[data-autofocus]') || ref.current?.querySelector('button')
    el?.focus?.()
    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="sheet-wrap" onClick={onClose} role="presentation">
      <div className="sheet" role="dialog" aria-modal="true" aria-label={title} ref={ref} onClick={(e) => e.stopPropagation()}>
        <h2 className="sheet-title">{title}</h2>
        {children}
      </div>
    </div>
  )
}

export function Chip({ children, tone = 'default', icon }) {
  return (
    <span className={`chip chip-${tone}`}>
      {icon}
      {children}
    </span>
  )
}

// عدّاد تنازلي: بيرجع الثواني الباقية، وبينادي onDone مرة واحدة
export function useCountdown(total, running, onDone) {
  const [left, setLeft] = useState(total)
  const leftRef = useRef(total)
  const doneRef = useRef(false)
  const onDoneRef = useRef(onDone)
  onDoneRef.current = onDone

  useEffect(() => {
    leftRef.current = total
    doneRef.current = false
    setLeft(total)
  }, [total])

  useEffect(() => {
    if (!running || total <= 0) return undefined
    const start = Date.now()
    const startLeft = leftRef.current
    let lastWhole = Math.ceil(startLeft)
    const id = setInterval(() => {
      const next = Math.max(0, startLeft - (Date.now() - start) / 1000)
      leftRef.current = next
      setLeft(next)
      const whole = Math.ceil(next)
      if (whole !== lastWhole) {
        lastWhole = whole
        if (whole <= 5 && whole > 0) sfx.tick()
      }
      if (next <= 0 && !doneRef.current) {
        doneRef.current = true
        clearInterval(id)
        sfx.alarm()
        onDoneRef.current?.()
      }
    }, 200)
    return () => clearInterval(id)
  }, [running, total])

  const reset = () => {
    leftRef.current = total
    doneRef.current = false
    setLeft(total)
  }
  return { left, reset }
}

export function TimerRing({ total, left, size = 132, color = 'var(--saffron)', label }) {
  const r = 52
  const circ = 2 * Math.PI * r
  const frac = total > 0 ? Math.max(0, Math.min(1, left / total)) : 0
  const urgent = left <= 10 && left > 0
  return (
    <div className={`timer-ring ${urgent ? 'urgent' : ''} ${left <= 0 ? 'done' : ''}`} style={{ width: size, height: size, '--ring': color }} role="timer" aria-label={label || 'Time left'}>
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <circle cx="60" cy="60" r={r} className="ring-track" />
        <circle
          cx="60"
          cy="60"
          r={r}
          className="ring-fill"
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - frac)}
          transform="rotate(-90 60 60)"
        />
      </svg>
      <span className="timer-text">{left <= 0 ? 'Time!' : clock(left)}</span>
    </div>
  )
}

// شاشة «مرّر الموبايل»
export function PassPrompt({ lead = 'Pass the phone to', name, hint, color = 'var(--saffron)' }) {
  return (
    <div className="pass" style={{ '--c': color }}>
      <span className="pass-lead">{lead}</span>
      <strong className="pass-name">{name}</strong>
      {hint ? <p className="pass-hint">{hint}</p> : null}
    </div>
  )
}

export function Progress({ value, total, label }) {
  return (
    <div className="progress" aria-label={label}>
      <div className="progress-bar">
        <span style={{ width: `${total ? (value / total) * 100 : 0}%` }} />
      </div>
      <span className="progress-text">
        {ar(value)} of {ar(total)}
      </span>
    </div>
  )
}
