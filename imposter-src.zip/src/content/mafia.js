// Mafia roles and narrator lines (simple, dramatic English)

export const ROLES = {
  mafia: {
    key: 'mafia',
    name: 'Mafia',
    team: 'mafia',
    color: 'var(--crimson)',
    img: 'role_mafia',
    plus: false,
    short: 'You work in the dark with the other Mafia',
    description:
      'Each night you silently agree on someone to take out. Win when your numbers match the rest of the town, without getting caught.',
  },
  doctor: {
    key: 'doctor',
    name: 'Doctor',
    team: 'town',
    color: 'var(--mint)',
    img: 'role_doctor',
    plus: false,
    short: 'You save one person each night',
    description:
      'Each night you pick someone to protect, even yourself. If the Mafia picks the same person, they wake up safe.',
  },
  detective: {
    key: 'detective',
    name: 'Detective',
    team: 'town',
    color: 'var(--saffron)',
    img: 'role_detective',
    plus: false,
    short: 'You investigate one person each night',
    description:
      'Each night you point at someone, and the app tells only you whether they are Mafia. Use what you learn wisely in the discussion.',
  },
  citizen: {
    key: 'citizen',
    name: 'Citizen',
    team: 'town',
    color: 'var(--lavender)',
    img: 'role_citizen',
    plus: false,
    short: 'Your vote is your weapon',
    description:
      'You have no night power, but your voice in the daytime discussion and vote is what exposes the Mafia.',
  },
  sniper: {
    key: 'sniper',
    name: 'Sniper',
    team: 'town',
    color: 'var(--coral)',
    img: 'role_sniper',
    plus: true,
    short: 'You get one shot the whole game',
    description:
      'Once per game you can take someone out at night. Hit the Mafia and you save the town... miss and the town loses one of its own.',
  },
  jester: {
    key: 'jester',
    name: 'Jester',
    team: 'jester',
    color: 'var(--saffron)',
    img: 'role_jester',
    plus: true,
    short: 'You want the town to vote you out',
    description:
      'Your only goal is to get voted out during the day. If it happens, you win alone and the game ends!',
  },
}

export const NIGHT_ORDER = ['mafia', 'doctor', 'detective', 'sniper']

// Narrator lines: each step has several versions. {name}, {names} and {role} are filled in during play.
export const NARRATION = {
  intro: [
    'Everyone knows their role... let the game begin.',
    'The roles have been dealt in secret... let the story begin.',
  ],
  nightStart: [
    'Night falls over the town... everyone, close your eyes.',
    'The sky turns dark and the town sleeps... close your eyes.',
    'It is midnight and all is silent... everyone, close your eyes.',
  ],
  mafiaWake: [
    'Mafia, open your eyes... and silently choose your victim.',
    'Wake up, Mafia... agree on tonight\'s target without a sound.',
    'Creatures of the night, open your eyes... who leaves the town tonight?',
  ],
  mafiaSleep: [
    'The choice is made... Mafia, close your eyes.',
    'Go back to sleep, Mafia.',
  ],
  doctorWake: [
    'Doctor, open your eyes... who will you save tonight?',
    'Wake up, Doctor... choose one person to protect until morning.',
  ],
  doctorSleep: [
    'Thank you, Doctor. Close your eyes.',
    'Go back to sleep, Doctor.',
  ],
  detectiveWake: [
    'Detective, open your eyes... point at the one you suspect.',
    'Wake up, Detective... who is your suspect tonight?',
  ],
  detectiveSleep: [
    'Keep what you learned to yourself... close your eyes, Detective.',
    'Go back to sleep, Detective, and think carefully.',
  ],
  sniperWake: [
    'Sniper, open your eyes... will you take your only shot tonight?',
    'Wake up, Sniper... you only get one chance, use it well.',
  ],
  sniperSleep: [
    'Close your eyes, Sniper.',
    'Back to your post, Sniper.',
  ],
  morning: [
    'Morning has come... everyone, open your eyes.',
    'The sun rises over the town... wake up, everyone.',
    'The rooster crows and the night is over... open your eyes.',
  ],
  deathOne: [
    'Sadly... the town lost {name} last night.',
    'The town wakes up to terrible news: {name} is gone.',
    'A cruel night... the town has lost {name}.',
  ],
  deathMany: [
    'A brutal night... the town has lost {names}.',
    'Sadly, tonight we lost {names}.',
  ],
  revealRole: [
    'Their role was: {role}.',
    'The true role: {role}.',
  ],
  saved: [
    'The Mafia struck tonight... but the Doctor was faster. Everyone survived!',
    'A terrifying night ended in peace... the Doctor saved the victim!',
  ],
  quiet: [
    'The night passed quietly... no one was taken.',
    'An unusually calm night... everyone is safe.',
  ],
  discussion: [
    'Now discuss... which one of you is hiding a secret?',
    'Time to talk... watch every face carefully.',
  ],
  voteCall: [
    'The discussion is over... the town must decide now.',
    'Time to vote... who leaves the town today?',
  ],
  voteOut: [
    'The town has decided to banish {name}.',
    'By majority vote... {name} is out of the game.',
  ],
  noVote: [
    'The town could not agree... and the game goes on.',
    'The town chose to wait... no one leaves today.',
  ],
  jesterWin: [
    'What a twist! That was the Jester... they fooled everyone and won alone!',
    'The Jester\'s trick worked... they win alone!',
  ],
  mafiaWin: [
    'The Mafia wins... the town is completely under their control.',
    'Darkness covers the town... the Mafia wins.',
  ],
  townWin: [
    'The town wins! Every member of the Mafia has been exposed.',
    'Peace returns to the town... the citizens win!',
  ],
}

// Text shown on screen while a role is acting (or when its owner is out and no one knows)
export const ROLE_WAIT_TEXT = {
  mafia: 'The Mafia is choosing...',
  doctor: 'The Doctor is choosing...',
  detective: 'The Detective is investigating...',
  sniper: 'The Sniper is thinking...',
}

export function fill(template, vars = {}) {
  return template.replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : ''))
}
