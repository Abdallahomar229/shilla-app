// Imposter categories
// Each category: stable id, name, plus (locked in the free version?), and words (30+ unique words)
// Family-friendly and globally understood: no religious symbols, alcohol, gambling or politics.

export const CATEGORIES = [
  // ───────────── Free ─────────────
  {
    id: 'food',
    name: 'Food',
    plus: false,
    words: [
      'Pizza', 'Burger', 'Hot Dog', 'Tacos', 'Sushi', 'Spaghetti', 'Lasagna', 'Fried Chicken',
      'Steak', 'Pancakes', 'Waffles', 'Burrito', 'Ramen', 'Dumplings', 'Fries', 'Nachos',
      'Mac and Cheese', 'Grilled Cheese', 'Caesar Salad', 'Omelette', 'Kebab', 'Falafel', 'Hummus', 'Curry',
      'Fish and Chips', 'Paella', 'Pad Thai', 'Chicken Wings', 'Meatballs', 'Popcorn', 'Croissant', 'Bagel',
      'Shawarma', 'Quesadilla', 'Soup',
    ],
  },
  {
    id: 'animals',
    name: 'Animals',
    plus: false,
    words: [
      'Lion', 'Tiger', 'Elephant', 'Giraffe', 'Monkey', 'Horse', 'Camel', 'Cow', 'Sheep', 'Goat',
      'Dog', 'Cat', 'Rabbit', 'Mouse', 'Bear', 'Wolf', 'Fox', 'Deer', 'Crocodile', 'Turtle',
      'Snake', 'Eagle', 'Owl', 'Parrot', 'Penguin', 'Dolphin', 'Whale', 'Shark', 'Octopus', 'Butterfly',
      'Bee', 'Ant', 'Zebra', 'Kangaroo', 'Panda', 'Hippo', 'Rhino', 'Koala', 'Flamingo', 'Duck',
    ],
  },
  {
    id: 'places',
    name: 'Places',
    plus: false,
    words: [
      'Hospital', 'School', 'University', 'Airport', 'Train Station', 'Supermarket', 'Mall', 'Movie Theater', 'Restaurant', 'Coffee Shop',
      'Beach', 'Desert', 'Mountain', 'Zoo', 'Theme Park', 'Stadium', 'Gym', 'Bank', 'Pharmacy', 'Hotel',
      'Library', 'Museum', 'Barbershop', 'Bakery', 'Farmers Market', 'Gas Station', 'Car Wash', 'Post Office', 'Farm', 'Campsite',
      "Dentist's Office", 'Swimming Pool', 'Circus', 'Aquarium', 'Bowling Alley', 'Photo Studio', 'Garage', 'Cruise Ship', 'Space Station', 'Castle',
    ],
  },
  {
    id: 'jobs',
    name: 'Jobs',
    plus: false,
    words: [
      'Doctor', 'Engineer', 'Teacher', 'Lawyer', 'Chef', 'Pilot', 'Flight Attendant', 'Taxi Driver', 'Carpenter', 'Plumber',
      'Electrician', 'Mechanic', 'Barber', 'Tailor', 'Farmer', 'Fisherman', 'Painter', 'Photographer', 'Actor', 'Soccer Player',
      'Journalist', 'News Anchor', 'Nurse', 'Pharmacist', 'Accountant', 'Programmer', 'Firefighter', 'Security Guard', 'Butcher', 'Baker',
      'Astronaut', 'Archaeologist', 'Tour Guide', 'YouTuber', 'Delivery Driver', 'Mail Carrier', 'Personal Trainer', 'Fashion Designer', 'Vet', 'Police Officer',
    ],
  },
  {
    id: 'home',
    name: 'Around the House',
    plus: false,
    words: [
      'Sofa', 'Bed', 'Wardrobe', 'Fridge', 'Oven', 'Washing Machine', 'Microwave', 'TV', 'Remote Control', 'Fan',
      'Air Conditioner', 'Rug', 'Curtain', 'Mirror', 'Wall Clock', 'Light Bulb', 'Pillow', 'Blanket', 'Bookshelf', 'Table',
      'Vacuum Cleaner', 'Trash Can', 'Key', 'Window', 'Shower', 'Toothbrush', 'Soap', 'Towel', 'Mug', 'Spoon',
      'Toaster', 'Kettle', 'Dishwasher', 'Doorbell', 'Lamp', 'Iron', 'Hair Dryer', 'Laundry Basket', 'Coat Hanger', 'Alarm Clock',
    ],
  },
  {
    id: 'sports',
    name: 'Sports & Games',
    plus: false,
    words: [
      'Soccer', 'Basketball', 'Tennis', 'Volleyball', 'Swimming', 'Boxing', 'Karate', 'Golf', 'Baseball', 'Cricket',
      'Table Tennis', 'Chess', 'Bowling', 'Skiing', 'Surfing', 'Skateboarding', 'Cycling', 'Marathon', 'Wrestling', 'Horse Riding',
      'Archery', 'Fencing', 'Gymnastics', 'Ice Hockey', 'Rugby', 'Badminton', 'Darts', 'Billiards', 'Yoga', 'Rock Climbing',
      'Hide and Seek', 'Tag', 'Jump Rope', 'Video Games', 'Dodgeball', 'Hopscotch', 'Tug of War', 'Kite Flying',
    ],
  },

  // ───────────── Plus ─────────────
  {
    id: 'desserts',
    name: 'Desserts',
    plus: true,
    words: [
      'Chocolate Cake', 'Cheesecake', 'Ice Cream', 'Donut', 'Cupcake', 'Brownie', 'Cookie', 'Muffin', 'Apple Pie', 'Tiramisu',
      'Macaron', 'Churros', 'Pudding', 'Cotton Candy', 'Lollipop', 'Gummy Bears', 'Milkshake', 'Crepe', 'Baklava', 'Cinnamon Roll',
      'Popsicle', 'Marshmallow', 'Jelly', 'Fudge', 'Banana Split', 'Frozen Yogurt', 'Carrot Cake', 'Eclair', 'Candy Cane', 'Caramel',
      'Sundae', 'Gelato', 'Mochi', 'Panna Cotta', 'Chocolate Bar',
    ],
  },
  {
    id: 'drinks',
    name: 'Drinks',
    plus: true,
    words: [
      'Coffee', 'Tea', 'Hot Chocolate', 'Orange Juice', 'Lemonade', 'Smoothie', 'Milkshake', 'Iced Tea', 'Cappuccino', 'Latte',
      'Espresso', 'Bubble Tea', 'Coconut Water', 'Sparkling Water', 'Cola', 'Energy Drink', 'Apple Juice', 'Mango Juice', 'Milk', 'Matcha',
      'Iced Coffee', 'Root Beer', 'Ginger Ale', 'Frappuccino', 'Mint Tea', 'Watermelon Juice', 'Protein Shake', 'Chai', 'Mocha', 'Slushie',
      'Tomato Juice', 'Strawberry Milk', 'Herbal Tea', 'Cold Brew', 'Water',
    ],
  },
  {
    id: 'fruits-veg',
    name: 'Fruits & Veggies',
    plus: true,
    words: [
      'Apple', 'Banana', 'Orange', 'Strawberry', 'Grapes', 'Watermelon', 'Mango', 'Pineapple', 'Peach', 'Cherry',
      'Kiwi', 'Lemon', 'Avocado', 'Coconut', 'Blueberry', 'Pomegranate', 'Pear', 'Fig', 'Papaya', 'Plum',
      'Tomato', 'Potato', 'Carrot', 'Onion', 'Garlic', 'Cucumber', 'Broccoli', 'Spinach', 'Pumpkin', 'Corn',
      'Eggplant', 'Mushroom', 'Bell Pepper', 'Lettuce', 'Cabbage', 'Zucchini', 'Peas', 'Cauliflower', 'Radish', 'Celery',
    ],
  },
  {
    id: 'countries',
    name: 'Countries',
    plus: true,
    words: [
      'USA', 'Canada', 'Mexico', 'Brazil', 'Argentina', 'United Kingdom', 'France', 'Germany', 'Italy', 'Spain',
      'Portugal', 'Netherlands', 'Sweden', 'Norway', 'Russia', 'Turkey', 'Egypt', 'Morocco', 'Nigeria', 'South Africa',
      'Kenya', 'Saudi Arabia', 'UAE', 'India', 'China', 'Japan', 'South Korea', 'Thailand', 'Indonesia', 'Australia',
      'New Zealand', 'Greece', 'Switzerland', 'Ireland', 'Philippines', 'Vietnam', 'Peru', 'Colombia', 'Chile', 'Iceland',
    ],
  },
  {
    id: 'cities',
    name: 'Famous Cities',
    plus: true,
    words: [
      'New York', 'Los Angeles', 'London', 'Paris', 'Rome', 'Tokyo', 'Dubai', 'Sydney', 'Barcelona', 'Istanbul',
      'Cairo', 'Rio de Janeiro', 'Las Vegas', 'Miami', 'Toronto', 'Berlin', 'Amsterdam', 'Venice', 'Hong Kong', 'Singapore',
      'Bangkok', 'Seoul', 'Mexico City', 'Moscow', 'Athens', 'Lisbon', 'Prague', 'Vienna', 'San Francisco', 'Chicago',
      'Hollywood', 'Mumbai', 'Cape Town', 'Marrakech', 'Bali', 'Honolulu', 'Madrid', 'Buenos Aires', 'Shanghai', 'Kyoto',
    ],
  },
  {
    id: 'landmarks',
    name: 'Landmarks',
    plus: true,
    words: [
      'Eiffel Tower', 'Statue of Liberty', 'Great Wall of China', 'Pyramids of Giza', 'Colosseum', 'Big Ben', 'Taj Mahal', 'Burj Khalifa', 'Sydney Opera House', 'Mount Everest',
      'Niagara Falls', 'Grand Canyon', 'Golden Gate Bridge', 'Machu Picchu', 'Leaning Tower of Pisa', 'Stonehenge', 'Mount Fuji', 'Times Square', 'Hollywood Sign', 'Christ the Redeemer',
      'Petra', 'Sphinx', 'Acropolis', 'Louvre', 'Tower Bridge', 'Empire State Building', 'Disneyland', 'Amazon Rainforest', 'Sahara Desert', 'Northern Lights',
      'Mount Rushmore', 'Buckingham Palace', 'Central Park', 'Venice Canals', 'Great Barrier Reef',
    ],
  },
  {
    id: 'movie-genres',
    name: 'Movie Night',
    plus: true,
    words: [
      'Horror Movie', 'Romantic Comedy', 'Action Movie', 'Cartoon', 'Documentary', 'Superhero Movie', 'Zombie Movie', 'Space Movie', 'Musical', 'Detective Story',
      'Popcorn', 'Movie Ticket', 'Red Carpet', 'Oscar', 'Director', 'Stuntman', 'Sequel', 'Trailer', 'Plot Twist', 'Villain',
      'Sidekick', 'Spoiler', 'Subtitles', '3D Glasses', 'Movie Poster', 'Soundtrack', 'Blooper', 'Remake', 'Happy Ending', 'Cliffhanger',
      'Binge Watching', 'Movie Marathon', 'Drive-in Cinema', 'Film Festival', 'Box Office',
    ],
  },
  {
    id: 'tech',
    name: 'Tech & Gadgets',
    plus: true,
    words: [
      'Smartphone', 'Laptop', 'Tablet', 'Smartwatch', 'Headphones', 'Earbuds', 'Charger', 'Power Bank', 'Keyboard', 'Mouse',
      'Printer', 'Camera', 'Drone', 'Game Console', 'VR Headset', 'Smart Speaker', 'Router', 'USB Stick', 'Selfie Stick', 'Robot Vacuum',
      'Webcam', 'Microphone', 'Projector', 'E-reader', 'Electric Scooter', 'Fitness Tracker', 'Calculator', 'Satellite', 'Hard Drive', 'Ring Light',
      'Wi-Fi', 'Bluetooth', 'Emoji', 'Password', 'Screenshot',
    ],
  },
  {
    id: 'cars',
    name: 'Vehicles',
    plus: true,
    words: [
      'Car', 'Bus', 'Train', 'Airplane', 'Helicopter', 'Bicycle', 'Motorcycle', 'Scooter', 'Truck', 'Taxi',
      'Ambulance', 'Fire Truck', 'Police Car', 'Tractor', 'Submarine', 'Ship', 'Sailboat', 'Canoe', 'Hot Air Balloon', 'Rocket',
      'Limousine', 'Jeep', 'Subway', 'Tram', 'Cable Car', 'Skateboard', 'Jet Ski', 'Golf Cart', 'Monster Truck', 'Race Car',
      'School Bus', 'Camper Van', 'Bulldozer', 'Rickshaw', 'Yacht',
    ],
  },
  {
    id: 'clothes',
    name: 'Clothes & Accessories',
    plus: true,
    words: [
      'T-shirt', 'Jeans', 'Dress', 'Suit', 'Hoodie', 'Jacket', 'Sweater', 'Shorts', 'Skirt', 'Pajamas',
      'Sneakers', 'High Heels', 'Sandals', 'Boots', 'Flip-flops', 'Socks', 'Hat', 'Baseball Cap', 'Scarf', 'Gloves',
      'Sunglasses', 'Watch', 'Necklace', 'Ring', 'Earrings', 'Bracelet', 'Belt', 'Tie', 'Backpack', 'Handbag',
      'Raincoat', 'Swimsuit', 'Bow Tie', 'Wallet', 'Umbrella',
    ],
  },
  {
    id: 'party',
    name: 'Party Time',
    plus: true,
    words: [
      'Birthday Cake', 'Balloons', 'Candles', 'Confetti', 'Party Hat', 'Gift Box', 'DJ', 'Dance Floor', 'Karaoke', 'Photo Booth',
      'Pinata', 'Fireworks', 'Disco Ball', 'Costume Party', 'Pool Party', 'Sleepover', 'Barbecue', 'Wedding', 'Graduation', 'Surprise Party',
      'Party Playlist', 'Snacks Table', 'Invitation', 'Toast', 'Selfie', 'Slow Dance', 'Group Photo', 'Bonfire', 'Glow Sticks', 'Streamers',
      'New Year Countdown', 'Baby Shower', 'Game Night', 'After Party', 'Dress Code',
    ],
  },
  {
    id: 'holidays',
    name: 'Holidays & Seasons',
    plus: true,
    words: [
      'Summer Vacation', 'Winter', 'Snowman', 'Snowball Fight', 'Beach Umbrella', 'Sunscreen', 'Sandcastle', 'Halloween', 'Pumpkin Carving', 'Trick or Treat',
      'New Year', 'Fireworks', 'Valentine', 'Road Trip', 'Camping', 'Ski Trip', 'Autumn Leaves', 'Spring Break', 'Picnic', 'Gift Wrapping',
      'Hot Cocoa', 'Rainy Day', 'Heat Wave', 'Rainbow', 'Thunderstorm', 'Flower Garden', 'Ice Skating', 'Suitcase', 'Passport', 'Souvenir',
      'Postcard', 'Cozy Blanket', 'Fireplace', 'Lemonade Stand', 'Water Park',
    ],
  },
  {
    id: 'transport',
    name: 'Travel',
    plus: true,
    words: [
      'Passport', 'Boarding Pass', 'Suitcase', 'Backpack', 'Hotel Room', 'Hostel', 'Airport Security', 'Jet Lag', 'Window Seat', 'Travel Pillow',
      'Map', 'Compass', 'Tour Bus', 'Cruise', 'Road Trip', 'Gas Station', 'Rest Stop', 'Souvenir Shop', 'Currency Exchange', 'Room Service',
      'Duty Free', 'Lost Luggage', 'Delayed Flight', 'Customs', 'Travel Guide', 'Selfie Spot', 'Beach Resort', 'Camping Tent', 'Train Ticket', 'GPS',
      'Sunburn', 'Postcard', 'Local Food', 'Taxi Line', 'Check-in',
    ],
  },
  {
    id: 'school',
    name: 'School Life',
    plus: true,
    words: [
      'Pencil', 'Eraser', 'Notebook', 'Ruler', 'Backpack', 'Calculator', 'Textbook', 'Whiteboard', 'Chalk', 'Highlighter',
      'Homework', 'Exam', 'Report Card', 'Principal', 'Classroom', 'Cafeteria', 'Playground', 'School Bus', 'Locker', 'Science Lab',
      'Field Trip', 'Recess', 'Detention', 'Graduation', 'School Uniform', 'Library Card', 'Pop Quiz', 'Group Project', 'Summer Break', 'Gym Class',
      'Hall Pass', 'Spelling Bee', 'Yearbook', 'Teacher\'s Pet', 'Class Clown',
    ],
  },
  {
    id: 'apps',
    name: 'Apps & Internet',
    plus: true,
    words: [
      'Selfie', 'Hashtag', 'Meme', 'Emoji', 'Livestream', 'Podcast', 'Influencer', 'Viral Video', 'Story', 'Reel',
      'Group Chat', 'Voice Note', 'Video Call', 'Online Shopping', 'Food Delivery', 'Streaming Service', 'Playlist', 'Translation App', 'Map App', 'Weather App',
      'Password', 'Wi-Fi', 'Notification', 'Unboxing Video', 'Tutorial', 'Comment Section', 'Like Button', 'Unfollow', 'Screenshot', 'Filter',
      'Spam', 'Captcha', 'Dark Mode', 'Low Battery', 'Airplane Mode',
    ],
  },
  {
    id: 'superpowers',
    name: 'Fantasy & Superpowers',
    plus: true,
    words: [
      'Invisibility', 'Flying', 'Time Travel', 'Teleportation', 'Mind Reading', 'Super Strength', 'Dragon', 'Unicorn', 'Wizard', 'Witch',
      'Mermaid', 'Vampire', 'Werewolf', 'Ghost', 'Zombie', 'Alien', 'Robot', 'Pirate', 'Ninja', 'Knight',
      'Magic Wand', 'Treasure Map', 'Haunted House', 'Crystal Ball', 'Potion', 'Flying Carpet', 'Genie', 'Giant', 'Fairy', 'Elf',
      'Spaceship', 'Superhero Cape', 'Secret Agent', 'Time Machine', 'Shapeshifter',
    ],
  },
  {
    id: 'music',
    name: 'Music',
    plus: true,
    words: [
      'Guitar', 'Piano', 'Drums', 'Violin', 'Trumpet', 'Saxophone', 'Flute', 'Harp', 'Ukulele', 'Accordion',
      'Microphone', 'Concert', 'Music Festival', 'Rock Band', 'Rapper', 'Opera', 'Choir', 'Orchestra', 'DJ', 'Karaoke',
      'Headphones', 'Vinyl Record', 'Playlist', 'Music Video', 'Boy Band', 'Lullaby', 'National Anthem', 'Encore', 'Backstage', 'Tour Bus',
      'Beat', 'Chorus', 'Duet', 'Mosh Pit', 'Talent Show',
    ],
  },
  {
    id: 'nature',
    name: 'Nature & Weather',
    plus: true,
    words: [
      'Volcano', 'Waterfall', 'Rainforest', 'Island', 'Cave', 'Glacier', 'Canyon', 'River', 'Lake', 'Ocean',
      'Desert', 'Jungle', 'Meadow', 'Cliff', 'Coral Reef', 'Hurricane', 'Tornado', 'Earthquake', 'Tsunami', 'Avalanche',
      'Rainbow', 'Lightning', 'Snowflake', 'Fog', 'Sunset', 'Sunrise', 'Full Moon', 'Shooting Star', 'Eclipse', 'Hail',
      'Sandstorm', 'Heat Wave', 'Puddle', 'Breeze', 'Tide',
    ],
  },
]

export const CATEGORY_BY_ID = Object.fromEntries(CATEGORIES.map((c) => [c.id, c]))
export const FREE_CATEGORY_IDS = CATEGORIES.filter((c) => !c.plus).map((c) => c.id)
