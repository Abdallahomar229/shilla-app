import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Logo, Cover } from '../components/Art.jsx'
import { Chip } from '../components/ui.jsx'
import { IconCrown, IconGear, IconForward, IconVolume } from '../components/Icons.jsx'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

const GAMES = [
  {
    id: 'outsider',
    title: 'Imposter',
    desc: 'Everyone knows the secret word... except one. Find the Imposter before they guess it.',
    meta: '3–20 players',
    color: 'var(--saffron)',
    img: 'cover_outsider',
  },
  {
    id: 'mafia',
    title: 'Mafia',
    desc: 'Night belongs to the Mafia, day to the town... and the narrator runs it all.',
    meta: '5–20 players',
    extra: 'Narrator voice',
    color: 'var(--crimson)',
    img: 'cover_mafia',
  },
  {
    id: 'truth',
    title: 'Truth or Dare',
    desc: 'Honest questions, fun dares and "Most Likely To" moments that light up the room.',
    meta: '2+ players',
    color: 'var(--mint)',
    img: 'cover_truth',
  },
]

const AVATAR_TONES = ['saffron', 'coral', 'mint', 'lavender']

export default function Home() {
  const { players, plus } = useApp()
  const nav = useNav()
  const go = (name) => {
    sfx.tap()
    nav.navigate({ name })
  }
  return (
    <section className="screen home glow-home">
      <header className="home-top">
        <Logo size={46} />
        <div className="home-actions">
          <button type="button" className={`plus-chip ${plus ? 'active' : ''}`} onClick={() => go('paywall')}>
            <IconCrown size={18} />
            Plus
          </button>
          <button type="button" className="icon-btn" aria-label="Settings" onClick={() => go('settings')}>
            <IconGear />
          </button>
        </div>
      </header>
      <div className="screen-body">
        <div className="screen-inner">
          <p className="tagline">Party games for one phone</p>

          <button type="button" className="players-row" onClick={() => go('players')}>
            <span className="avatars" aria-hidden="true">
              {players.slice(0, 5).map((p, i) => (
                <span key={p.id} className={`avatar tone-${AVATAR_TONES[i % AVATAR_TONES.length]}`}>
                  {p.name.trim().charAt(0)}
                </span>
              ))}
            </span>
            <span className="players-label">Players ({ar(players.length)})</span>
            <span className="players-edit">
              Edit <IconForward size={18} />
            </span>
          </button>

          <div className="games">
            {GAMES.map((g, i) => (
              <button key={g.id} type="button" className={`game-card game-${g.id}`} style={{ '--c': g.color, '--i': i }} onClick={() => go(g.id)}>
                <Cover imgKey={g.img} game={g.id} color={g.color} />
                <span className="game-info">
                  <span className="game-title">{g.title}</span>
                  <span className="game-desc">{g.desc}</span>
                  <span className="game-meta">
                    <Chip>{g.meta}</Chip>
                    {g.extra ? (
                      <Chip tone="crimson" icon={<IconVolume size={14} />}>
                        {g.extra}
                      </Chip>
                    ) : null}
                  </span>
                </span>
              </button>
            ))}
          </div>

          <p className="home-foot">Everything stays on your phone. No accounts, no sign-up.</p>
        </div>
      </div>
    </section>
  )
}
