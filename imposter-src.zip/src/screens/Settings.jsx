import { useRef, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen, Section, Toggle, Segmented, Sheet } from '../components/ui.jsx'
import { IconShield, IconForward, IconTrash, IconInfo, IconVolume } from '../components/Icons.jsx'
import { SHOW_TEST_MODE, APP_VERSION, REVIEW_UNLOCK } from '../lib/config.js'
import { ar } from '../lib/format.js'
import { speak } from '../lib/voice.js'
import { isNativeApp, openTtsSettings } from '../lib/native.js'
import { redeemReviewCode, REVIEW_TAPS } from '../lib/review.js'

function untilText(ts) {
  try {
    return new Date(ts).toLocaleDateString('en-US', { day: 'numeric', month: 'long' })
  } catch {
    return ''
  }
}

export default function Settings() {
  const { settings, setSetting, voiceOk, resetAll, toast, entitled, reviewPlus, reviewUntil, setReviewUntil } = useApp()
  const nav = useNav()
  const [askReset, setAskReset] = useState(false)
  const [askCode, setAskCode] = useState(false)
  const [code, setCode] = useState('')
  const [checking, setChecking] = useState(false)
  const taps = useRef({ n: 0, t: 0 })

  // ٧ دوسات ورا بعض على «الإصدار» بتفتح خانة كود المراجعة
  const onVersionTap = () => {
    if (!REVIEW_UNLOCK) return
    const now = Date.now()
    const r = taps.current
    r.n = now - r.t < 1500 ? r.n + 1 : 1
    r.t = now
    if (r.n >= REVIEW_TAPS) {
      r.n = 0
      setCode('')
      setAskCode(true)
    }
  }

  const submitCode = async (e) => {
    e.preventDefault()
    if (checking) return
    setChecking(true)
    try {
      const res = await redeemReviewCode(code)
      if (res.ok) {
        setReviewUntil(res.until)
        setAskCode(false)
        toast('Plus unlocked for review for 7 days')
      } else if (res.reason === 'unsupported') toast('This feature is not available on this device')
      else toast('That code is not valid')
    } finally {
      setChecking(false)
    }
  }

  return (
    <Screen title="Settings" glow="lavender">
      <Section title="Sound">
        <Toggle id="set-narrator" label="Narrator" hint="A voice that runs the Mafia nights" checked={settings.narrator} onChange={(v) => setSetting('narrator', v)} />
        {voiceOk === false ? <p className="notice soft">This device has no English text-to-speech voice. The lines will show on screen so someone can read them out loud.</p> : null}
        {voiceOk === false && isNativeApp() ? (
          <button type="button" className="btn btn-ghost btn-sm" onClick={openTtsSettings}>
            <IconVolume size={18} /> Download an English voice in phone settings
          </button>
        ) : null}
        <div className="row-field">
          <span className="row-label">
            <span>Narrator speed</span>
          </span>
          <Segmented
            id="narrator-rate"
            label="Narrator speed"
            value={settings.narratorRate}
            onChange={(v) => setSetting('narratorRate', v)}
            options={[
              { value: 0.85, label: 'Slow' },
              { value: 1, label: 'Normal' },
              { value: 1.15, label: 'Fast' },
            ]}
          />
        </div>
        {voiceOk ? (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => speak('Night falls over the town... everyone, close your eyes.', { rate: settings.narratorRate })}>
            <IconVolume size={18} /> Hear the narrator
          </button>
        ) : null}
        <Toggle id="set-sfx" label="Sound effects" checked={settings.sfx} onChange={(v) => setSetting('sfx', v)} />
        <Toggle id="set-vibration" label="Vibration" checked={settings.vibration} onChange={(v) => setSetting('vibration', v)} />
      </Section>

      <Section title="Gameplay">
        <Toggle id="set-reveal" label="Reveal the role of eliminated players" hint="Default setting in Mafia" checked={settings.revealOnExit} onChange={(v) => setSetting('revealOnExit', v)} />
      </Section>

      {SHOW_TEST_MODE ? (
        <Section title="Testing">
          <Toggle
            id="set-test-plus"
            label="Test mode: unlock Plus"
            hint={entitled ? 'Plus is already active' : 'Unlocks every category and role for testing. Not in the store version.'}
            checked={settings.testPlus}
            onChange={(v) => {
              setSetting('testPlus', v)
              toast(v ? 'Test mode on: everything unlocked' : 'Test mode off')
            }}
          />
        </Section>
      ) : null}

      <Section title="About Imposter Night">
        <button type="button" className="list-link" onClick={() => nav.navigate({ name: 'privacy' })}>
          <IconShield size={20} />
          <span>Privacy policy</span>
          <IconForward size={18} />
        </button>
        <div className="list-link static" onClick={onVersionTap} data-testid="version-row">
          <IconInfo size={20} />
          <span>Version {ar(APP_VERSION)}</span>
        </div>
        {reviewPlus && !entitled ? (
          <p className="notice soft">Review code active: Plus is unlocked until {untilText(reviewUntil)}.</p>
        ) : null}
        <button type="button" className="list-link danger" onClick={() => setAskReset(true)}>
          <IconTrash size={20} />
          <span>Erase data</span>
        </button>
      </Section>

      <Sheet open={askReset} title="Erase all data?" onClose={() => setAskReset(false)}>
        <p className="sheet-text">Players, settings and your game choices will be deleted. This cannot be undone.</p>
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" data-autofocus onClick={() => setAskReset(false)}>
            No, keep it
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              resetAll()
              setAskReset(false)
              toast('Everything was erased')
            }}
          >
            Erase
          </button>
        </div>
      </Sheet>

      <Sheet open={askCode} title="Review code" onClose={() => setAskCode(false)}>
        <form className="review-form" onSubmit={submitCode}>
          <p className="sheet-text">
            Enter your code to unlock Plus.
            <span className="review-en" lang="en" dir="ltr">
              Enter your review code to unlock Shilla Plus.
            </span>
          </p>
          <input
            id="review-code"
            className="review-input"
            data-autofocus
            dir="ltr"
            lang="en"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Review code"
            aria-label="Review code"
            autoComplete="off"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            enterKeyHint="done"
            maxLength={40}
          />
          <div className="btn-row">
            <button type="button" className="btn btn-secondary" onClick={() => setAskCode(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={checking || !code.trim()}>
              Activate
            </button>
          </div>
        </form>
      </Sheet>
    </Screen>
  )
}
