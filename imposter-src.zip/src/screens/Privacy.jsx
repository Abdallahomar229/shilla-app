import { Screen } from '../components/ui.jsx'

export default function Privacy() {
  return (
    <Screen title="Privacy Policy" glow="lavender">
      <article className="prose">
        <p>Imposter Night is a party games app that runs on your phone with no accounts and no sign-up.</p>
        <h2>What do we collect?</h2>
        <p>We do not collect anything. Player names and settings are saved only on your device and are never sent to our servers.</p>
        <h2>Ads</h2>
        <p>The free version shows a few Google AdMob ads between rounds. Google may use your device's advertising ID and technical data to show ads, according to Google's privacy policy. Imposter Night Plus removes all ads.</p>
        <h2>Voice</h2>
        <p>The narrator uses your device's built-in text-to-speech engine. We never record your voice or use the microphone.</p>
        <h2>Subscriptions</h2>
        <p>When you subscribe to Plus, payment is handled entirely by Google Play or the App Store. We never see your payment details.</p>
        <h2>Deleting your data</h2>
        <p>You can delete everything at any time from Settings → Erase data, or by uninstalling the app.</p>
        <h2>Children</h2>
        <p>The content is family-friendly, but the app is not directed at children under 13.</p>
        <p className="prose-foot">Last updated: November 2026</p>
      </article>
    </Screen>
  )
}
