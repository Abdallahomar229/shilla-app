import { useState } from 'react'
import { useApp, FREE_PLAYER_LIMIT, MAX_PLAYERS, NAME_MAX } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { IconPlus, IconLock, IconUp, IconDown, IconTrash } from '../components/Icons.jsx'
import { uid } from '../lib/random.js'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

export default function Players() {
  const { players, setPlayers, plus, toast } = useApp()
  const nav = useNav()
  const [draft, setDraft] = useState('')
  const limit = plus ? MAX_PLAYERS : FREE_PLAYER_LIMIT
  const locked = !plus && players.length >= FREE_PLAYER_LIMIT

  const add = () => {
    const name = draft.trim().replace(/\s+/g, ' ').slice(0, NAME_MAX)
    if (locked) {
      nav.navigate({ name: 'paywall' })
      return
    }
    if (!name) return
    if (players.length >= MAX_PLAYERS) {
      toast(`Maximum ${ar(MAX_PLAYERS)} players`)
      return
    }
    if (players.some((p) => p.name.trim() === name)) {
      toast('That name is already taken')
      return
    }
    sfx.tap()
    setPlayers([...players, { id: uid(), name }])
    setDraft('')
  }

  const rename = (id, name) => setPlayers(players.map((p) => (p.id === id ? { ...p, name: name.slice(0, NAME_MAX) } : p)))
  const fixEmpty = (id, i) => {
    const p = players.find((x) => x.id === id)
    if (p && !p.name.trim()) rename(id, `Player ${ar(i + 1)}`)
  }
  const remove = (id) => {
    sfx.tap()
    setPlayers(players.filter((p) => p.id !== id))
  }
  const move = (i, dir) => {
    const j = i + dir
    if (j < 0 || j >= players.length) return
    const next = players.slice()
    ;[next[i], next[j]] = [next[j], next[i]]
    setPlayers(next)
  }

  return (
    <Screen
      title="Players"
      eyebrow={`${ar(players.length)} of ${ar(limit)}`}
      glow="saffron"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={nav.back}>
          Done
        </button>
      }
    >
      <form
        className="add-player"
        onSubmit={(e) => {
          e.preventDefault()
          add()
        }}
      >
        <label htmlFor="new-player" className="sr-only">
          New player name
        </label>
        <input
          id="new-player"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={locked ? 'Free version limit reached' : 'Type a player name'}
          maxLength={NAME_MAX}
          autoComplete="off"
          enterKeyHint="done"
          disabled={locked}
        />
        <button type="submit" className={`btn btn-add ${locked ? 'locked' : ''}`}>
          {locked ? <IconLock size={20} /> : <IconPlus size={20} />}
          {locked ? 'Plus' : 'Add'}
        </button>
      </form>

      {!plus ? (
        <p className="limit-note">
          The free version allows up to {ar(FREE_PLAYER_LIMIT)} players.{' '}
          <button type="button" className="link" onClick={() => nav.navigate({ name: 'paywall' })}>
            Plus allows up to {ar(MAX_PLAYERS)}
          </button>
        </p>
      ) : null}

      {players.length ? (
        <ol className="player-list">
          {players.map((p, i) => (
            <li key={p.id} className="player-row">
              <span className={`player-num ${!plus && i >= FREE_PLAYER_LIMIT ? 'over' : ''}`}>{ar(i + 1)}</span>
              <input
                id={`player-${p.id}`}
                className="player-name"
                value={p.name}
                onChange={(e) => rename(p.id, e.target.value)}
                onBlur={() => fixEmpty(p.id, i)}
                aria-label={`Player ${ar(i + 1)} name`}
                maxLength={NAME_MAX}
                autoComplete="off"
              />
              <span className="row-tools">
                <button type="button" className="icon-btn sm" aria-label={`Move ${p.name} up`} disabled={i === 0} onClick={() => move(i, -1)}>
                  <IconUp size={20} />
                </button>
                <button type="button" className="icon-btn sm" aria-label={`Move ${p.name} down`} disabled={i === players.length - 1} onClick={() => move(i, 1)}>
                  <IconDown size={20} />
                </button>
                <button type="button" className="icon-btn sm danger" aria-label={`Remove ${p.name}`} onClick={() => remove(p.id)}>
                  <IconTrash size={20} />
                </button>
              </span>
            </li>
          ))}
        </ol>
      ) : (
        <p className="empty">Add your friends' names to get started.</p>
      )}
      {!plus && players.length > FREE_PLAYER_LIMIT ? <p className="notice">The free version allows {ar(FREE_PLAYER_LIMIT)} players per game. Remove the extra players or unlock Plus to start.</p> : null}
    </Screen>
  )
}
