import { useEffect, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { Logo } from '../components/Art.jsx'
import { IconClose, IconCheck, IconCrown } from '../components/Icons.jsx'
import { getOfferings, purchase, restore, PLANS } from '../lib/billing.js'
import { nativePlatform } from '../lib/native.js'
import { CATEGORIES } from '../content/categories.js'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

const plusCats = CATEGORIES.filter((c) => c.plus).length
// شروط الاستخدام القياسية (أبل بتطلب لينك ليها جنب أي اشتراك بيتجدد)
const TERMS_URL = 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/'

const BENEFITS = [
  `Every category and word (+${ar(plusCats)} categories)`,
  'Sniper and Jester roles in Mafia',
  'Every Truth or Dare and Most Likely To pack',
  'Up to 20 players per game',
  'No ads at all',
  'New categories regularly',
]

export default function Paywall() {
  const { plus, entitled, reviewPlus, toast, refreshEntitlement } = useApp()
  const nav = useNav()
  const [plan, setPlan] = useState('yearly')
  const [offer, setOffer] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let alive = true
    getOfferings().then((o) => {
      if (alive) setOffer(o)
    })
    return () => {
      alive = false
    }
  }, [])

  const plans = offer?.plans || PLANS.map((p) => ({ ...p, price: null }))

  const buy = async () => {
    setBusy(true)
    try {
      const res = await purchase(plan)
      if (res?.ok) {
        refreshEntitlement()
        sfx.success()
        toast('Welcome to Plus!')
        nav.back()
      } else {
        toast(res?.message || 'The purchase was not completed')
      }
    } finally {
      setBusy(false)
    }
  }

  const doRestore = async () => {
    const res = await restore()
    refreshEntitlement()
    if (res?.ok) toast(res.entitled ? 'Your Plus subscription was restored' : 'No purchases found on this account')
    else toast(res?.message || 'Could not restore purchases right now')
  }

  return (
    <Screen
      title="Plus"
      glow="saffron"
      noBack
      className="paywall"
      right={
        <button type="button" className="icon-btn" aria-label="Close" onClick={nav.back}>
          <IconClose />
        </button>
      }
      actions={
        entitled ? (
          <button type="button" className="btn btn-primary btn-block" onClick={nav.back}>
            Done
          </button>
        ) : (
          <div className="pay-actions">
            <button type="button" className="btn btn-primary btn-block" disabled={busy} onClick={buy}>
              <IconCrown size={20} /> Subscribe to Plus
            </button>
            <button type="button" className="link" onClick={doRestore}>
              Restore purchases
            </button>
          </div>
        )
      }
    >
      <div className="pay-hero">
        <Logo size={40} />
        <strong className="pay-title">Unlock every game and category</strong>
        {plus && !entitled ? (
          <p className="pay-note">{reviewPlus ? 'Review code active: everything is unlocked.' : 'Test mode on: everything is unlocked.'}</p>
        ) : null}
        {entitled ? <p className="pay-note good">Plus is active. Enjoy!</p> : null}
      </div>

      <ul className="benefits">
        {BENEFITS.map((b) => (
          <li key={b}>
            <span className="benefit-check">
              <IconCheck size={16} strokeWidth={3} />
            </span>
            {b}
          </li>
        ))}
      </ul>

      {!entitled ? (
        <div className="plans" role="radiogroup" aria-label="Choose a plan">
          {plans.map((p) => (
            <button
              key={p.id}
              type="button"
              role="radio"
              aria-checked={plan === p.id}
              className={`plan ${plan === p.id ? 'on' : ''}`}
              onClick={() => {
                sfx.tap()
                setPlan(p.id)
              }}
            >
              {p.badge ? <span className="plan-badge">{p.badge}</span> : null}
              <span className="plan-title">{p.title}</span>
              <span className="plan-price">{p.price || 'Price from store'}</span>
              <span className="plan-note">{p.note}</span>
            </button>
          ))}
        </div>
      ) : null}

      {!entitled ? (
        <p className="fine-print">
          {offer && !offer.available ? (offer.native ? 'The store is not available right now, try again later. ' : 'Purchases work in the store version. ') : ''}
          Weekly and yearly plans renew automatically and can be cancelled anytime in your store settings. Lifetime is a one-time payment.
        </p>
      ) : null}
      <p className="fine-print legal-links">
        {nativePlatform() === 'ios' ? (
          <>
            <a href={TERMS_URL} target="_blank" rel="noreferrer">
              Terms of Use
            </a>
            <span aria-hidden="true"> · </span>
          </>
        ) : null}
        <button type="button" className="link" onClick={() => nav.navigate({ name: 'privacy' })}>
          Privacy Policy
        </button>
      </p>
    </Screen>
  )
}
