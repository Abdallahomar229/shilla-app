import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles/fonts.css'
import './styles/app.css'
import App from './App.jsx'
import { initNative } from './lib/native.js'

// لازم قبل ما الواجهة تشتغل: يسجّل صوت الراوي والاهتزاز بتوع أندرويد لو موجودين
initNative()

try {
  document.documentElement.lang = 'en'
  document.documentElement.dir = 'ltr'
} catch {
  /* تجاهل */
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
