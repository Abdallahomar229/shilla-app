// منطق «المافيا» (من غير واجهة)
import { shuffle, pick } from '../../lib/random.js'
import { NARRATION, NIGHT_ORDER, fill } from '../../content/mafia.js'

export const MIN_PLAYERS = 5

export function defaultMafiaCount(n) {
  return Math.max(1, Math.floor(n / 4))
}

export function maxMafiaCount(n) {
  return Math.max(1, Math.floor((n - 1) / 2))
}

export function specialRoles(opts) {
  return ['doctor', 'detective', 'sniper', 'jester'].filter((k) => opts[k])
}

export function composition(n, opts) {
  const mafia = opts.mafia
  const specials = specialRoles(opts)
  const citizens = n - mafia - specials.length
  return { mafia, specials, citizens, valid: n >= MIN_PLAYERS && mafia >= 1 && mafia <= maxMafiaCount(n) && citizens >= 0 }
}

export function assignRoles(players, opts) {
  const ids = shuffle(players.map((p) => p.id))
  const roles = {}
  let i = 0
  for (let k = 0; k < opts.mafia; k++) roles[ids[i++]] = 'mafia'
  specialRoles(opts).forEach((r) => {
    if (i < ids.length) roles[ids[i++]] = r
  })
  while (i < ids.length) roles[ids[i++]] = 'citizen'
  return roles
}

export function aliveIds(alive) {
  return Object.keys(alive).filter((id) => alive[id])
}

export function checkWin(roles, alive) {
  const ids = aliveIds(alive)
  const mafia = ids.filter((id) => roles[id] === 'mafia').length
  if (mafia === 0) return 'town'
  if (mafia >= ids.length - mafia) return 'mafia'
  return null
}

export function resolveNight({ mafiaTarget, doctorSave, sniperTarget }) {
  const deaths = []
  let saved = false
  if (mafiaTarget) {
    if (mafiaTarget === doctorSave) saved = true
    else deaths.push(mafiaTarget)
  }
  if (sniperTarget) {
    if (sniperTarget === doctorSave) saved = true
    else if (!deaths.includes(sniperTarget)) deaths.push(sniperTarget)
  }
  return { deaths, saved }
}

export function line(key, vars) {
  const list = NARRATION[key] || ['']
  return fill(pick(list), vars)
}

// خطوات الليلة: أدوار اللعبة كلها بتتنادي (حتى لو صاحب الدور خرج) عشان محدش يعرف مين لسه موجود
export function buildNight(roles) {
  const inGame = new Set(Object.values(roles))
  const steps = [{ kind: 'narr', key: 'nightStart', text: line('nightStart') }]
  NIGHT_ORDER.forEach((role) => {
    if (!inGame.has(role)) return
    steps.push({ kind: 'role', role, wake: line(`${role}Wake`), sleep: line(`${role}Sleep`) })
  })
  steps.push({ kind: 'narr', key: 'morning', text: line('morning') })
  return steps
}

// هل الدور ده يقدر يلعب الليلة؟
export function canAct(role, roles, alive, sniperUsed) {
  const holders = Object.keys(roles).filter((id) => roles[id] === role && alive[id])
  if (!holders.length) return false
  if (role === 'sniper' && sniperUsed) return false
  return true
}

// مين يظهر في قايمة الاختيار لكل دور
export function targetsFor(role, roles, alive) {
  const ids = aliveIds(alive)
  if (role === 'mafia') return ids.filter((id) => roles[id] !== 'mafia')
  if (role === 'doctor') return ids
  const self = Object.keys(roles).find((id) => roles[id] === role)
  return ids.filter((id) => id !== self)
}
