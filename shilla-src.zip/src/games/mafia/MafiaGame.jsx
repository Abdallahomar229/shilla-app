import { useEffect, useMemo, useReducer, useRef, useState } from 'react'
import { useApp, FREE_PLAYER_LIMIT } from '../../state/app.jsx'
import { useNav, useExitGuard } from '../../state/nav.jsx'
import { Screen, Section, Segmented, Stepper, Toggle, PassPrompt, Progress, TimerRing, useCountdown, Chip } from '../../components/ui.jsx'
import { RoleArt } from '../../components/Art.jsx'
import { IconUsers, IconEye, IconMoon, IconSun, IconVolume, IconPause, IconPlay, IconCheck, IconClose, IconForward, IconTrophy } from '../../components/Icons.jsx'
import { ROLES, ROLE_WAIT_TEXT } from '../../content/mafia.js'
import {
  MIN_PLAYERS,
  defaultMafiaCount,
  maxMafiaCount,
  composition,
  assignRoles,
  checkWin,
  resolveNight,
  line,
  buildNight,
  canAct,
  targetsFor,
} from './logic.js'
import { ar, joinNames } from '../../lib/format.js'
import { load, save } from '../../lib/storage.js'
import { randInt } from '../../lib/random.js'
import { speak, cancel as cancelSpeech } from '../../lib/voice.js'
import { sfx, startNight, stopNight } from '../../lib/sfx.js'
import { adBetweenRounds } from '../../lib/ads.js'
import { buzz, keepAwake } from '../../lib/device.js'

const DEFAULT_CONFIG = { mafia: null, doctor: true, detective: true, sniper: false, jester: false, discussion: 180, revealOnExit: true }

function effectiveOpts(config, n, plus) {
  const auto = defaultMafiaCount(n)
  const mafia = Math.min(Math.max(1, config.mafia ?? auto), maxMafiaCount(n))
  return {
    mafia,
    doctor: !!config.doctor,
    detective: !!config.detective,
    sniper: plus && !!config.sniper,
    jester: plus && !!config.jester,
  }
}

function init() {
  return {
    phase: 'setup',
    config: { ...DEFAULT_CONFIG, ...load('mafia.config', {}) },
    players: [],
    opts: null,
    roles: {},
    alive: {},
    revealIdx: 0,
    revealOpen: false,
    nightNo: 0,
    night: null,
    sniperUsed: false,
    morning: null,
    voteSel: null,
    verdict: null,
    winner: null,
  }
}

function deal(state, players, opts) {
  return {
    ...state,
    phase: 'reveal',
    players,
    opts,
    roles: assignRoles(players, opts),
    alive: Object.fromEntries(players.map((p) => [p.id, true])),
    revealIdx: 0,
    revealOpen: false,
    nightNo: 0,
    night: null,
    sniperUsed: false,
    morning: null,
    voteSel: null,
    verdict: null,
    winner: null,
  }
}

function stepKey(night) {
  return night ? `${night.idx}:${night.sub}` : ''
}

function winLine(winner) {
  if (winner === 'mafia') return line('mafiaWin')
  if (winner === 'town') return line('townWin')
  if (winner === 'jester') return line('jesterWin')
  return ''
}

function reducer(state, a) {
  switch (a.type) {
    case 'config':
      return { ...state, config: { ...state.config, ...a.patch } }
    case 'start':
      return deal(state, a.players, a.opts)
    case 'again':
      return deal(state, state.players, state.opts)
    case 'reveal_open':
      return { ...state, revealOpen: true }
    case 'reveal_next':
      if (state.revealIdx + 1 < state.players.length) return { ...state, revealIdx: state.revealIdx + 1, revealOpen: false }
      return { ...state, phase: 'ready', revealOpen: false }
    case 'night_start': {
      const steps = buildNight(state.roles)
      return {
        ...state,
        phase: 'night',
        nightNo: state.nightNo + 1,
        night: { steps, idx: 0, sub: 'narr', sel: null, picks: {}, hit: null },
        voteSel: null,
        verdict: null,
      }
    }
    case 'night_advance': {
      const n = state.night
      if (!n || a.from !== stepKey(n)) return state
      const step = n.steps[n.idx]
      const nextStep = () => {
        const idx = n.idx + 1
        if (idx >= n.steps.length) return finishNight(state)
        const s = n.steps[idx]
        return { ...state, night: { ...n, idx, sub: s.kind === 'narr' ? 'narr' : 'wake', sel: null, hit: null } }
      }
      if (step.kind === 'narr') return nextStep()
      if (n.sub === 'wake') {
        const able = canAct(step.role, state.roles, state.alive, state.sniperUsed)
        return { ...state, night: { ...n, sub: able ? 'act' : 'wait', sel: null } }
      }
      if (n.sub === 'wait' || n.sub === 'result') return { ...state, night: { ...n, sub: 'sleep' } }
      if (n.sub === 'sleep') return nextStep()
      return state
    }
    case 'night_select':
      return { ...state, night: { ...state.night, sel: a.id } }
    case 'night_confirm': {
      const n = state.night
      const step = n.steps[n.idx]
      if (n.sub !== 'act') return state
      if (step.role === 'sniper' && a.skip) return { ...state, night: { ...n, sub: 'sleep', picks: { ...n.picks, sniper: null } } }
      if (!n.sel) return state
      const picks = { ...n.picks, [step.role]: n.sel }
      if (step.role === 'detective') return { ...state, night: { ...n, picks, sub: 'result', hit: state.roles[n.sel] === 'mafia' } }
      return { ...state, night: { ...n, picks, sub: 'sleep' } }
    }
    case 'to_day':
      return { ...state, phase: 'day' }
    case 'to_vote':
      return { ...state, phase: 'vote', voteSel: null }
    case 'vote_select':
      return { ...state, voteSel: a.id }
    case 'vote_confirm': {
      if (!state.voteSel) return state
      const names = Object.fromEntries(state.players.map((p) => [p.id, p.name]))
      if (state.voteSel === 'none') {
        return { ...state, phase: 'verdict', verdict: { out: null, lines: [line('noVote')] }, winner: null }
      }
      const id = state.voteSel
      const alive = { ...state.alive, [id]: false }
      const lines = [line('voteOut', { name: names[id] })]
      if (state.config.revealOnExit) lines.push(line('revealRole', { role: ROLES[state.roles[id]].name }))
      let winner = null
      if (state.roles[id] === 'jester') winner = 'jester'
      else winner = checkWin(state.roles, alive)
      if (winner) lines.push(winLine(winner))
      return { ...state, phase: 'verdict', alive, verdict: { out: id, lines }, winner }
    }
    case 'to_end':
      return { ...state, phase: 'end' }
    default:
      return state
  }
}

function finishNight(state) {
  const n = state.night
  const { deaths, saved } = resolveNight({ mafiaTarget: n.picks.mafia, doctorSave: n.picks.doctor, sniperTarget: n.picks.sniper })
  const alive = { ...state.alive }
  deaths.forEach((id) => {
    alive[id] = false
  })
  const names = Object.fromEntries(state.players.map((p) => [p.id, p.name]))
  const lines = []
  if (!deaths.length) lines.push(line(saved ? 'saved' : 'quiet'))
  else if (deaths.length === 1) lines.push(line('deathOne', { name: names[deaths[0]] }))
  else lines.push(line('deathMany', { names: joinNames(deaths.map((d) => names[d])) }))
  if (state.config.revealOnExit) deaths.forEach((d) => lines.push(line('revealRole', { role: ROLES[state.roles[d]].name })))
  const winner = checkWin(state.roles, alive)
  if (winner) lines.push(winLine(winner))
  return {
    ...state,
    phase: 'morning',
    alive,
    sniperUsed: state.sniperUsed || !!n.picks.sniper,
    morning: { deaths, saved, lines },
    winner,
    night: { ...n, sub: 'done' },
  }
}

// ينطق جملة (أو أكتر) أول ما الشاشة تظهر
function useNarrate(lines, active, rate) {
  const text = Array.isArray(lines) ? lines.join(' ') : lines
  useEffect(() => {
    if (!active || !text) return undefined
    speak(text, { rate })
    return () => cancelSpeech()
  }, [text, active, rate])
}

export default function MafiaGame() {
  const { players, plus, settings, voiceOk } = useApp()
  const [state, dispatch] = useReducer(reducer, undefined, init)
  const playing = state.phase !== 'setup' && state.phase !== 'end'
  useExitGuard(playing)
  const narrator = !!settings.narrator && voiceOk === true
  const rate = settings.narratorRate || 1

  useEffect(() => {
    save('mafia.config', state.config)
  }, [state.config])

  useEffect(() => {
    keepAwake(state.phase !== 'setup')
    return () => keepAwake(false)
  }, [state.phase])

  useEffect(() => {
    if (state.phase === 'night') startNight()
    else stopNight()
  }, [state.phase])

  useEffect(
    () => () => {
      stopNight()
      cancelSpeech()
    },
    [],
  )

  const byId = useMemo(() => Object.fromEntries(state.players.map((p) => [p.id, p])), [state.players])
  const nameOf = (id) => byId[id]?.name || ''
  const common = { state, dispatch, nameOf, narrator, rate }

  switch (state.phase) {
    case 'setup':
      return <Setup state={state} dispatch={dispatch} players={players} plus={plus} narratorSetting={settings.narrator} voiceOk={voiceOk} />
    case 'reveal':
      return <RoleReveal {...common} />
    case 'ready':
      return <Ready {...common} />
    case 'night':
      return <Night {...common} />
    case 'morning':
      return <Morning {...common} />
    case 'day':
      return <Day {...common} />
    case 'vote':
      return <DayVote {...common} />
    case 'verdict':
      return <Verdict {...common} />
    case 'end':
      return <End {...common} />
    default:
      return null
  }
}

// ───────── الإعداد ─────────
function Setup({ state, dispatch, players, plus, narratorSetting, voiceOk }) {
  const nav = useNav()
  const { setSetting } = useApp()
  const n = players.length
  const opts = effectiveOpts(state.config, n, plus)
  const comp = composition(n, opts)
  const overLimit = !plus && n > FREE_PLAYER_LIMIT
  const tooFew = n < MIN_PLAYERS
  const canStart = comp.valid && !overLimit && !tooFew
  const set = (patch) => dispatch({ type: 'config', patch })
  const toPaywall = () => nav.navigate({ name: 'paywall' })

  const start = () => {
    sfx.drum()
    dispatch({ type: 'start', players, opts })
  }

  return (
    <Screen
      title="المافيا"
      eyebrow="الليل للمافيا… والنهار للمدينة"
      glow="crimson"
      actions={
        <button type="button" className="btn btn-crimson btn-block" disabled={!canStart} onClick={start}>
          وزّع الأدوار
        </button>
      }
    >
      <Section
        title={`اللاعيبة (${ar(n)})`}
        aside={
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => nav.navigate({ name: 'players' })}>
            <IconUsers size={18} /> تعديل
          </button>
        }
      >
        <div className="chips">
          {players.map((p) => (
            <Chip key={p.id}>{p.name}</Chip>
          ))}
        </div>
        {tooFew ? <p className="notice">المافيا محتاجة {ar(MIN_PLAYERS)} لاعيبة على الأقل.</p> : null}
        {overLimit ? (
          <div className="notice">
            النسخة المجانية لحد {ar(FREE_PLAYER_LIMIT)} لاعيبة.
            <button type="button" className="link" onClick={toPaywall}>
              افتح لحد ٢٠ مع شلّة بلس
            </button>
          </div>
        ) : null}
      </Section>

      <Section title="عدد المافيا" hint={tooFew ? null : `المقترح لـ${ar(n)} لاعيبة: ${ar(defaultMafiaCount(n))}`}>
        <Stepper id="mafia-count" label="عدد المافيا" value={opts.mafia} min={1} max={maxMafiaCount(Math.max(n, MIN_PLAYERS))} onChange={(v) => set({ mafia: v })} />
      </Section>

      <Section title="الأدوار">
        <Toggle id="role-doctor" label="الطبيب" hint={ROLES.doctor.short} checked={opts.doctor} onChange={(v) => set({ doctor: v })} />
        <Toggle id="role-detective" label="المحقق" hint={ROLES.detective.short} checked={opts.detective} onChange={(v) => set({ detective: v })} />
        <Toggle id="role-sniper" label="القنّاص" hint={plus ? ROLES.sniper.short : 'مع شلّة بلس'} checked={opts.sniper} locked={!plus} onLocked={toPaywall} onChange={(v) => set({ sniper: v })} />
        <Toggle id="role-jester" label="المهرّج" hint={plus ? ROLES.jester.short : 'مع شلّة بلس'} checked={opts.jester} locked={!plus} onLocked={toPaywall} onChange={(v) => set({ jester: v })} />
        {!tooFew ? (
          <p className={`composition ${comp.valid ? '' : 'bad'}`}>
            {ar(comp.mafia)} مافيا
            {comp.specials.map((k) => `، ${ROLES[k].name}`).join('')}
            {comp.citizens > 0 ? `، ${ar(comp.citizens)} ${comp.citizens === 1 ? 'مواطن' : 'مواطنين'}` : ''}
            {comp.citizens < 0 ? ' — الأدوار أكتر من اللاعيبة' : ''}
          </p>
        ) : null}
      </Section>

      <Section title="وقت النقاش بالنهار">
        <Segmented
          id="discussion-time"
          label="وقت النقاش"
          value={state.config.discussion}
          onChange={(v) => set({ discussion: v })}
          options={[
            { value: 120, label: 'دقيقتين' },
            { value: 180, label: '٣ دقايق' },
            { value: 300, label: '٥ دقايق' },
          ]}
        />
      </Section>

      <Section title="خيارات">
        <Toggle id="reveal-exit" label="اكشف دور اللي يخرج" hint="لما حد يخرج، الكل يعرف كان إيه" checked={state.config.revealOnExit} onChange={(v) => set({ revealOnExit: v })} />
        <Toggle
          id="mafia-narrator"
          label="الراوي"
          hint={voiceOk === false ? 'الجهاز ده مفيهوش صوت عربي — حد يقرا الجمل بصوت عالي' : 'صوت بيدير الليل بدالكم'}
          checked={narratorSetting}
          onChange={(v) => setSetting('narrator', v)}
        />
      </Section>

      <details className="rules">
        <summary>إزاي بنلعب؟</summary>
        <ol>
          <li>الموبايل يلف على الكل، وكل واحد يعرف دوره لوحده.</li>
          <li>بالليل الكل يغمّض، والراوي ينادي كل دور يفتح عينه ويختار من الموبايل.</li>
          <li>بالنهار تتناقشوا وتصوّتوا تطردوا مين.</li>
          <li>المدينة تكسب لو طردت كل المافيا، والمافيا تكسب لو عددها بقى زي باقي المدينة.</li>
        </ol>
      </details>
    </Screen>
  )
}

// ───────── توزيع الأدوار ─────────
function RoleReveal({ state, dispatch, nameOf }) {
  const p = state.players[state.revealIdx]
  const roleKey = state.roles[p.id]
  const role = ROLES[roleKey]
  const mates = roleKey === 'mafia' ? state.players.filter((x) => x.id !== p.id && state.roles[x.id] === 'mafia').map((x) => x.name) : []
  const last = state.revealIdx + 1 >= state.players.length

  return (
    <Screen
      title="الأدوار"
      eyebrow="كل واحد يشوف دوره لوحده"
      glow="crimson"
      actions={
        state.revealOpen ? (
          <button type="button" className="btn btn-secondary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'reveal_next' }) }}>
            {last ? 'خبّي… وكلنا جاهزين' : 'خبّي ومرّر'}
          </button>
        ) : (
          <button
            type="button"
            className="btn btn-crimson btn-block"
            onClick={() => {
              sfx.reveal()
              buzz(roleKey === 'mafia' ? [40, 60, 40] : 25)
              dispatch({ type: 'reveal_open' })
            }}
          >
            <IconEye size={22} /> اكشف دوري
          </button>
        )
      }
    >
      <Progress value={state.revealIdx + 1} total={state.players.length} label="الأدوار" />
      {!state.revealOpen ? (
        <PassPrompt name={nameOf(p.id)} hint="محدش يبص غيره. دورك سر لحد آخر اللعبة." color="var(--crimson)" />
      ) : (
        <div className="role-card" style={{ '--c': role.color }} key={p.id} aria-live="polite">
          <span className="reveal-who">{nameOf(p.id)}</span>
          <RoleArt role={roleKey} color={role.color} />
          <span className="reveal-label">دورك</span>
          <strong className="role-name">{role.name}</strong>
          <p className="role-desc">{role.description}</p>
          {mates.length ? <p className="role-mates">شركاءك في المافيا: {joinNames(mates)}</p> : null}
          {roleKey === 'mafia' && !mates.length ? <p className="role-mates">إنت المافيا الوحيد… خلي بالك.</p> : null}
        </div>
      )}
    </Screen>
  )
}

function Ready({ state, dispatch, narrator, rate }) {
  const text = line('intro')
  const [intro] = useState(text)
  useNarrate(intro, narrator, rate)
  return (
    <Screen
      title="جاهزين؟"
      eyebrow="الأدوار اتوزعت"
      glow="crimson"
      actions={
        <button type="button" className="btn btn-crimson btn-block" onClick={() => dispatch({ type: 'night_start' })}>
          <IconMoon size={20} /> ابدأ الليل
        </button>
      }
    >
      <div className="ready">
        <p className="narration">{intro}</p>
        <ul className="ready-list">
          <li>حطوا الموبايل في النص بحيث الكل يوصله.</li>
          <li>{narrator ? 'الراوي هيقول كل خطوة بصوت عالي.' : 'حد يقرا الجمل اللي على الشاشة بصوت عالي، ويدوس «التالي».'}</li>
          <li>اللي دوره بيتنادي بس هو اللي يفتح عينه ويختار من الموبايل.</li>
        </ul>
      </div>
    </Screen>
  )
}

// ───────── الليل ─────────
function Night({ state, dispatch, nameOf, narrator, rate }) {
  const n = state.night
  const step = n.steps[n.idx]
  const key = stepKey(n)
  const keyRef = useRef(key)
  keyRef.current = key

  const advance = () => dispatch({ type: 'night_advance', from: key })

  // نطق الجملة + تقدّم تلقائي لو الراوي شغال
  const spoken = step.kind === 'narr' ? step.text : n.sub === 'wake' ? step.wake : n.sub === 'sleep' ? step.sleep : ''
  useEffect(() => {
    if (!spoken || !narrator) return undefined
    let alive = true
    const from = key
    speak(spoken, { rate }).then(() => {
      setTimeout(() => {
        if (alive && keyRef.current === from) dispatch({ type: 'night_advance', from })
      }, 650)
    })
    return () => {
      alive = false
    }
  }, [key, spoken, narrator, rate, dispatch])

  // صاحب الدور خرج: نستنى وقت عشوائي ونكمل (عشان محدش يعرف)
  useEffect(() => {
    if (n.sub !== 'wait') return undefined
    const from = key
    const t = setTimeout(() => dispatch({ type: 'night_advance', from }), randInt(5000, 8000))
    return () => clearTimeout(t)
  }, [key, n.sub, dispatch])

  const role = step.kind === 'role' ? ROLES[step.role] : null
  const eyebrow = `الليلة ${ar(state.nightNo)}`

  // شاشة الاختيار
  if (n.sub === 'act') {
    const targets = targetsFor(step.role, state.roles, state.alive)
    const title =
      step.role === 'mafia' ? 'المافيا: مين ضحية الليلة؟' : step.role === 'doctor' ? 'الطبيب: هتنقذ مين؟' : step.role === 'detective' ? 'المحقق: شاكك في مين؟' : 'القنّاص: هتستخدم فرصتك؟'
    return (
      <Screen
        title={role.name}
        eyebrow={eyebrow}
        glow="night"
        className="night-screen"
        actions={
          step.role === 'sniper' ? (
            <div className="btn-row">
              <button type="button" className="btn btn-secondary" onClick={() => { sfx.tap(); dispatch({ type: 'night_confirm', skip: true }) }}>
                مش هضرب الليلة
              </button>
              <button type="button" className="btn btn-crimson" disabled={!n.sel} onClick={() => { sfx.tap(); buzz(20); dispatch({ type: 'night_confirm' }) }}>
                تأكيد
              </button>
            </div>
          ) : (
            <button type="button" className="btn btn-crimson btn-block" disabled={!n.sel} onClick={() => { sfx.tap(); buzz(20); dispatch({ type: 'night_confirm' }) }}>
              تأكيد
            </button>
          )
        }
      >
        <h2 className="ask-title">{title}</h2>
        <div className="vote-grid night" role="radiogroup" aria-label={title}>
          {targets.map((id) => (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={n.sel === id}
              className={`vote-btn ${n.sel === id ? 'on' : ''}`}
              onClick={() => { sfx.tap(); dispatch({ type: 'night_select', id }) }}
            >
              {nameOf(id)}
            </button>
          ))}
        </div>
      </Screen>
    )
  }

  if (n.sub === 'result') {
    const target = n.picks.detective
    return (
      <Screen
        title="المحقق"
        eyebrow={eyebrow}
        glow="night"
        className="night-screen"
        actions={
          <button type="button" className="btn btn-secondary btn-block" onClick={() => { sfx.tap(); advance() }}>
            تمام، عرفت
          </button>
        }
      >
        <div className={`verdict-card ${n.hit ? 'hit' : 'miss'}`} aria-live="polite">
          <span className="verdict-icon">{n.hit ? <IconCheck size={56} strokeWidth={3} /> : <IconClose size={56} strokeWidth={3} />}</span>
          <strong className="verdict-name">{nameOf(target)}</strong>
          <span className="verdict-text">{n.hit ? 'مافيا!' : 'مش مافيا'}</span>
          <p className="big-hint">خلّي المعلومة دي لنفسك.</p>
        </div>
      </Screen>
    )
  }

  // شاشة الراوي (نوم/صحيان/انتظار)
  const text = n.sub === 'wait' ? ROLE_WAIT_TEXT[step.role] : spoken
  const showNext = !narrator && n.sub !== 'wait'
  return (
    <Screen
      title={role ? role.name : step.key === 'morning' ? 'الصبح' : 'الليل'}
      eyebrow={eyebrow}
      glow="night"
      className="night-screen"
      actions={
        showNext ? (
          <button type="button" className="btn btn-secondary btn-block" onClick={() => { sfx.tap(); advance() }}>
            التالي <IconForward size={20} />
          </button>
        ) : null
      }
    >
      <div className="night-stage" key={key}>
        <span className={`night-orb ${step.key === 'morning' ? 'sun' : ''}`} aria-hidden="true">
          {step.key === 'morning' ? <IconSun size={44} /> : <IconMoon size={44} />}
        </span>
        <p className="narration" aria-live="polite">
          {text}
        </p>
        {!narrator && n.sub !== 'wait' ? <p className="read-aloud">اقرا الجملة دي بصوت عالي</p> : null}
        {narrator ? (
          <p className="read-aloud">
            <IconVolume size={16} /> الراوي بيتكلم…
          </p>
        ) : null}
      </div>
    </Screen>
  )
}

// ───────── الصبح ─────────
function Morning({ state, dispatch, nameOf, narrator, rate }) {
  const m = state.morning
  useNarrate(m.lines, narrator, rate)
  useEffect(() => {
    if (m.deaths.length) sfx.fail()
    else sfx.success()
  }, [m.deaths.length])
  return (
    <Screen
      title="طلع الصبح"
      eyebrow={`بعد الليلة ${ar(state.nightNo)}`}
      glow="saffron"
      actions={
        state.winner ? (
          <button type="button" className="btn btn-primary btn-block" onClick={() => dispatch({ type: 'to_end' })}>
            <IconTrophy size={20} /> النتيجة
          </button>
        ) : (
          <button type="button" className="btn btn-primary btn-block" onClick={() => dispatch({ type: 'to_day' })}>
            يلا النقاش
          </button>
        )
      }
    >
      <div className="morning">
        {m.deaths.length ? (
          <div className="out-list">
            {m.deaths.map((id) => (
              <div key={id} className="out-card">
                <strong>{nameOf(id)}</strong>
                <span>خرج من اللعبة</span>
                {state.config.revealOnExit ? <Chip tone="ghost">{ROLES[state.roles[id]].name}</Chip> : null}
              </div>
            ))}
          </div>
        ) : (
          <div className="safe-card">{m.saved ? 'الطبيب أنقذ الضحية!' : 'ليلة هادية… محدش خرج'}</div>
        )}
        <p className="narration small">{m.lines.join(' ')}</p>
        <AliveList state={state} nameOf={nameOf} />
      </div>
    </Screen>
  )
}

function AliveList({ state, nameOf }) {
  const alive = state.players.filter((p) => state.alive[p.id])
  const out = state.players.filter((p) => !state.alive[p.id])
  return (
    <div className="alive">
      <h3>لسه في اللعبة ({ar(alive.length)})</h3>
      <div className="chips">
        {alive.map((p) => (
          <Chip key={p.id}>{nameOf(p.id)}</Chip>
        ))}
      </div>
      {out.length ? (
        <>
          <h3>خرجوا</h3>
          <div className="chips">
            {out.map((p) => (
              <Chip key={p.id} tone="out">
                {nameOf(p.id)}
                {state.config.revealOnExit ? ` (${ROLES[state.roles[p.id]].name})` : ''}
              </Chip>
            ))}
          </div>
        </>
      ) : null}
    </div>
  )
}

// ───────── النهار ─────────
function Day({ state, dispatch, nameOf, narrator, rate }) {
  const [text] = useState(() => line('discussion'))
  useNarrate(text, narrator, rate)
  const [running, setRunning] = useState(true)
  const total = state.config.discussion
  const { left } = useCountdown(total, running)
  return (
    <Screen
      title="النقاش"
      eyebrow={`النهار ${ar(state.nightNo)}`}
      glow="saffron"
      actions={
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" onClick={() => setRunning((r) => !r)} aria-label={running ? 'وقّف الوقت' : 'كمّل الوقت'}>
            {running ? <IconPause size={20} /> : <IconPlay size={20} />} {running ? 'وقّف' : 'كمّل'}
          </button>
          <button type="button" className="btn btn-primary" onClick={() => { sfx.drum(); dispatch({ type: 'to_vote' }) }}>
            خلصنا نقاش
          </button>
        </div>
      }
    >
      <div className="day">
        <TimerRing total={total} left={left} size={156} label="وقت النقاش" />
        <p className="narration small">{text}</p>
        <AliveList state={state} nameOf={nameOf} />
      </div>
    </Screen>
  )
}

function DayVote({ state, dispatch, nameOf, narrator, rate }) {
  const [text] = useState(() => line('voteCall'))
  useNarrate(text, narrator, rate)
  const alive = state.players.filter((p) => state.alive[p.id])
  return (
    <Screen
      title="التصويت"
      eyebrow="ارفعوا إيديكم واتفقوا"
      glow="coral"
      actions={
        <button type="button" className="btn btn-primary btn-block" disabled={!state.voteSel} onClick={() => { sfx.tap(); buzz(25); dispatch({ type: 'vote_confirm' }) }}>
          تأكيد
        </button>
      }
    >
      <h2 className="ask-title">المدينة قررت تطرد مين؟</h2>
      <div className="vote-grid" role="radiogroup" aria-label="المدينة قررت تطرد مين؟">
        {alive.map((p) => (
          <button
            key={p.id}
            type="button"
            role="radio"
            aria-checked={state.voteSel === p.id}
            className={`vote-btn ${state.voteSel === p.id ? 'on' : ''}`}
            onClick={() => { sfx.tap(); dispatch({ type: 'vote_select', id: p.id }) }}
          >
            {nameOf(p.id)}
          </button>
        ))}
        <button
          type="button"
          role="radio"
          aria-checked={state.voteSel === 'none'}
          className={`vote-btn none ${state.voteSel === 'none' ? 'on' : ''}`}
          onClick={() => { sfx.tap(); dispatch({ type: 'vote_select', id: 'none' }) }}
        >
          محدش
        </button>
      </div>
    </Screen>
  )
}

function Verdict({ state, dispatch, nameOf, narrator, rate }) {
  const v = state.verdict
  useNarrate(v.lines, narrator, rate)
  useEffect(() => {
    if (v.out) sfx.drum()
  }, [v.out])
  return (
    <Screen
      title={v.out ? 'القرار' : 'محدش خرج'}
      eyebrow={`النهار ${ar(state.nightNo)}`}
      glow="coral"
      actions={
        state.winner ? (
          <button type="button" className="btn btn-primary btn-block" onClick={() => dispatch({ type: 'to_end' })}>
            <IconTrophy size={20} /> النتيجة
          </button>
        ) : (
          <button type="button" className="btn btn-crimson btn-block" onClick={() => dispatch({ type: 'night_start' })}>
            <IconMoon size={20} /> الليل
          </button>
        )
      }
    >
      <div className="morning">
        {v.out ? (
          <div className="out-card big">
            <strong>{nameOf(v.out)}</strong>
            <span>المدينة طردته</span>
            {state.config.revealOnExit || state.roles[v.out] === 'jester' ? <Chip tone="ghost">{ROLES[state.roles[v.out]].name}</Chip> : null}
          </div>
        ) : (
          <div className="safe-card">المدينة مااتفقتش على حد</div>
        )}
        <p className="narration small">{v.lines.join(' ')}</p>
      </div>
    </Screen>
  )
}

// ───────── النهاية ─────────
function End({ state, dispatch, nameOf, narrator, rate }) {
  const { plus } = useApp()
  const nav = useNav()
  const w = state.winner
  const [text] = useState(() => winLine(w))
  useNarrate(text, narrator, rate)
  useEffect(() => {
    sfx.success()
    buzz([40, 60, 40, 60, 80])
  }, [])
  const title = w === 'mafia' ? 'المافيا كسبت!' : w === 'town' ? 'المدينة كسبت!' : 'المهرّج كسب لوحده!'
  const tone = w === 'mafia' ? 'crimson' : w === 'town' ? 'mint' : 'saffron'
  const order = { mafia: 0, jester: 1, sniper: 2, detective: 3, doctor: 4, citizen: 5 }
  const rows = state.players.slice().sort((a, b) => order[state.roles[a.id]] - order[state.roles[b.id]])
  return (
    <Screen
      title="النتيجة"
      eyebrow={`بعد ${ar(state.nightNo)} ${state.nightNo === 1 ? 'ليلة' : 'ليالي'}`}
      glow={tone}
      onBack={nav.goHome}
      actions={
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" onClick={nav.goHome}>
            الرئيسية
          </button>
          <button type="button" className="btn btn-primary" onClick={async () => { await adBetweenRounds(plus); dispatch({ type: 'again' }) }}>
            العب تاني
          </button>
        </div>
      }
    >
      <div className={`winner winner-${tone}`}>
        <IconTrophy size={40} />
        <strong>{title}</strong>
        <p>{text}</p>
      </div>
      <ul className="roles-list">
        {rows.map((p) => {
          const r = ROLES[state.roles[p.id]]
          return (
            <li key={p.id} className={`roles-row ${state.alive[p.id] ? '' : 'out'}`} style={{ '--c': r.color }}>
              <span className="roles-dot" aria-hidden="true" />
              <span className="roles-name">{nameOf(p.id)}</span>
              <span className="roles-role">{r.name}</span>
              <span className="roles-state">{state.alive[p.id] ? 'لسه موجود' : 'خرج'}</span>
            </li>
          )
        })}
      </ul>
    </Screen>
  )
}
