import { useEffect, useRef, useState } from 'react'
import { useApp } from '../../state/app.jsx'
import { useNav } from '../../state/nav.jsx'
import { Screen, Segmented } from '../../components/ui.jsx'
import { IconLock, IconUsers, IconSkip, IconForward, IconRefresh } from '../../components/Icons.jsx'
import { TRUTH_PACKS, WHO_PACKS } from '../../content/truth.js'
import { shuffle } from '../../lib/random.js'
import { ar } from '../../lib/format.js'
import { load, save } from '../../lib/storage.js'
import { sfx } from '../../lib/sfx.js'
import { adBetweenRounds } from '../../lib/ads.js'
import { buzz, keepAwake } from '../../lib/device.js'

const MODES = { truth: TRUTH_PACKS, who: WHO_PACKS }

export default function TruthGame() {
  const { players, plus } = useApp()
  const nav = useNav()
  const [mode, setMode] = useState(() => load('truth.mode', 'truth'))
  const [packId, setPackId] = useState(null)

  useEffect(() => {
    save('truth.mode', mode)
  }, [mode])

  useEffect(() => {
    keepAwake(!!packId)
    return () => keepAwake(false)
  }, [packId])

  const packs = MODES[mode]
  const pack = packs.find((p) => p.id === packId)

  if (pack) return <Deck key={`${mode}-${pack.id}`} mode={mode} pack={pack} players={players} onChangePack={() => setPackId(null)} />

  const open = (p) => {
    if (p.plus && !plus) {
      nav.navigate({ name: 'paywall' })
      return
    }
    sfx.tap()
    setPackId(p.id)
  }

  return (
    <Screen title="صراحة ومين فينا" eyebrow="اختار الباقة وابدأوا" glow="mint">
      <Segmented
        id="truth-mode"
        label="نوع اللعبة"
        value={mode}
        onChange={(v) => {
          sfx.tap()
          setMode(v)
        }}
        options={[
          { value: 'truth', label: 'صراحة' },
          { value: 'who', label: 'مين فينا؟' },
        ]}
      />
      <p className="mode-hint">{mode === 'truth' ? 'كل واحد في دوره يجاوب على السؤال بصراحة.' : 'السؤال يتقري، والكل يشاور في نفس اللحظة على الشخص المناسب.'}</p>
      <div className="packs">
        {packs.map((p, i) => {
          const locked = p.plus && !plus
          return (
            <button key={p.id} type="button" className={`pack ${locked ? 'locked' : ''}`} style={{ '--i': i }} onClick={() => open(p)} aria-label={locked ? `${p.name} (شلّة بلس)` : p.name}>
              <span className="pack-main">
                <span className="pack-name">{p.name}</span>
                <span className="pack-blurb">{p.blurb}</span>
              </span>
              <span className="pack-side">
                {locked ? <IconLock size={20} /> : <span className="pack-count">{ar(p.questions.length)}</span>}
                <small>{locked ? 'بلس' : 'سؤال'}</small>
              </span>
            </button>
          )
        })}
      </div>
      {mode === 'truth' && players.length < 2 ? (
        <div className="notice">
          صراحة محتاجة لاعبين على الأقل.
          <button type="button" className="link" onClick={() => nav.navigate({ name: 'players' })}>
            ضيف اللاعيبة
          </button>
        </div>
      ) : null}
    </Screen>
  )
}

function Deck({ mode, pack, players, onChangePack }) {
  const { plus } = useApp()
  const nav = useNav()
  const [order, setOrder] = useState(() => shuffle(pack.questions.map((_, i) => i)))
  const [pos, setPos] = useState(0)
  const [turn, setTurn] = useState(0)
  const [count, setCount] = useState(null) // عدّاد «مين فينا»
  const timer = useRef(null)
  const done = pos >= order.length
  const isTruth = mode === 'truth'
  const tooFew = isTruth && players.length < 2

  useEffect(() => () => clearInterval(timer.current), [])

  const next = () => {
    sfx.tap()
    setCount(null)
    clearInterval(timer.current)
    setPos((p) => p + 1)
    if (isTruth && players.length) setTurn((t) => (t + 1) % players.length)
  }
  const skip = () => {
    sfx.tap()
    setPos((p) => p + 1)
  }
  const restart = async () => {
    sfx.tap()
    await adBetweenRounds(plus)
    setOrder(shuffle(pack.questions.map((_, i) => i)))
    setPos(0)
  }
  const countdown = () => {
    if (count !== null) return
    setCount(3)
    sfx.tick()
    let n = 3
    timer.current = setInterval(() => {
      n -= 1
      if (n > 0) {
        sfx.tick()
        setCount(n)
      } else {
        clearInterval(timer.current)
        setCount(0)
        sfx.success()
        buzz([30, 40, 30])
      }
    }, 800)
  }

  const q = !done ? pack.questions[order[pos]] : null
  const who = isTruth && players.length ? players[turn % players.length] : null

  let actions
  if (done) {
    actions = (
      <div className="btn-row">
        <button type="button" className="btn btn-secondary" onClick={onChangePack}>
          باقة تانية
        </button>
        <button type="button" className="btn btn-mint" onClick={restart}>
          <IconRefresh size={20} /> نعيدها
        </button>
      </div>
    )
  } else if (isTruth) {
    actions = (
      <div className="btn-row">
        <button type="button" className="btn btn-secondary" onClick={skip}>
          <IconSkip size={18} /> تخطّي
        </button>
        <button type="button" className="btn btn-mint" onClick={next} disabled={tooFew}>
          التالي <IconForward size={20} />
        </button>
      </div>
    )
  } else {
    actions = (
      <div className="btn-row">
        <button type="button" className="btn btn-secondary" onClick={countdown} disabled={count !== null && count > 0}>
          ١… ٢… ٣ شاوروا!
        </button>
        <button type="button" className="btn btn-mint" onClick={next}>
          التالي <IconForward size={20} />
        </button>
      </div>
    )
  }

  return (
    <Screen
      title={pack.name}
      eyebrow={isTruth ? 'صراحة' : 'مين فينا؟'}
      glow="mint"
      onBack={onChangePack}
      right={
        <button type="button" className="btn btn-ghost btn-sm" onClick={onChangePack}>
          الباقات
        </button>
      }
      actions={actions}
    >
      {done ? (
        <div className="deck-done">
          <strong>خلصت الباقة!</strong>
          <p>جاوبتوا على كل الأسئلة. تحبوا نعيدها بترتيب جديد ولا نجرب باقة تانية؟</p>
        </div>
      ) : (
        <>
          <div className="deck-top">
            {who ? (
              <span className="turn">
                دور <strong>{who.name}</strong>
              </span>
            ) : (
              <span className="turn">الكل يشاور مع بعض</span>
            )}
            <span className="deck-count">
              {ar(pos + 1)} / {ar(order.length)}
            </span>
          </div>
          <div className={`q-card ${isTruth ? '' : 'who'}`} key={pos}>
            <p className="q-text">{q}</p>
            {!isTruth && count !== null ? <span className={`count ${count === 0 ? 'go' : ''}`} aria-live="assertive">{count === 0 ? 'شاوروا!' : ar(count)}</span> : null}
          </div>
          {tooFew ? (
            <div className="notice">
              ضيف لاعبين على الأقل عشان الأدوار.
              <button type="button" className="link" onClick={() => nav.navigate({ name: 'players' })}>
                <IconUsers size={16} /> اللاعيبة
              </button>
            </div>
          ) : null}
        </>
      )}
    </Screen>
  )
}
