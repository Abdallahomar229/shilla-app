import { useEffect, useMemo, useReducer } from 'react'
import { useApp, FREE_PLAYER_LIMIT } from '../../state/app.jsx'
import { useNav, useExitGuard } from '../../state/nav.jsx'
import { Screen, Section, Segmented, PassPrompt, Progress, TimerRing, useCountdown, Chip } from '../../components/ui.jsx'
import { IconLock, IconShuffle, IconEye, IconUsers, IconForward } from '../../components/Icons.jsx'
import { CATEGORIES } from '../../content/categories.js'
import { RANDOM, makeRound, makePairs, tallyVotes, caughtMap, scoreRound } from './logic.js'
import { ar, joinNames } from '../../lib/format.js'
import { load, save } from '../../lib/storage.js'
import { sfx } from '../../lib/sfx.js'
import { adBetweenRounds } from '../../lib/ads.js'
import { buzz, keepAwake } from '../../lib/device.js'

const DEFAULT_CONFIG = { outsiders: 1, cats: [RANDOM], timer: 0 }
const MIN_PLAYERS = 3

const fresh = {
  revealIdx: 0,
  revealOpen: false,
  pairIdx: 0,
  qRound: 1,
  voteIdx: 0,
  voteOpen: false,
  voteSel: null,
  votes: {},
  tally: {},
  caught: {},
  guessIdx: 0,
  guessPick: null,
  guesses: {},
  deltas: {},
}

function init() {
  return {
    phase: 'setup',
    config: { ...DEFAULT_CONFIG, ...load('outsider.config', {}) },
    players: [],
    round: null,
    scores: {},
    used: {},
    roundNo: 0,
  }
}

function reducer(state, a) {
  const r = state.round
  switch (a.type) {
    case 'config':
      return { ...state, config: { ...state.config, ...a.patch } }
    case 'start': {
      const { round, used } = makeRound({ players: a.players, config: state.config, plus: a.plus, used: state.used, roundNo: state.roundNo })
      const scores = a.keepScores ? state.scores : Object.fromEntries(a.players.map((p) => [p.id, 0]))
      return { ...state, phase: 'reveal', players: a.players, round: { ...round, ...fresh }, used, roundNo: state.roundNo + 1, scores }
    }
    case 'reveal_open':
      return { ...state, round: { ...r, revealOpen: true } }
    case 'reveal_next':
      if (r.revealIdx + 1 < r.order.length) return { ...state, round: { ...r, revealIdx: r.revealIdx + 1, revealOpen: false } }
      return { ...state, phase: 'questions', round: { ...r, revealOpen: false, pairIdx: 0 } }
    case 'pair_next':
      return { ...state, round: { ...r, pairIdx: Math.min(r.pairIdx + 1, r.pairs.length - 1) } }
    case 'questions_again':
      return { ...state, round: { ...r, pairs: makePairs(state.players.map((p) => p.id)), pairIdx: 0, qRound: r.qRound + 1 } }
    case 'to_vote':
      return { ...state, phase: 'vote', round: { ...r, voteIdx: 0, voteOpen: false, voteSel: null, votes: {} } }
    case 'vote_open':
      return { ...state, round: { ...r, voteOpen: true, voteSel: null } }
    case 'vote_select':
      return { ...state, round: { ...r, voteSel: a.id } }
    case 'vote_confirm': {
      if (!r.voteSel) return state
      const voter = r.order[r.voteIdx]
      const votes = { ...r.votes, [voter]: r.voteSel }
      if (r.voteIdx + 1 < r.order.length) return { ...state, round: { ...r, votes, voteIdx: r.voteIdx + 1, voteOpen: false, voteSel: null } }
      const ids = state.players.map((p) => p.id)
      const tally = tallyVotes(ids, votes)
      return { ...state, phase: 'results', round: { ...r, votes, tally, caught: caughtMap(r.outsiders, tally), voteOpen: false, voteSel: null } }
    }
    case 'to_unmask':
      return { ...state, phase: 'unmask' }
    case 'to_guess':
      return { ...state, phase: 'guess', round: { ...r, guessIdx: 0, guessPick: null } }
    case 'guess_pick': {
      if (r.guessPick) return state
      const o = r.outsiders[r.guessIdx]
      return { ...state, round: { ...r, guessPick: a.word, guesses: { ...r.guesses, [o]: { choice: a.word, correct: a.word === r.word } } } }
    }
    case 'guess_next': {
      if (r.guessIdx + 1 < r.outsiders.length) return { ...state, round: { ...r, guessIdx: r.guessIdx + 1, guessPick: null } }
      const ids = state.players.map((p) => p.id)
      const deltas = scoreRound({ ids, outsiders: r.outsiders, votes: r.votes, caught: r.caught, guesses: r.guesses })
      const scores = { ...state.scores }
      ids.forEach((id) => {
        scores[id] = (scores[id] || 0) + deltas[id]
      })
      return { ...state, phase: 'score', scores, round: { ...r, deltas } }
    }
    default:
      return state
  }
}

export default function OutsiderGame() {
  const { players, plus } = useApp()
  const [state, dispatch] = useReducer(reducer, undefined, init)
  const playing = state.phase !== 'setup' && state.phase !== 'score'
  useExitGuard(playing)

  useEffect(() => {
    save('outsider.config', state.config)
  }, [state.config])

  useEffect(() => {
    keepAwake(state.phase !== 'setup')
    return () => keepAwake(false)
  }, [state.phase])

  const byId = useMemo(() => Object.fromEntries(state.players.map((p) => [p.id, p])), [state.players])
  const nameOf = (id) => byId[id]?.name || ''

  const start = (keepScores = false) => {
    sfx.drum()
    dispatch({ type: 'start', players: keepScores ? state.players : players, plus, keepScores })
  }

  switch (state.phase) {
    case 'setup':
      return <Setup state={state} dispatch={dispatch} players={players} plus={plus} onStart={() => start(false)} />
    case 'reveal':
      return <Reveal state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'questions':
      return <Questions key={state.round.qRound} state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'vote':
      return <Vote state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'results':
      return <Results state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'unmask':
      return <Unmask state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'guess':
      return <Guess state={state} dispatch={dispatch} nameOf={nameOf} />
    case 'score':
      return <Score state={state} nameOf={nameOf} onAgain={async () => { await adBetweenRounds(plus); start(true) }} />
    default:
      return null
  }
}

// ───────── الإعداد ─────────
function Setup({ state, dispatch, players, plus, onStart }) {
  const nav = useNav()
  const n = players.length
  const overLimit = !plus && n > FREE_PLAYER_LIMIT
  const tooFew = n < MIN_PLAYERS
  const allowed = (c) => plus || !c.plus
  const selected = state.config.cats.filter((id) => id === RANDOM || CATEGORIES.some((c) => c.id === id && allowed(c)))
  const cats = selected.length ? selected : [RANDOM]
  const twoAllowed = n >= 7
  const outsiders = state.config.outsiders === 2 && twoAllowed ? 2 : 1

  const toggleCat = (cat) => {
    if (cat && !allowed(cat)) {
      nav.navigate({ name: 'paywall' })
      return
    }
    if (!cat) {
      dispatch({ type: 'config', patch: { cats: [RANDOM] } })
      return
    }
    let next = cats.filter((c) => c !== RANDOM)
    next = next.includes(cat.id) ? next.filter((c) => c !== cat.id) : [...next, cat.id]
    dispatch({ type: 'config', patch: { cats: next.length ? next : [RANDOM] } })
  }

  const canStart = !tooFew && !overLimit
  return (
    <Screen
      title="برا السالفة"
      eyebrow="كلكم عارفين السالفة… إلا واحد"
      glow="saffron"
      actions={
        <button type="button" className="btn btn-primary btn-block" disabled={!canStart} onClick={onStart}>
          ابدأ الجولة
        </button>
      }
    >
      <Section
        title={`اللاعيبة (${ar(n)})`}
        aside={
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => nav.navigate({ name: 'players' })}>
            <IconUsers size={18} /> تعديل
          </button>
        }
      >
        <div className="chips">
          {players.map((p) => (
            <Chip key={p.id}>{p.name}</Chip>
          ))}
        </div>
        {tooFew ? <p className="notice">محتاجين {ar(MIN_PLAYERS)} لاعيبة على الأقل.</p> : null}
        {overLimit ? (
          <div className="notice">
            النسخة المجانية لحد {ar(FREE_PLAYER_LIMIT)} لاعيبة.
            <button type="button" className="link" onClick={() => nav.navigate({ name: 'paywall' })}>
              افتح لحد ٢٠ مع شلّة بلس
            </button>
          </div>
        ) : null}
      </Section>

      <Section title="كام واحد برا السالفة؟">
        <Segmented
          id="outsiders-count"
          label="عدد اللي برا السالفة"
          value={outsiders}
          onChange={(v) => dispatch({ type: 'config', patch: { outsiders: v } })}
          options={[
            { value: 1, label: 'واحد' },
            { value: 2, label: twoAllowed ? 'اتنين' : 'اتنين (من ٧ لاعيبة)', disabled: !twoAllowed },
          ]}
        />
      </Section>

      <Section title="الأقسام" hint="اختار قسم أو أكتر، أو سيبها عشوائي.">
        <div className="cat-grid">
          <button type="button" className={`cat-tile random ${cats.includes(RANDOM) ? 'on' : ''}`} aria-pressed={cats.includes(RANDOM)} onClick={() => toggleCat(null)}>
            <IconShuffle size={20} />
            <span>عشوائي</span>
          </button>
          {CATEGORIES.map((c) => {
            const locked = !allowed(c)
            const on = cats.includes(c.id)
            return (
              <button
                key={c.id}
                type="button"
                className={`cat-tile ${on ? 'on' : ''} ${locked ? 'locked' : ''}`}
                aria-pressed={on}
                aria-label={locked ? `${c.name} (شلّة بلس)` : c.name}
                onClick={() => toggleCat(c)}
              >
                <span>{c.name}</span>
                {locked ? <IconLock size={16} /> : <small>{ar(c.words.length)}</small>}
              </button>
            )
          })}
        </div>
      </Section>

      <Section title="مؤقت الأسئلة">
        <Segmented
          id="question-timer"
          label="مؤقت الأسئلة"
          value={state.config.timer}
          onChange={(v) => dispatch({ type: 'config', patch: { timer: v } })}
          options={[
            { value: 0, label: 'بدون' },
            { value: 60, label: 'دقيقة' },
            { value: 90, label: 'دقيقة ونص' },
            { value: 120, label: 'دقيقتين' },
          ]}
        />
      </Section>

      <details className="rules">
        <summary>إزاي بنلعب؟</summary>
        <ol>
          <li>الموبايل يلف على الكل: كل واحد يشوف السالفة لوحده… إلا اللي برا السالفة.</li>
          <li>كل لاعب يسأل لاعب تاني سؤال عن السالفة من غير ما يفضحها.</li>
          <li>كل واحد يصوّت سرًا على اللي شاكك إنه برا السالفة.</li>
          <li>اللي برا السالفة يحاول يخمّن الكلمة عشان ياخد نقط زيادة.</li>
        </ol>
      </details>
    </Screen>
  )
}

// ───────── كشف السالفة ─────────
function Reveal({ state, dispatch, nameOf }) {
  const r = state.round
  const id = r.order[r.revealIdx]
  const isOut = r.outsiders.includes(id)
  const last = r.revealIdx + 1 >= r.order.length

  const open = () => {
    sfx.reveal()
    buzz(isOut ? [40, 60, 40] : 25)
    dispatch({ type: 'reveal_open' })
  }

  return (
    <Screen
      title="برا السالفة"
      eyebrow="كشف السالفة"
      glow="saffron"
      actions={
        r.revealOpen ? (
          <button type="button" className="btn btn-secondary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'reveal_next' }) }}>
            {last ? 'خبّي… ويلا نبدأ الأسئلة' : 'خبّي ومرّر'}
          </button>
        ) : (
          <button type="button" className="btn btn-primary btn-block" onClick={open}>
            <IconEye size={22} /> اكشف
          </button>
        )
      }
    >
      <Progress value={r.revealIdx + 1} total={r.order.length} label="مين شاف" />
      {!r.revealOpen ? (
        <PassPrompt name={nameOf(id)} hint="محدش يبص غيره. أول ما يمسك الموبايل يدوس «اكشف»." />
      ) : (
        <div className={`reveal-card ${isOut ? 'is-out' : ''}`} key={id} aria-live="polite">
          <span className="reveal-who">{nameOf(id)}</span>
          {isOut ? (
            <>
              <span className="reveal-label">إنت</span>
              <strong className="reveal-big">برا السالفة!</strong>
              <p className="reveal-hint">اسمعهم كويس وحاول تعرف السالفة من غير ما تتكشف</p>
            </>
          ) : (
            <>
              <span className="reveal-label">السالفة</span>
              <strong className="reveal-big">{r.word}</strong>
              <p className="reveal-hint">متقولش الكلمة! اسأل وجاوب بذكاء عشان تكشفوا اللي برا السالفة</p>
            </>
          )}
          <Chip tone="ghost">القسم: {r.catName}</Chip>
        </div>
      )}
    </Screen>
  )
}

// ───────── الأسئلة ─────────
function Questions({ state, dispatch, nameOf }) {
  const r = state.round
  const [asker, target] = r.pairs[r.pairIdx]
  const total = state.config.timer
  const { left } = useCountdown(total, total > 0)
  const last = r.pairIdx + 1 >= r.pairs.length

  return (
    <Screen
      title="وقت الأسئلة"
      eyebrow={`جولة الأسئلة ${ar(r.qRound)}، القسم: ${r.catName}`}
      glow="saffron"
      actions={
        last ? (
          <div className="btn-row">
            <button type="button" className="btn btn-secondary" onClick={() => { sfx.tap(); dispatch({ type: 'questions_again' }) }}>
              جولة أسئلة كمان
            </button>
            <button type="button" className="btn btn-primary" onClick={() => { sfx.drum(); dispatch({ type: 'to_vote' }) }}>
              يلا نصوّت
            </button>
          </div>
        ) : (
          <div className="btn-row">
            <button type="button" className="btn btn-ghost" onClick={() => { sfx.drum(); dispatch({ type: 'to_vote' }) }}>
              نصوّت على طول
            </button>
            <button type="button" className="btn btn-primary" onClick={() => { sfx.tap(); dispatch({ type: 'pair_next' }) }}>
              التالي <IconForward size={20} />
            </button>
          </div>
        )
      }
    >
      {total > 0 ? (
        <div className="timer-wrap">
          <TimerRing total={total} left={left} size={112} label="وقت جولة الأسئلة" />
        </div>
      ) : null}
      <div className="qa-card" key={`${r.qRound}-${r.pairIdx}`}>
        <span className="qa-verb">السؤال من</span>
        <strong className="qa-asker">{nameOf(asker)}</strong>
        <span className="qa-verb">إلى</span>
        <strong className="qa-target">{nameOf(target)}</strong>
      </div>
      <p className="big-hint">سؤال واحد عن السالفة… من غير ما تفضحها!</p>
      <Progress value={r.pairIdx + 1} total={r.pairs.length} label="الأسئلة" />
    </Screen>
  )
}

// ───────── التصويت ─────────
function Vote({ state, dispatch, nameOf }) {
  const r = state.round
  const voter = r.order[r.voteIdx]
  const candidates = state.players.filter((p) => p.id !== voter)

  return (
    <Screen
      title="التصويت"
      eyebrow="كل واحد يصوّت لوحده"
      glow="coral"
      actions={
        r.voteOpen ? (
          <button type="button" className="btn btn-primary btn-block" disabled={!r.voteSel} onClick={() => { sfx.tap(); buzz(20); dispatch({ type: 'vote_confirm' }) }}>
            تأكيد التصويت
          </button>
        ) : (
          <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'vote_open' }) }}>
            صوّت
          </button>
        )
      }
    >
      <Progress value={r.voteIdx + 1} total={r.order.length} label="التصويت" />
      {!r.voteOpen ? (
        <PassPrompt lead="دور التصويت" name={nameOf(voter)} hint="مرّر الموبايل وخلّي صوتك سر." color="var(--coral)" />
      ) : (
        <>
          <h2 className="ask-title">{nameOf(voter)}، مين برا السالفة؟</h2>
          <div className="vote-grid" role="radiogroup" aria-label="اختار اللاعب">
            {candidates.map((p) => (
              <button
                key={p.id}
                type="button"
                role="radio"
                aria-checked={r.voteSel === p.id}
                className={`vote-btn ${r.voteSel === p.id ? 'on' : ''}`}
                onClick={() => { sfx.tap(); dispatch({ type: 'vote_select', id: p.id }) }}
              >
                {p.name}
              </button>
            ))}
          </div>
        </>
      )}
    </Screen>
  )
}

// ───────── نتيجة التصويت ─────────
function Results({ state, dispatch, nameOf }) {
  const r = state.round
  const rows = Object.entries(r.tally).sort((a, b) => b[1] - a[1])
  const max = Math.max(1, ...rows.map(([, v]) => v))
  return (
    <Screen
      title="نتيجة التصويت"
      eyebrow="الأصوات اتجمعت"
      glow="coral"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.drum(); buzz([30, 50, 30]); dispatch({ type: 'to_unmask' }) }}>
          اكشف اللي برا السالفة
        </button>
      }
    >
      <ul className="bars">
        {rows.map(([id, v], i) => (
          <li key={id} className="bar-row" style={{ '--i': i }}>
            <span className="bar-name">{nameOf(id)}</span>
            <span className="bar-track">
              <span className="bar-fill" style={{ width: `${(v / max) * 100}%` }} />
            </span>
            <span className="bar-count">{ar(v)}</span>
          </li>
        ))}
      </ul>
    </Screen>
  )
}

// ───────── الكشف ─────────
function Unmask({ state, dispatch, nameOf }) {
  const r = state.round
  const names = r.outsiders.map(nameOf)
  const allCaught = r.outsiders.every((o) => r.caught[o])
  const noneCaught = r.outsiders.every((o) => !r.caught[o])
  useEffect(() => {
    if (allCaught) sfx.success()
    else sfx.fail()
  }, [allCaught])
  const first = r.outsiders[0]
  return (
    <Screen
      title="الحقيقة"
      eyebrow="اللحظة الحاسمة"
      glow="coral"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={() => { sfx.tap(); dispatch({ type: 'to_guess' }) }}>
          {r.outsiders.length > 1 ? 'يلا يخمّنوا السالفة' : `${nameOf(first)} يخمّن السالفة`}
        </button>
      }
    >
      <div className="unmask">
        <span className="unmask-lead">{r.outsiders.length > 1 ? 'اللي كانوا برا السالفة' : 'اللي كان برا السالفة'}</span>
        <strong className="unmask-names">{joinNames(names)}</strong>
        <p className={`unmask-status ${allCaught ? 'good' : 'bad'}`}>
          {allCaught ? (r.outsiders.length > 1 ? 'الشلّة كشفتهم الاتنين!' : 'الشلّة كشفته!') : noneCaught ? (r.outsiders.length > 1 ? 'الاتنين عدّوها عليكم!' : 'عدّاها عليكم!') : 'كشفتوا واحد… والتاني عدّاها!'}
        </p>
        <p className="big-hint">لسه في فرصة: لو خمّن السالفة ياخد نقطتين زيادة.</p>
      </div>
    </Screen>
  )
}

// ───────── التخمين ─────────
function Guess({ state, dispatch, nameOf }) {
  const r = state.round
  const o = r.outsiders[r.guessIdx]
  const pickW = (w) => {
    if (r.guessPick) return
    if (w === r.word) {
      sfx.success()
      buzz([30, 40, 30])
    } else {
      sfx.fail()
      buzz(120)
    }
    dispatch({ type: 'guess_pick', word: w })
  }
  const lastOut = r.guessIdx + 1 >= r.outsiders.length
  const correct = r.guessPick === r.word
  return (
    <Screen
      title="خمّن السالفة"
      eyebrow={`القسم: ${r.catName}`}
      glow="saffron"
      actions={
        r.guessPick ? (
          <button type="button" className="btn btn-primary btn-block" onClick={() => dispatch({ type: 'guess_next' })}>
            {lastOut ? 'شوف النقط' : 'اللي بعده'}
          </button>
        ) : null
      }
    >
      <h2 className="ask-title">{nameOf(o)}، السالفة كانت إيه؟</h2>
      <div className="guess-grid">
        {r.options.map((w) => {
          const state2 = !r.guessPick ? '' : w === r.word ? 'right' : w === r.guessPick ? 'wrong' : 'dim'
          return (
            <button key={w} type="button" className={`guess-btn ${state2}`} disabled={!!r.guessPick} onClick={() => pickW(w)}>
              {w}
            </button>
          )
        })}
      </div>
      {r.guessPick ? (
        <p className={`guess-result ${correct ? 'good' : 'bad'}`} aria-live="polite">
          {correct ? 'صح! خمّنها' : `لأ… السالفة كانت «${r.word}»`}
        </p>
      ) : null}
    </Screen>
  )
}

// ───────── النقط ─────────
function Score({ state, nameOf, onAgain }) {
  const nav = useNav()
  const r = state.round
  const rows = state.players.map((p) => ({ id: p.id, total: state.scores[p.id] || 0, delta: r.deltas[p.id] || 0 })).sort((a, b) => b.total - a.total || b.delta - a.delta)
  return (
    <Screen
      title="النقط"
      eyebrow={`الجولة ${ar(state.roundNo)}، والسالفة كانت «${r.word}»`}
      glow="saffron"
      onBack={nav.goHome}
      actions={
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" onClick={nav.goHome}>
            إنهاء
          </button>
          <button type="button" className="btn btn-primary" onClick={onAgain}>
            جولة جديدة
          </button>
        </div>
      }
    >
      <ol className="scoreboard">
        {rows.map((row, i) => (
          <li key={row.id} className={`score-row ${i === 0 && row.total > 0 ? 'lead' : ''}`} style={{ '--i': i }}>
            <span className="score-rank">{ar(i + 1)}</span>
            <span className="score-name">
              {nameOf(row.id)}
              {r.outsiders.includes(row.id) ? <small>برا السالفة</small> : null}
            </span>
            {row.delta > 0 ? <span className="score-delta">+{ar(row.delta)}</span> : <span className="score-delta zero">٠</span>}
            <span className="score-total">{ar(row.total)}</span>
          </li>
        ))}
      </ol>
      <p className="big-hint">كل اللي صوّت صح ياخد نقطة. اللي برا السالفة ياخد نقطتين لو مااتكشفش، ونقطتين لو خمّن السالفة.</p>
    </Screen>
  )
}
