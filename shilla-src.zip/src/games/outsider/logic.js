// منطق «برا السالفة» (من غير واجهة) عشان يبقى سهل نختبره
import { CATEGORIES, CATEGORY_BY_ID } from '../../content/categories.js'
import { pick, sample, shuffle } from '../../lib/random.js'

export const RANDOM = 'random'

export function availableCategoryIds(plus) {
  return CATEGORIES.filter((c) => plus || !c.plus).map((c) => c.id)
}

// الأقسام اللي هنختار منها فعلًا
export function resolvePool(selected, plus) {
  const allowed = new Set(availableCategoryIds(plus))
  const chosen = (selected || []).filter((id) => id !== RANDOM && allowed.has(id))
  if (!chosen.length) return [...allowed]
  return chosen
}

// كل لاعب يسأل لاعب تاني مرة واحدة، وكل لاعب يتسأل مرة واحدة، ومحدش يسأل نفسه
export function makePairs(ids) {
  const order = shuffle(ids)
  return order.map((id, i) => [id, order[(i + 1) % order.length]])
}

export function makeRound({ players, config, plus, used = {}, roundNo = 0 }) {
  const pool = resolvePool(config.cats, plus)
  const catId = pick(pool)
  const cat = CATEGORY_BY_ID[catId]
  const usedHere = used[catId] || []
  let candidates = cat.words.filter((w) => !usedHere.includes(w))
  let nextUsedHere = usedHere
  if (!candidates.length) {
    candidates = cat.words
    nextUsedHere = []
  }
  const word = pick(candidates)
  const ids = players.map((p) => p.id)
  const nOut = config.outsiders === 2 && ids.length >= 7 ? 2 : 1
  const outsiders = sample(ids, nOut)
  const start = roundNo % ids.length
  const order = [...ids.slice(start), ...ids.slice(0, start)]
  const others = sample(
    cat.words.filter((w) => w !== word),
    7,
  )
  return {
    round: {
      catId,
      catName: cat.name,
      word,
      outsiders,
      order,
      pairs: makePairs(ids),
      options: shuffle([word, ...others]),
    },
    used: { ...used, [catId]: [...nextUsedHere, word] },
  }
}

export function tallyVotes(ids, votes) {
  const tally = Object.fromEntries(ids.map((id) => [id, 0]))
  Object.values(votes).forEach((t) => {
    if (t in tally) tally[t] += 1
  })
  return tally
}

// اللي برا السالفة «اتكشف» لو أخد أعلى أصوات (أو متعادل مع الأعلى)
export function caughtMap(outsiders, tally) {
  const max = Math.max(0, ...Object.values(tally))
  return Object.fromEntries(outsiders.map((o) => [o, max > 0 && tally[o] === max]))
}

export function scoreRound({ ids, outsiders, votes, caught, guesses }) {
  const deltas = Object.fromEntries(ids.map((id) => [id, 0]))
  Object.entries(votes).forEach(([voter, target]) => {
    if (outsiders.includes(target)) deltas[voter] += 1
  })
  outsiders.forEach((o) => {
    if (!caught[o]) deltas[o] += 2
    if (guesses[o]?.correct) deltas[o] += 2
  })
  return deltas
}
