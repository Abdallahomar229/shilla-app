// تنقّل بسيط بين الشاشات + زرار «رجوع» في الموبايل/المتصفح
// كل شاشة جديدة = خطوة في history، فزرار الرجوع يرجّع للشاشة اللي قبلها.
// أثناء لعبة شغّالة: «حارس» يوقف الرجوع ويسأل «تخرج من اللعبة؟».
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'

const NavCtx = createContext(null)

export function NavProvider({ children }) {
  const [stack, setStack] = useState([{ name: 'home' }])
  const stackRef = useRef(stack)
  stackRef.current = stack
  const historyOk = useRef(true)
  const guardRef = useRef(null)
  const skipGuard = useRef(false)
  const fallbackTimer = useRef(null)
  const [exitAsk, setExitAsk] = useState(false)

  useEffect(() => {
    try {
      window.history.replaceState({ shilla: 0 }, '')
    } catch {
      historyOk.current = false
    }
    const onPop = (e) => {
      const depth = typeof e.state?.shilla === 'number' ? e.state.shilla : 0
      const cur = stackRef.current.length - 1
      if (depth >= cur) return
      if (!skipGuard.current && guardRef.current && guardRef.current()) {
        try {
          window.history.pushState({ shilla: cur }, '')
        } catch {
          historyOk.current = false
        }
        setExitAsk(true)
        return
      }
      skipGuard.current = false
      clearTimeout(fallbackTimer.current)
      setStack((s) => s.slice(0, depth + 1))
    }
    window.addEventListener('popstate', onPop)
    return () => window.removeEventListener('popstate', onPop)
  }, [])

  // يرجّع n خطوات؛ لو history مش شغالة (iframe مقفول مثلًا) نرجع يدويًا
  const popTo = useCallback((targetLen) => {
    const before = stackRef.current.length
    const n = before - targetLen
    if (n <= 0) return
    if (historyOk.current) {
      try {
        if (n === 1) window.history.back()
        else window.history.go(-n)
        clearTimeout(fallbackTimer.current)
        fallbackTimer.current = setTimeout(() => {
          if (stackRef.current.length === before) {
            historyOk.current = false
            skipGuard.current = false
            setStack((s) => s.slice(0, targetLen))
          }
        }, 450)
        return
      } catch {
        historyOk.current = false
      }
    }
    skipGuard.current = false
    setStack((s) => s.slice(0, targetLen))
  }, [])

  const navigate = useCallback((route) => {
    const depth = stackRef.current.length
    setStack((s) => [...s, route])
    if (historyOk.current) {
      try {
        window.history.pushState({ shilla: depth }, '')
      } catch {
        historyOk.current = false
      }
    }
  }, [])

  const replace = useCallback((route) => {
    setStack((s) => [...s.slice(0, -1), route])
  }, [])

  const back = useCallback(() => {
    if (guardRef.current && guardRef.current()) {
      setExitAsk(true)
      return
    }
    popTo(stackRef.current.length - 1)
  }, [popTo])

  const goHome = useCallback(() => {
    guardRef.current = null
    skipGuard.current = true
    popTo(1)
  }, [popTo])

  const confirmExit = useCallback(() => {
    setExitAsk(false)
    guardRef.current = null
    skipGuard.current = true
    popTo(stackRef.current.length - 1)
  }, [popTo])

  const cancelExit = useCallback(() => setExitAsk(false), [])

  const setGuard = useCallback((fn) => {
    guardRef.current = fn || null
  }, [])

  const value = useMemo(
    () => ({
      stack,
      route: stack[stack.length - 1],
      depth: stack.length,
      navigate,
      replace,
      back,
      goHome,
      setGuard,
      exitAsk,
      confirmExit,
      cancelExit,
    }),
    [stack, navigate, replace, back, goHome, setGuard, exitAsk, confirmExit, cancelExit],
  )

  return <NavCtx.Provider value={value}>{children}</NavCtx.Provider>
}

export function useNav() {
  return useContext(NavCtx)
}

// يفعّل الحارس طول ما active = true
export function useExitGuard(active) {
  const { setGuard } = useNav()
  useEffect(() => {
    setGuard(active ? () => true : null)
    return () => setGuard(null)
  }, [active, setGuard])
}
