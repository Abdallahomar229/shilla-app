import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { load, save, clearAll } from '../lib/storage.js'
import { uid } from '../lib/random.js'
import * as billing from '../lib/billing.js'
import { setSfxEnabled } from '../lib/sfx.js'
import { setVibration } from '../lib/device.js'
import { prepareVoices, resetVoices } from '../lib/voice.js'
import { isNativeApp } from '../lib/native.js'
import { SHOW_TEST_MODE } from '../lib/config.js'

export const FREE_PLAYER_LIMIT = 8
export const MAX_PLAYERS = 20
export const NAME_MAX = 16

const DEFAULT_SETTINGS = {
  narrator: true,
  narratorRate: 1,
  sfx: true,
  vibration: true,
  revealOnExit: true,
  testPlus: false,
}

const DEFAULT_NAMES = ['أحمد', 'سارة', 'محمد', 'نورة']

function defaultPlayers() {
  return DEFAULT_NAMES.map((name) => ({ id: uid(), name }))
}

function loadPlayers() {
  const saved = load('players', null)
  if (Array.isArray(saved)) {
    const ok = saved.filter((p) => p && typeof p.id === 'string' && typeof p.name === 'string' && p.name.trim())
    if (ok.length) return ok.slice(0, MAX_PLAYERS)
  }
  return defaultPlayers()
}

const AppCtx = createContext(null)

export function AppProvider({ children }) {
  const [settings, setSettings] = useState(() => ({ ...DEFAULT_SETTINGS, ...load('settings', {}) }))
  const [players, setPlayers] = useState(loadPlayers)
  const [entitled, setEntitled] = useState(() => billing.isPlus())
  const [voiceOk, setVoiceOk] = useState(null)
  const [toastState, setToastState] = useState(null)

  useEffect(() => {
    save('settings', settings)
    setSfxEnabled(settings.sfx)
    setVibration(settings.vibration)
  }, [settings])

  useEffect(() => {
    save('players', players)
  }, [players])

  useEffect(() => {
    let alive = true
    const check = () => {
      prepareVoices().then((ok) => {
        if (alive) setVoiceOk(!!ok)
      })
    }
    check()
    // في نسخة أندرويد: لو المستخدم نزّل الصوت العربي من الإعدادات ورجع، نعيد الفحص
    const onVisible = () => {
      if (document.visibilityState !== 'visible' || !isNativeApp()) return
      resetVoices()
      check()
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      alive = false
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [])

  useEffect(() => {
    if (!toastState) return undefined
    const t = setTimeout(() => setToastState(null), 2800)
    return () => clearTimeout(t)
  }, [toastState])

  const setSetting = useCallback((key, value) => setSettings((s) => ({ ...s, [key]: value })), [])
  const toast = useCallback((msg) => setToastState({ msg, id: Date.now() }), [])
  const refreshEntitlement = useCallback(() => setEntitled(billing.isPlus()), [])

  // الاشتراك اتفعّل/اتلغى من ناحية المتجر (نسخة أندرويد)
  useEffect(() => {
    const onEnt = () => setEntitled(billing.isPlus())
    window.addEventListener('shilla:entitlement', onEnt)
    return () => window.removeEventListener('shilla:entitlement', onEnt)
  }, [])

  const resetAll = useCallback(() => {
    const had = billing.isPlus()
    clearAll()
    billing.keepEntitlement(had)
    setSettings({ ...DEFAULT_SETTINGS })
    setPlayers(defaultPlayers())
    setEntitled(had)
  }, [])

  const plus = entitled || (SHOW_TEST_MODE && !!settings.testPlus)

  const value = useMemo(
    () => ({
      settings,
      setSetting,
      players,
      setPlayers,
      plus,
      entitled,
      refreshEntitlement,
      voiceOk,
      toast,
      toastState,
      resetAll,
    }),
    [settings, setSetting, players, plus, entitled, refreshEntitlement, voiceOk, toast, toastState, resetAll],
  )

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp() {
  return useContext(AppCtx)
}
