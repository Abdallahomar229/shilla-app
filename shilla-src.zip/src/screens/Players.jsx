import { useState } from 'react'
import { useApp, FREE_PLAYER_LIMIT, MAX_PLAYERS, NAME_MAX } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { IconPlus, IconLock, IconUp, IconDown, IconTrash } from '../components/Icons.jsx'
import { uid } from '../lib/random.js'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

export default function Players() {
  const { players, setPlayers, plus, toast } = useApp()
  const nav = useNav()
  const [draft, setDraft] = useState('')
  const limit = plus ? MAX_PLAYERS : FREE_PLAYER_LIMIT
  const locked = !plus && players.length >= FREE_PLAYER_LIMIT

  const add = () => {
    const name = draft.trim().replace(/\s+/g, ' ').slice(0, NAME_MAX)
    if (locked) {
      nav.navigate({ name: 'paywall' })
      return
    }
    if (!name) return
    if (players.length >= MAX_PLAYERS) {
      toast(`أقصى عدد ${ar(MAX_PLAYERS)} لاعب`)
      return
    }
    if (players.some((p) => p.name.trim() === name)) {
      toast('الاسم ده موجود قبل كده')
      return
    }
    sfx.tap()
    setPlayers([...players, { id: uid(), name }])
    setDraft('')
  }

  const rename = (id, name) => setPlayers(players.map((p) => (p.id === id ? { ...p, name: name.slice(0, NAME_MAX) } : p)))
  const fixEmpty = (id, i) => {
    const p = players.find((x) => x.id === id)
    if (p && !p.name.trim()) rename(id, `لاعب ${ar(i + 1)}`)
  }
  const remove = (id) => {
    sfx.tap()
    setPlayers(players.filter((p) => p.id !== id))
  }
  const move = (i, dir) => {
    const j = i + dir
    if (j < 0 || j >= players.length) return
    const next = players.slice()
    ;[next[i], next[j]] = [next[j], next[i]]
    setPlayers(next)
  }

  return (
    <Screen
      title="اللاعيبة"
      eyebrow={`${ar(players.length)} من ${ar(limit)}`}
      glow="saffron"
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={nav.back}>
          تمام
        </button>
      }
    >
      <form
        className="add-player"
        onSubmit={(e) => {
          e.preventDefault()
          add()
        }}
      >
        <label htmlFor="new-player" className="sr-only">
          اسم لاعب جديد
        </label>
        <input
          id="new-player"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={locked ? 'وصلت لحد النسخة المجانية' : 'اكتب اسم لاعب'}
          maxLength={NAME_MAX}
          autoComplete="off"
          enterKeyHint="done"
          disabled={locked}
        />
        <button type="submit" className={`btn btn-add ${locked ? 'locked' : ''}`}>
          {locked ? <IconLock size={20} /> : <IconPlus size={20} />}
          {locked ? 'بلس' : 'ضيف'}
        </button>
      </form>

      {!plus ? (
        <p className="limit-note">
          النسخة المجانية لحد {ar(FREE_PLAYER_LIMIT)} لاعيبة.{' '}
          <button type="button" className="link" onClick={() => nav.navigate({ name: 'paywall' })}>
            شلّة بلس لحد {ar(MAX_PLAYERS)}
          </button>
        </p>
      ) : null}

      {players.length ? (
        <ol className="player-list">
          {players.map((p, i) => (
            <li key={p.id} className="player-row">
              <span className={`player-num ${!plus && i >= FREE_PLAYER_LIMIT ? 'over' : ''}`}>{ar(i + 1)}</span>
              <input
                id={`player-${p.id}`}
                className="player-name"
                value={p.name}
                onChange={(e) => rename(p.id, e.target.value)}
                onBlur={() => fixEmpty(p.id, i)}
                aria-label={`اسم اللاعب رقم ${ar(i + 1)}`}
                maxLength={NAME_MAX}
                autoComplete="off"
              />
              <span className="row-tools">
                <button type="button" className="icon-btn sm" aria-label={`طلّع ${p.name} لفوق`} disabled={i === 0} onClick={() => move(i, -1)}>
                  <IconUp size={20} />
                </button>
                <button type="button" className="icon-btn sm" aria-label={`نزّل ${p.name} لتحت`} disabled={i === players.length - 1} onClick={() => move(i, 1)}>
                  <IconDown size={20} />
                </button>
                <button type="button" className="icon-btn sm danger" aria-label={`امسح ${p.name}`} onClick={() => remove(p.id)}>
                  <IconTrash size={20} />
                </button>
              </span>
            </li>
          ))}
        </ol>
      ) : (
        <p className="empty">ضيف أسماء الشلّة عشان تبدأوا.</p>
      )}
      {!plus && players.length > FREE_PLAYER_LIMIT ? <p className="notice">النسخة المجانية لحد {ar(FREE_PLAYER_LIMIT)} لاعيبة في اللعبة. امسح الزيادة أو افتح شلّة بلس عشان تبدأوا.</p> : null}
    </Screen>
  )
}
