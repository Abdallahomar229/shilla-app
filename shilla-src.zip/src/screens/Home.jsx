import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Logo, Cover } from '../components/Art.jsx'
import { Chip } from '../components/ui.jsx'
import { IconCrown, IconGear, IconForward, IconVolume } from '../components/Icons.jsx'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

const GAMES = [
  {
    id: 'outsider',
    title: 'برا السالفة',
    desc: 'كلكم عارفين السالفة… إلا واحد. اكشفوه قبل ما يعرفها.',
    meta: '٣–٢٠ لاعب',
    color: 'var(--saffron)',
    img: 'cover_outsider',
  },
  {
    id: 'mafia',
    title: 'المافيا',
    desc: 'الليل للمافيا والنهار للمدينة… والراوي بيدير كل حاجة.',
    meta: '٥–٢٠ لاعب',
    extra: 'بصوت راوي',
    color: 'var(--crimson)',
    img: 'cover_mafia',
  },
  {
    id: 'truth',
    title: 'صراحة ومين فينا',
    desc: 'أسئلة صريحة ولحظات «مين فينا؟» تولّع القعدة.',
    meta: '٢+ لاعيبة',
    color: 'var(--mint)',
    img: 'cover_truth',
  },
]

const AVATAR_TONES = ['saffron', 'coral', 'mint', 'lavender']

export default function Home() {
  const { players, plus } = useApp()
  const nav = useNav()
  const go = (name) => {
    sfx.tap()
    nav.navigate({ name })
  }
  return (
    <section className="screen home glow-home">
      <header className="home-top">
        <Logo size={46} />
        <div className="home-actions">
          <button type="button" className={`plus-chip ${plus ? 'active' : ''}`} onClick={() => go('paywall')}>
            <IconCrown size={18} />
            {plus ? 'بلس مفعّل' : 'شلّة بلس'}
          </button>
          <button type="button" className="icon-btn" aria-label="الإعدادات" onClick={() => go('settings')}>
            <IconGear />
          </button>
        </div>
      </header>
      <div className="screen-body">
        <div className="screen-inner">
          <p className="tagline">ألعاب السهرة مع الشلّة</p>

          <button type="button" className="players-row" onClick={() => go('players')}>
            <span className="avatars" aria-hidden="true">
              {players.slice(0, 5).map((p, i) => (
                <span key={p.id} className={`avatar tone-${AVATAR_TONES[i % AVATAR_TONES.length]}`}>
                  {p.name.trim().charAt(0)}
                </span>
              ))}
            </span>
            <span className="players-label">اللاعيبة ({ar(players.length)})</span>
            <span className="players-edit">
              تعديل <IconForward size={18} />
            </span>
          </button>

          <div className="games">
            {GAMES.map((g, i) => (
              <button key={g.id} type="button" className={`game-card game-${g.id}`} style={{ '--c': g.color, '--i': i }} onClick={() => go(g.id)}>
                <Cover imgKey={g.img} game={g.id} color={g.color} />
                <span className="game-info">
                  <span className="game-title">{g.title}</span>
                  <span className="game-desc">{g.desc}</span>
                  <span className="game-meta">
                    <Chip>{g.meta}</Chip>
                    {g.extra ? (
                      <Chip tone="crimson" icon={<IconVolume size={14} />}>
                        {g.extra}
                      </Chip>
                    ) : null}
                  </span>
                </span>
              </button>
            ))}
          </div>

          <p className="home-foot">نسخة تجريبية ٠٫١، وكل حاجة بتتحفظ على موبايلك بس</p>
        </div>
      </div>
    </section>
  )
}
