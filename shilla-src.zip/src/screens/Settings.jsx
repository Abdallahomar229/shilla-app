import { useRef, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen, Section, Toggle, Segmented, Sheet } from '../components/ui.jsx'
import { IconShield, IconForward, IconTrash, IconInfo, IconVolume } from '../components/Icons.jsx'
import { SHOW_TEST_MODE, APP_VERSION } from '../lib/config.js'
import { ar } from '../lib/format.js'
import { speak } from '../lib/voice.js'
import { isNativeApp, openTtsSettings } from '../lib/native.js'
import { redeemReviewCode, REVIEW_TAPS } from '../lib/review.js'

function untilText(ts) {
  try {
    return new Date(ts).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' })
  } catch {
    return ''
  }
}

export default function Settings() {
  const { settings, setSetting, voiceOk, resetAll, toast, entitled, reviewPlus, reviewUntil, setReviewUntil } = useApp()
  const nav = useNav()
  const [askReset, setAskReset] = useState(false)
  const [askCode, setAskCode] = useState(false)
  const [code, setCode] = useState('')
  const [checking, setChecking] = useState(false)
  const taps = useRef({ n: 0, t: 0 })

  // ٧ دوسات ورا بعض على «الإصدار» بتفتح خانة كود المراجعة
  const onVersionTap = () => {
    const now = Date.now()
    const r = taps.current
    r.n = now - r.t < 1500 ? r.n + 1 : 1
    r.t = now
    if (r.n >= REVIEW_TAPS) {
      r.n = 0
      setCode('')
      setAskCode(true)
    }
  }

  const submitCode = async (e) => {
    e.preventDefault()
    if (checking) return
    setChecking(true)
    try {
      const res = await redeemReviewCode(code)
      if (res.ok) {
        setReviewUntil(res.until)
        setAskCode(false)
        toast('اتفتحت شلّة بلس للمراجعة لمدة ٧ أيام')
      } else if (res.reason === 'unsupported') toast('الخاصية دي مش متاحة على الجهاز ده')
      else toast('الكود ده مش صحيح')
    } finally {
      setChecking(false)
    }
  }

  return (
    <Screen title="الإعدادات" glow="lavender">
      <Section title="الصوت">
        <Toggle id="set-narrator" label="الراوي" hint="صوت بيدير ليل المافيا" checked={settings.narrator} onChange={(v) => setSetting('narrator', v)} />
        {voiceOk === false ? <p className="notice soft">الجهاز ده مفيهوش صوت عربي للقراءة. الجمل هتظهر على الشاشة وحد يقراها بصوت عالي.</p> : null}
        {voiceOk === false && isNativeApp() ? (
          <button type="button" className="btn btn-ghost btn-sm" onClick={openTtsSettings}>
            <IconVolume size={18} /> نزّل الصوت العربي من إعدادات الموبايل
          </button>
        ) : null}
        <div className="row-field">
          <span className="row-label">
            <span>سرعة الراوي</span>
          </span>
          <Segmented
            id="narrator-rate"
            label="سرعة الراوي"
            value={settings.narratorRate}
            onChange={(v) => setSetting('narratorRate', v)}
            options={[
              { value: 0.85, label: 'هادي' },
              { value: 1, label: 'عادي' },
              { value: 1.15, label: 'سريع' },
            ]}
          />
        </div>
        {voiceOk ? (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => speak('حلّ الليل على المدينة… على الجميع إغلاق أعينهم.', { rate: settings.narratorRate })}>
            <IconVolume size={18} /> اسمع الراوي
          </button>
        ) : null}
        <Toggle id="set-sfx" label="المؤثرات الصوتية" checked={settings.sfx} onChange={(v) => setSetting('sfx', v)} />
        <Toggle id="set-vibration" label="الاهتزاز" checked={settings.vibration} onChange={(v) => setSetting('vibration', v)} />
      </Section>

      <Section title="اللعب">
        <Toggle id="set-reveal" label="اكشف دور اللي يخرج" hint="الاختيار الافتراضي في المافيا" checked={settings.revealOnExit} onChange={(v) => setSetting('revealOnExit', v)} />
      </Section>

      {SHOW_TEST_MODE ? (
        <Section title="للتجربة">
          <Toggle
            id="set-test-plus"
            label="وضع التجربة: افتح شلّة بلس"
            hint={entitled ? 'شلّة بلس مفعّل بالفعل' : 'يفتح كل الأقسام والأدوار عشان تجرّب. مش موجود في نسخة المتجر.'}
            checked={settings.testPlus}
            onChange={(v) => {
              setSetting('testPlus', v)
              toast(v ? 'وضع التجربة شغال: كل حاجة مفتوحة' : 'وضع التجربة اتقفل')
            }}
          />
        </Section>
      ) : null}

      <Section title="عن شلّة">
        <button type="button" className="list-link" onClick={() => nav.navigate({ name: 'privacy' })}>
          <IconShield size={20} />
          <span>سياسة الخصوصية</span>
          <IconForward size={18} />
        </button>
        <div className="list-link static" onClick={onVersionTap} data-testid="version-row">
          <IconInfo size={20} />
          <span>الإصدار {ar(APP_VERSION)}</span>
        </div>
        {reviewPlus && !entitled ? (
          <p className="notice soft">كود المراجعة شغال: «شلّة بلس» مفتوحة لحد {untilText(reviewUntil)}.</p>
        ) : null}
        <button type="button" className="list-link danger" onClick={() => setAskReset(true)}>
          <IconTrash size={20} />
          <span>مسح البيانات</span>
        </button>
      </Section>

      <Sheet open={askReset} title="نمسح كل البيانات؟" onClose={() => setAskReset(false)}>
        <p className="sheet-text">هيتمسح اللاعيبة والإعدادات واختياراتك في الألعاب. الحاجة دي مالهاش رجوع.</p>
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" data-autofocus onClick={() => setAskReset(false)}>
            لأ، سيبها
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              resetAll()
              setAskReset(false)
              toast('اتمسح كل حاجة')
            }}
          >
            امسح
          </button>
        </div>
      </Sheet>

      <Sheet open={askCode} title="كود المراجعة" onClose={() => setAskCode(false)}>
        <form className="review-form" onSubmit={submitCode}>
          <p className="sheet-text">
            اكتب الكود اللي معاك عشان تفتح «شلّة بلس».
            <span className="review-en" lang="en" dir="ltr">
              Enter your review code to unlock Shilla Plus.
            </span>
          </p>
          <input
            id="review-code"
            className="review-input"
            data-autofocus
            dir="ltr"
            lang="en"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Review code"
            aria-label="كود المراجعة"
            autoComplete="off"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            enterKeyHint="done"
            maxLength={40}
          />
          <div className="btn-row">
            <button type="button" className="btn btn-secondary" onClick={() => setAskCode(false)}>
              إلغاء
            </button>
            <button type="submit" className="btn btn-primary" disabled={checking || !code.trim()}>
              فعّل
            </button>
          </div>
        </form>
      </Sheet>
    </Screen>
  )
}
