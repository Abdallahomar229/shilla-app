import { useEffect, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { Logo } from '../components/Art.jsx'
import { IconClose, IconCheck, IconCrown } from '../components/Icons.jsx'
import { getOfferings, purchase, restore, PLANS } from '../lib/billing.js'
import { nativePlatform } from '../lib/native.js'
import { CATEGORIES } from '../content/categories.js'
import { ar } from '../lib/format.js'
import { sfx } from '../lib/sfx.js'

const plusCats = CATEGORIES.filter((c) => c.plus).length
// شروط الاستخدام القياسية (أبل بتطلب لينك ليها جنب أي اشتراك بيتجدد)
const TERMS_URL = 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/'

const BENEFITS = [
  `كل الأقسام والكلمات (+${ar(plusCats)} قسم)`,
  'دور القنّاص والمهرّج في المافيا',
  'كل باقات صراحة ومين فينا',
  'لحد ٢٠ لاعب في القعدة',
  'أقسام جديدة باستمرار',
]

export default function Paywall() {
  const { plus, entitled, reviewPlus, toast, refreshEntitlement } = useApp()
  const nav = useNav()
  const [plan, setPlan] = useState('yearly')
  const [offer, setOffer] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let alive = true
    getOfferings().then((o) => {
      if (alive) setOffer(o)
    })
    return () => {
      alive = false
    }
  }, [])

  const plans = offer?.plans || PLANS.map((p) => ({ ...p, price: null }))

  const buy = async () => {
    setBusy(true)
    try {
      const res = await purchase(plan)
      if (res?.ok) {
        refreshEntitlement()
        sfx.success()
        toast('أهلًا بيك في شلّة بلس!')
        nav.back()
      } else {
        toast(res?.message || 'الشراء ماتمّش')
      }
    } finally {
      setBusy(false)
    }
  }

  const doRestore = async () => {
    const res = await restore()
    refreshEntitlement()
    if (res?.ok) toast(res.entitled ? 'رجّعنا اشتراكك في شلّة بلس' : 'مفيش مشتريات على الحساب ده')
    else toast(res?.message || 'مقدرناش نرجّع المشتريات دلوقتي')
  }

  return (
    <Screen
      title="شلّة بلس"
      glow="saffron"
      noBack
      className="paywall"
      right={
        <button type="button" className="icon-btn" aria-label="اقفل" onClick={nav.back}>
          <IconClose />
        </button>
      }
      actions={
        entitled ? (
          <button type="button" className="btn btn-primary btn-block" onClick={nav.back}>
            تمام
          </button>
        ) : (
          <div className="pay-actions">
            <button type="button" className="btn btn-primary btn-block" disabled={busy} onClick={buy}>
              <IconCrown size={20} /> اشترك في شلّة بلس
            </button>
            <button type="button" className="link" onClick={doRestore}>
              استرجاع المشتريات
            </button>
          </div>
        )
      }
    >
      <div className="pay-hero">
        <Logo size={40} />
        <strong className="pay-title">افتح كل الألعاب والأقسام</strong>
        {plus && !entitled ? (
          <p className="pay-note">{reviewPlus ? 'كود المراجعة شغال: كل حاجة مفتوحة دلوقتي.' : 'وضع التجربة شغال: كل حاجة مفتوحة دلوقتي.'}</p>
        ) : null}
        {entitled ? <p className="pay-note good">شلّة بلس مفعّل. استمتعوا!</p> : null}
      </div>

      <ul className="benefits">
        {BENEFITS.map((b) => (
          <li key={b}>
            <span className="benefit-check">
              <IconCheck size={16} strokeWidth={3} />
            </span>
            {b}
          </li>
        ))}
      </ul>

      {!entitled ? (
        <div className="plans" role="radiogroup" aria-label="اختار الخطة">
          {plans.map((p) => (
            <button
              key={p.id}
              type="button"
              role="radio"
              aria-checked={plan === p.id}
              className={`plan ${plan === p.id ? 'on' : ''}`}
              onClick={() => {
                sfx.tap()
                setPlan(p.id)
              }}
            >
              {p.badge ? <span className="plan-badge">{p.badge}</span> : null}
              <span className="plan-title">{p.title}</span>
              <span className="plan-price">{p.price || 'السعر من المتجر'}</span>
              <span className="plan-note">{p.note}</span>
            </button>
          ))}
        </div>
      ) : null}

      {!entitled ? (
        <p className="fine-print">
          {offer && !offer.available ? (offer.native ? 'المتجر مش متاح دلوقتي، جرّب بعد شوية. ' : 'الشراء هيشتغل في نسخة المتجر. ') : ''}
          الاشتراك الأسبوعي والسنوي بيتجدد تلقائيًا وتقدر تلغيه في أي وقت من إعدادات المتجر. «مدى الحياة» بتدفعه مرة واحدة.
        </p>
      ) : null}
      <p className="fine-print legal-links">
        {nativePlatform() === 'ios' ? (
          <>
            <a href={TERMS_URL} target="_blank" rel="noreferrer">
              شروط الاستخدام
            </a>
            <span aria-hidden="true"> · </span>
          </>
        ) : null}
        <button type="button" className="link" onClick={() => nav.navigate({ name: 'privacy' })}>
          سياسة الخصوصية
        </button>
      </p>
    </Screen>
  )
}
