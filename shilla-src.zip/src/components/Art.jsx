// الشعار + الأغلفة والرسومات البديلة (لو صور الرسام لسه ماوصلتش)
import { img } from '../lib/images.js'

export function Logo({ size = 52, tag = false }) {
  return (
    <div className="logo" style={{ '--logo-size': `${size}px` }} role="img" aria-label="شلّة">
      <svg className="logo-dots" viewBox="0 0 30 27" aria-hidden="true" focusable="false">
        <circle cx="15" cy="6.2" r="5.4" fill="var(--saffron)" />
        <circle cx="7.2" cy="19.6" r="5.4" fill="var(--coral)" />
        <circle cx="22.8" cy="19.6" r="5.4" fill="var(--mint)" />
      </svg>
      <span className="logo-word" aria-hidden="true">
        شلّة
      </span>
      {tag ? <span className="logo-tag">ألعاب السهرة</span> : null}
    </div>
  )
}

// ───────── رسومات بديلة بسيطة ─────────
function GlyphOutsider() {
  return (
    <svg viewBox="0 0 200 120" aria-hidden="true" focusable="false">
      <g opacity="0.95">
        <circle cx="52" cy="62" r="13" fill="var(--lavender)" />
        <rect x="36" y="78" width="32" height="30" rx="14" fill="var(--lavender)" opacity="0.75" />
        <circle cx="86" cy="58" r="13" fill="var(--coral)" />
        <rect x="70" y="74" width="32" height="34" rx="14" fill="var(--coral)" opacity="0.75" />
        <circle cx="120" cy="62" r="13" fill="var(--mint)" />
        <rect x="104" y="78" width="32" height="30" rx="14" fill="var(--mint)" opacity="0.75" />
      </g>
      <circle cx="160" cy="70" r="13" fill="var(--saffron)" />
      <rect x="144" y="86" width="32" height="24" rx="14" fill="var(--saffron)" opacity="0.8" />
      <path d="M150 20h34a10 10 0 0 1 10 10v14a10 10 0 0 1-10 10h-16l-8 8v-8h-10a10 10 0 0 1-10-10V30a10 10 0 0 1 10-10z" fill="var(--text)" />
      <text x="167" y="47" textAnchor="middle" fontFamily="Lalezar, sans-serif" fontSize="30" fill="var(--night)">؟</text>
    </svg>
  )
}

function GlyphMafia() {
  return (
    <svg viewBox="0 0 200 120" aria-hidden="true" focusable="false">
      <path d="M150 18a24 24 0 1 0 22 33 19 19 0 1 1-22-33z" fill="var(--saffron)" opacity="0.9" />
      <ellipse cx="88" cy="88" rx="70" ry="13" fill="var(--night)" opacity="0.9" />
      <path d="M48 86c3-28 10-46 22-50 7-2 12 4 18 4s11-6 18-4c12 4 19 22 22 50z" fill="var(--night)" />
      <path d="M50 74h76" stroke="var(--crimson)" strokeWidth="8" strokeLinecap="round" />
      <circle cx="30" cy="30" r="2" fill="var(--text)" opacity="0.7" />
      <circle cx="112" cy="18" r="1.6" fill="var(--text)" opacity="0.6" />
      <circle cx="186" cy="92" r="1.8" fill="var(--text)" opacity="0.5" />
    </svg>
  )
}

function GlyphTruth() {
  return (
    <svg viewBox="0 0 200 120" aria-hidden="true" focusable="false">
      <g transform="rotate(-10 80 64)">
        <rect x="52" y="20" width="58" height="82" rx="12" fill="var(--surface-2)" stroke="var(--mint)" strokeWidth="3" />
        <path d="M81 74c-9-7-14-11-14-17a7 7 0 0 1 14-2 7 7 0 0 1 14 2c0 6-5 10-14 17z" fill="var(--coral)" />
      </g>
      <g transform="rotate(9 128 60)">
        <rect x="98" y="16" width="58" height="82" rx="12" fill="var(--text)" />
        <text x="127" y="76" textAnchor="middle" fontFamily="Lalezar, sans-serif" fontSize="54" fill="var(--night)">؟</text>
      </g>
    </svg>
  )
}

function GlyphRole({ role }) {
  const c = 'var(--text)'
  if (role === 'mafia')
    return (
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <ellipse cx="60" cy="78" rx="44" ry="9" fill={c} />
        <path d="M34 76c2-20 7-32 15-35 5-1 7 3 11 3s6-4 11-3c8 3 13 15 15 35z" fill={c} />
        <path d="M35 68h50" stroke="var(--crimson)" strokeWidth="6" strokeLinecap="round" />
      </svg>
    )
  if (role === 'doctor')
    return (
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <circle cx="60" cy="60" r="34" fill={c} />
        <path d="M60 42v36M42 60h36" stroke="var(--mint)" strokeWidth="11" strokeLinecap="round" />
      </svg>
    )
  if (role === 'detective')
    return (
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <circle cx="52" cy="52" r="22" fill="none" stroke={c} strokeWidth="9" />
        <path d="M68 68l22 22" stroke={c} strokeWidth="11" strokeLinecap="round" />
      </svg>
    )
  if (role === 'sniper')
    return (
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <circle cx="60" cy="60" r="30" fill="none" stroke={c} strokeWidth="6" />
        <circle cx="60" cy="60" r="6" fill="var(--coral)" />
        <path d="M60 20v22M60 78v22M20 60h22M78 60h22" stroke={c} strokeWidth="6" strokeLinecap="round" />
      </svg>
    )
  if (role === 'jester')
    return (
      <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
        <path d="M30 84c0-20 6-36 14-46 4 14 9 22 16 26 7-4 12-12 16-26 8 10 14 26 14 46z" fill={c} />
        <circle cx="44" cy="34" r="7" fill="var(--saffron)" />
        <circle cx="76" cy="34" r="7" fill="var(--mint)" />
        <circle cx="60" cy="58" r="6" fill="var(--coral)" />
        <rect x="28" y="82" width="64" height="10" rx="5" fill={c} />
      </svg>
    )
  // مواطن
  return (
    <svg viewBox="0 0 120 120" aria-hidden="true" focusable="false">
      <path d="M26 58L60 30l34 28" fill="none" stroke={c} strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M36 54v34h48V54" fill={c} />
      <rect x="53" y="66" width="14" height="22" rx="3" fill="var(--lavender)" />
    </svg>
  )
}

const GAME_GLYPH = { outsider: GlyphOutsider, mafia: GlyphMafia, truth: GlyphTruth }

export function Cover({ imgKey, game, color = 'var(--saffron)', className = '' }) {
  const src = img(imgKey)
  const Glyph = GAME_GLYPH[game]
  return (
    <div className={`cover ${className}`} style={{ '--c': color }}>
      {src ? (
        <img src={src} alt="" decoding="async" draggable="false" />
      ) : (
        <div className="cover-fallback">{Glyph ? <Glyph /> : null}</div>
      )}
    </div>
  )
}

export function RoleArt({ role, color, className = '' }) {
  const src = img(`role_${role}`)
  return (
    <div className={`role-art ${className}`} style={{ '--c': color }}>
      {src ? (
        <img src={src} alt="" decoding="async" draggable="false" />
      ) : (
        <div className="role-fallback">
          <GlyphRole role={role} />
        </div>
      )}
    </div>
  )
}
