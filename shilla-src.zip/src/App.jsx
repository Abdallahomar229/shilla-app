import { useEffect } from 'react'
import { AppProvider, useApp } from './state/app.jsx'
import { NavProvider, useNav } from './state/nav.jsx'
import { Sheet } from './components/ui.jsx'
import Home from './screens/Home.jsx'
import Players from './screens/Players.jsx'
import Settings from './screens/Settings.jsx'
import Privacy from './screens/Privacy.jsx'
import Paywall from './screens/Paywall.jsx'
import OutsiderGame from './games/outsider/OutsiderGame.jsx'
import MafiaGame from './games/mafia/MafiaGame.jsx'
import TruthGame from './games/truth/TruthGame.jsx'
import { unlockAudio } from './lib/sfx.js'
import { cancel as cancelSpeech } from './lib/voice.js'

const SCREENS = {
  home: Home,
  players: Players,
  settings: Settings,
  privacy: Privacy,
  paywall: Paywall,
  outsider: OutsiderGame,
  mafia: MafiaGame,
  truth: TruthGame,
}

// كل شاشة في الـstack بتفضل متركّبة (ومخفية) تحت اللي فوقها،
// فإعداد اللعبة مايضيعش لما تفتح «اللاعيبة» أو «شلّة بلس» وترجع.
function Router() {
  const nav = useNav()
  const { toastState } = useApp()

  useEffect(() => {
    const unlock = () => unlockAudio()
    window.addEventListener('pointerdown', unlock, { once: true })
    window.addEventListener('keydown', unlock, { once: true })
    return () => {
      window.removeEventListener('pointerdown', unlock)
      window.removeEventListener('keydown', unlock)
    }
  }, [])

  const last = nav.stack.length - 1
  return (
    <div className="app" lang="ar" dir="rtl">
      {nav.stack.map((route, i) => {
        const S = SCREENS[route.name] || Home
        const isTop = i === last
        return (
          <div key={i} className={`layer ${isTop ? 'top' : 'under'}`} hidden={!isTop}>
            <S />
          </div>
        )
      })}
      <Sheet open={nav.exitAsk} title="تخرج من اللعبة؟" onClose={nav.cancelExit}>
        <p className="sheet-text">الجولة اللي شغالة دلوقتي هتضيع.</p>
        <div className="btn-row">
          <button type="button" className="btn btn-secondary" data-autofocus onClick={nav.cancelExit}>
            لأ، كمّل
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              cancelSpeech()
              nav.confirmExit()
            }}
          >
            أيوه، اخرج
          </button>
        </div>
      </Sheet>
      <div className="toast-zone" aria-live="polite" role="status">
        {toastState ? (
          <div className="toast" key={toastState.id}>
            {toastState.msg}
          </div>
        ) : null}
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <NavProvider>
        <Router />
      </NavProvider>
    </AppProvider>
  )
}
