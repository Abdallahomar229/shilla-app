import UIKit

/// «شلّة» — غلاف آيفون بسيط: WKWebView بيعرض اللعبة من ملفات التطبيق (من غير إنترنت)،
/// وجسر للجافاسكريبت بنفس أسماء نسخة أندرويد (ShillaNative): الراوي، الاهتزاز، و«شلّة بلس».
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = ShillaTheme.night
        w.rootViewController = WebViewController()
        w.makeKeyAndVisible()
        window = w
        return true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // الموبايل بيتلف على القعدة، فمنخليش الشاشة تطفي في نص اللعب
        application.isIdleTimerDisabled = true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        application.isIdleTimerDisabled = false
    }
}

enum ShillaTheme {
    static let night = UIColor(red: 26.0 / 255.0, green: 16.0 / 255.0, blue: 51.0 / 255.0, alpha: 1)
}
