import GoogleMobileAds
import UIKit

/// إعلان بملء الشاشة بين الجولات (النسخة المجانية بس — اللعبة هي اللي بتقرر تطلبه).
/// المعرّف بييجي من Info.plist (GADInterstitialUnit)، والافتراضي إعلانات جوجل التجريبية.
final class AdsBridge: NSObject, FullScreenContentDelegate {
    private weak var host: UIViewController?
    private let done: (Bool) -> Void
    private var ad: InterstitialAd?
    private var loading = false
    private var started = false

    init(host: UIViewController, done: @escaping (Bool) -> Void) {
        self.host = host
        self.done = done
        super.init()
    }

    private var unitID: String {
        (Bundle.main.object(forInfoDictionaryKey: "GADInterstitialUnit") as? String) ?? "ca-app-pub-3940256099942544/4411468910"
    }

    /// إعلانات جوجل التجريبية مبتظهرش في نسخة المتجر — لحد ما نحط معرّفات AdMob الحقيقية
    private var enabled: Bool {
        #if DEBUG
        return true
        #else
        return !unitID.hasPrefix("ca-app-pub-3940256099942544")
        #endif
    }

    func start() {
        guard enabled else { return }
        if started { load(); return }
        started = true
        MobileAds.shared.start { [weak self] _ in
            DispatchQueue.main.async { self?.load() }
        }
    }

    private func load() {
        guard ad == nil, !loading else { return }
        loading = true
        InterstitialAd.load(with: unitID, request: Request()) { [weak self] loaded, _ in
            DispatchQueue.main.async {
                self?.loading = false
                self?.ad = loaded
                self?.ad?.fullScreenContentDelegate = self
            }
        }
    }

    func show() {
        guard let ad = ad, let host = host else {
            done(false)
            start()
            return
        }
        self.ad = nil
        ad.present(from: host)
    }

    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        done(true)
        load()
    }

    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        done(false)
        load()
    }
}
