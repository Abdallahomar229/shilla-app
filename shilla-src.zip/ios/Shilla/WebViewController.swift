import AudioToolbox
import AVFoundation
import UIKit
import WebKit

/// الشاشة الوحيدة في التطبيق: اللعبة نفسها جوه WKWebView.
final class WebViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate,
    AVSpeechSynthesizerDelegate {

    static let scheme = "app"
    static let startURL = URL(string: "app://shilla/index.html")!

    private var web: WKWebView!
    private let synth = AVSpeechSynthesizer()
    private var utteranceIds: [ObjectIdentifier: String] = [:]
    private let store = StoreBridge()
    private let arabicVoice: AVSpeechSynthesisVoice? = WebViewController.pickArabicVoice()
    private var audioReady = false

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .portrait }
    private lazy var ads = AdsBridge(host: self) { [weak self] shown in
        self?.js("window.__shillaAdDone&&window.__shillaAdDone(\(shown ? "true" : "false"))")
    }
    override var prefersHomeIndicatorAutoHidden: Bool { false }

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(BundleSchemeHandler(), forURLScheme: WebViewController.scheme)
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let content = WKUserContentController()
        content.addUserScript(WKUserScript(source: bridgeScript(),
                                           injectionTime: .atDocumentStart,
                                           forMainFrameOnly: true))
        content.add(WeakScriptHandler(self), name: "shilla")
        config.userContentController = content

        let w = WKWebView(frame: .zero, configuration: config)
        w.isOpaque = false
        w.backgroundColor = ShillaTheme.night
        w.scrollView.backgroundColor = ShillaTheme.night
        w.scrollView.bounces = false
        w.scrollView.alwaysBounceVertical = false
        w.scrollView.contentInsetAdjustmentBehavior = .never
        w.allowsBackForwardNavigationGestures = false
        w.allowsLinkPreview = false
        w.navigationDelegate = self
        w.uiDelegate = self
        web = w
        view = w
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        synth.delegate = self
        store.onEntitlement = { [weak self] on in
            self?.js("window.__shillaEntitlement&&window.__shillaEntitlement(\(on ? "true" : "false"))")
        }
        store.start()
        web.load(URLRequest(url: WebViewController.startURL))
    }

    // MARK: - الجسر (نفس أسماء نسخة أندرويد)

    private func bridgeScript() -> String {
        let status = arabicVoice == nil ? -1 : 1
        return """
        (function () {
          if (window.ShillaNative) return;
          var post = function (m) {
            try { window.webkit.messageHandlers.shilla.postMessage(m); } catch (e) {}
          };
          window.ShillaNative = {
            ttsStatus: function () { return \(status); },
            speak: function (t, r, id) { post({ fn: 'speak', text: String(t), rate: Number(r) || 1, id: String(id) }); },
            stop: function () { post({ fn: 'stop' }); },
            vibrate: function (ms) { post({ fn: 'vibrate', ms: Number(ms) || 0 }); },
            openTtsSettings: function () {},
            platform: function () { return 'ios'; },
            ads: function (a) { post({ fn: 'ads', action: String(a) }); },
            billing: function (a, p, cb) { post({ fn: 'billing', action: String(a), payload: String(p || '{}'), cb: String(cb) }); }
          };
        })();
        """
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let fn = body["fn"] as? String else { return }
        switch fn {
        case "ads":
            if (body["action"] as? String) == "interstitial" { ads.show() } else { ads.start() }
        case "speak":
            let rate = (body["rate"] as? NSNumber)?.floatValue ?? 1
            speak(body["text"] as? String ?? "", rate: rate, id: body["id"] as? String ?? "")
        case "stop":
            synth.stopSpeaking(at: .immediate)
        case "vibrate":
            vibrate(ms: (body["ms"] as? NSNumber)?.intValue ?? 0)
        case "billing":
            let cb = body["cb"] as? String ?? ""
            store.handle(action: body["action"] as? String ?? "",
                         payload: body["payload"] as? String ?? "{}") { [weak self] result in
                self?.billingReply(cb: cb, result: result)
            }
        default:
            break
        }
    }

    private func billingReply(cb: String, result: [String: Any]) {
        let json: String
        if let data = try? JSONSerialization.data(withJSONObject: result),
           let text = String(data: data, encoding: .utf8) {
            json = text
        } else {
            json = "{\"ok\":false,\"reason\":\"error\",\"message\":\"حصلت مشكلة، جرّب تاني\"}"
        }
        js("window.__shillaBilling&&window.__shillaBilling(\(WebViewController.jsString(cb)),\(WebViewController.jsString(json)))")
    }

    // MARK: - الراوي (نطق عربي)

    static func pickArabicVoice() -> AVSpeechSynthesisVoice? {
        let voices = AVSpeechSynthesisVoice.speechVoices().filter { $0.language.lowercased().hasPrefix("ar") }
        if let best = voices.max(by: { $0.quality.rawValue < $1.quality.rawValue }) {
            return best
        }
        return AVSpeechSynthesisVoice(language: "ar-SA")
    }

    private func prepareAudio() {
        if audioReady { return }
        audioReady = true
        let session = AVAudioSession.sharedInstance()
        // الراوي لازم يتسمع حتى لو زرار الصامت شغال، ومنوقفش أغاني القعدة
        try? session.setCategory(.playback, mode: .spokenAudio, options: [.mixWithOthers])
        try? session.setActive(true)
    }

    private func speak(_ text: String, rate: Float, id: String) {
        guard let voice = arabicVoice, !text.isEmpty else {
            ttsDone(id)
            return
        }
        prepareAudio()
        let u = AVSpeechUtterance(string: text)
        u.voice = voice
        let r = AVSpeechUtteranceDefaultSpeechRate * (rate > 0 ? rate : 1)
        u.rate = min(AVSpeechUtteranceMaximumSpeechRate, max(AVSpeechUtteranceMinimumSpeechRate, r))
        utteranceIds[ObjectIdentifier(u)] = id
        synth.speak(u)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        finishUtterance(utterance)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        finishUtterance(utterance)
    }

    private func finishUtterance(_ u: AVSpeechUtterance) {
        let key = ObjectIdentifier(u)
        DispatchQueue.main.async { [weak self] in
            guard let self = self, let id = self.utteranceIds.removeValue(forKey: key) else { return }
            self.ttsDone(id)
        }
    }

    private func ttsDone(_ id: String) {
        js("window.__shillaTtsDone&&window.__shillaTtsDone(\(WebViewController.jsString(id)))")
    }

    // MARK: - الاهتزاز

    private func vibrate(ms: Int) {
        guard ms > 0 else { return }
        if ms < 40 {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        } else if ms < 120 {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        } else if ms < 300 {
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        } else {
            AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
        }
    }

    // MARK: - اللينكات اللي برا اللعبة بتفتح في Safari

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.scheme == WebViewController.scheme || url.scheme == "about" || url.scheme == "blob" || url.scheme == "data" {
            decisionHandler(.allow)
            return
        }
        if url.scheme == "http" || url.scheme == "https" || url.scheme == "mailto" {
            UIApplication.shared.open(url)
        }
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, url.scheme == "http" || url.scheme == "https" {
            UIApplication.shared.open(url)
        }
        return nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.load(URLRequest(url: WebViewController.startURL))
    }

    // MARK: - مساعدات

    private func js(_ code: String) {
        DispatchQueue.main.async { [weak self] in
            self?.web?.evaluateJavaScript(code, completionHandler: nil)
        }
    }

    /// نص جافاسكريبت آمن ("...") من أي نص
    static func jsString(_ s: String) -> String {
        if let data = try? JSONSerialization.data(withJSONObject: [s]),
           let text = String(data: data, encoding: .utf8), text.count >= 2 {
            return String(text.dropFirst().dropLast())
        }
        return "\"\""
    }
}

/// WKUserContentController بيمسك الـhandler بقوة، فبنحط وسيط ضعيف عشان منعملش دايرة.
final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?

    init(_ target: WKScriptMessageHandler) {
        self.target = target
        super.init()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

/// بيقدّم ملفات اللعبة من جوه التطبيق على app://shilla/… (عشان الـmodules وlocalStorage يشتغلوا عادي)
final class BundleSchemeHandler: NSObject, WKURLSchemeHandler {
    private let root: URL = (Bundle.main.resourceURL ?? Bundle.main.bundleURL)
        .appendingPathComponent("web", isDirectory: true)
        .standardizedFileURL

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        let file = root.appendingPathComponent(String(path.dropFirst())).standardizedFileURL
        guard file.path.hasPrefix(root.path), let data = try? Data(contentsOf: file) else {
            let missing = HTTPURLResponse(url: url, statusCode: 404, httpVersion: "HTTP/1.1",
                                          headerFields: ["Content-Type": "text/plain"])!
            urlSchemeTask.didReceive(missing)
            urlSchemeTask.didReceive(Data())
            urlSchemeTask.didFinish()
            return
        }
        let headers = [
            "Content-Type": BundleSchemeHandler.mime(file.pathExtension),
            "Content-Length": String(data.count),
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*",
        ]
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: headers)!
        urlSchemeTask.didReceive(response)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    static func mime(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json; charset=utf-8"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "gif": return "image/gif"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        case "ttf": return "font/ttf"
        case "mp3": return "audio/mpeg"
        case "wav": return "audio/wav"
        case "ico": return "image/x-icon"
        case "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }
}
