# يولّد أيقونات أندرويد + أيقونة المتجر من رسمة ChatGPT (assets/raw/icon_symbol.png)
# python3 scripts/make-icons.py
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / 'assets/raw/icon_symbol.png'
RES = ROOT / 'android/res'
STORE = ROOT / 'store'
BG = (33, 17, 61)  # لون خلفية الرسمة نفسها (#21113D)

art = Image.open(RAW).convert('RGB')
# جوه المربع المدوّر اللي في الرسمة: الشلة + فقاعة الكلام
art = art.crop((150, 150, 1105, 1105))


def rounded_mask(size, radius, feather=0):
    m = Image.new('L', (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill=255)
    if feather:
        m = m.filter(ImageFilter.GaussianBlur(feather))
    return m


def circle_mask(size):
    m = Image.new('L', (size, size), 0)
    ImageDraw.Draw(m).ellipse((0, 0, size - 1, size - 1), fill=255)
    return m


# 1) أيقونة جوجل بلاي 512×512 (مربعة كاملة — جوجل بيدوّر الأطراف بنفسه)
STORE.mkdir(parents=True, exist_ok=True)
play = art.resize((512, 512), Image.LANCZOS)
play.save(STORE / 'icon-512.png', optimize=True)

# 2) الأيقونة المتكيّفة (Android 8+): خلفية لون ثابت + الرسمة في النص بأطراف ناعمة
FG = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
for d, px in FG.items():
    canvas = Image.new('RGBA', (px, px), (0, 0, 0, 0))
    s = round(px * 0.74)
    a = art.resize((s, s), Image.LANCZOS).convert('RGBA')
    a.putalpha(rounded_mask(s, round(s * 0.2), feather=max(1, round(s * 0.035))))
    canvas.alpha_composite(a, (round(px * 0.13), round(px * 0.17)))
    out = RES / f'mipmap-{d}'
    out.mkdir(parents=True, exist_ok=True)
    canvas.save(out / 'ic_launcher_foreground.png', optimize=True)

# 3) أيقونات قديمة (قبل Android 8): مربع مدوّر + دايرة
LEG = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
for d, px in LEG.items():
    base = art.resize((px, px), Image.LANCZOS).convert('RGBA')
    sq = base.copy()
    sq.putalpha(rounded_mask(px, round(px * 0.2)))
    sq.save(RES / f'mipmap-{d}' / 'ic_launcher.png', optimize=True)
    rd = base.copy()
    rd.putalpha(circle_mask(px))
    rd.save(RES / f'mipmap-{d}' / 'ic_launcher_round.png', optimize=True)

# 4) معاينة سريعة: شكل الأيقونة بماسك دايرة وماسك مربع مدوّر
prev = Image.new('RGB', (2 * 260 + 30, 290), (16, 16, 16))
fg = Image.open(RES / 'mipmap-xxxhdpi/ic_launcher_foreground.png')
full = Image.new('RGBA', fg.size, BG + (255,))
full.alpha_composite(fg)
vis = full.crop((72, 72, 360, 360)).resize((260, 260), Image.LANCZOS)  # الجزء الظاهر (72dp من 108)
c = vis.copy(); c.putalpha(circle_mask(260))
r = vis.copy(); r.putalpha(rounded_mask(260, 60))
prev.paste(c, (10, 15), c)
prev.paste(r, (280, 15), r)
prev.save(ROOT / 'store/_icon-preview.png')
print('icons ok')
