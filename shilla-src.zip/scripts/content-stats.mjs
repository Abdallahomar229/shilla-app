// إحصائيات المحتوى + فحص التكرار: node scripts/content-stats.mjs
import { CATEGORIES } from '../src/content/categories.js'
import { TRUTH_PACKS, WHO_PACKS } from '../src/content/truth.js'
import { NARRATION } from '../src/content/mafia.js'

let problems = 0
console.log('برا السالفة:')
for (const c of CATEGORIES) {
  const dups = c.words.filter((w, i) => c.words.indexOf(w) !== i)
  if (dups.length || c.words.length < 30) problems++
  console.log(`  ${c.plus ? 'Plus' : 'Free'}  ${c.name}: ${c.words.length}${dups.length ? '  DUP: ' + dups.join('، ') : ''}${c.words.length < 30 ? '  <30!' : ''}`)
}
const total = CATEGORIES.reduce((a, c) => a + c.words.length, 0)
console.log(`  المجموع: ${CATEGORIES.length} قسم، ${total} كلمة (مجاني ${CATEGORIES.filter((c) => !c.plus).length} / بلس ${CATEGORIES.filter((c) => c.plus).length})`)
for (const [label, packs] of [['صراحة', TRUTH_PACKS], ['مين فينا', WHO_PACKS]]) {
  console.log(label + ':')
  for (const p of packs) {
    const dups = p.questions.filter((q, i) => p.questions.indexOf(q) !== i)
    if (dups.length) problems++
    console.log(`  ${p.plus ? 'Plus' : 'Free'}  ${p.name}: ${p.questions.length}${dups.length ? '  DUP: ' + dups.join(' | ') : ''}`)
  }
}
console.log('جمل الراوي:', Object.entries(NARRATION).map(([k, v]) => `${k}:${v.length}`).join(' '))
console.log(problems ? `PROBLEMS: ${problems}` : 'no duplicates, all categories ≥ 30')
