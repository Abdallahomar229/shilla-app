// يرسم صور المتجر بالخطوط الحقيقية (العربي بيتشكّل صح في كروميوم):
//   store/feature-graphic.png   (1024×500)  — الصورة المميّزة في Google Play
//   store/screenshots/0N-*.png  (1080×1920) — لقطات شاشة بعناوين
// node scripts/store-graphics.mjs   (محتاج qa-hd/ من: DPR=3 QA_DIR=qa-hd node scripts/qa.mjs)
import { writeFileSync, mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { chromium } = require('playwright')
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const out = resolve(root, 'store')
const tmp = resolve(out, '_tmp')
mkdirSync(resolve(out, 'screenshots'), { recursive: true })
mkdirSync(tmp, { recursive: true })

const u = (p) => pathToFileURL(resolve(root, p)).href
const FONTS = `
@font-face{font-family:Lalezar;src:url(${u('src/assets/fonts/lalezar-arabic-400-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:400;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-400-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:600;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-600-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:800;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-800-normal.woff2')}) format('woff2')}
:root{--night:#1A1033;--saffron:#FFC531;--coral:#FF6B5B;--mint:#3FE0C5;--crimson:#E8344E;--lavender:#B9A8FF;--text:#FFF7EA;--muted:#BDB2DF}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--night)}
body{font-family:Baloo,sans-serif;color:var(--text);direction:rtl}
.dots{display:inline-flex;gap:.12em;vertical-align:top;margin-inline-start:.08em}
.dots i{display:block;width:.17em;height:.17em;border-radius:50%}
`

const feature = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>${FONTS}
body{width:1024px;height:500px;overflow:hidden;position:relative}
.bg{position:absolute;inset:0;background:url(${u('assets/raw/store_banner.png')}) left 62% / cover no-repeat}
.shade{position:absolute;inset:0;background:linear-gradient(270deg,rgba(26,16,51,.92) 0%,rgba(26,16,51,.75) 32%,rgba(26,16,51,0) 58%)}
.copy{position:absolute;top:0;bottom:0;right:64px;width:400px;display:flex;flex-direction:column;justify-content:center;gap:10px}
.logo{font-family:Lalezar;font-size:150px;line-height:1;color:var(--saffron);letter-spacing:0}
.tag{font-weight:800;font-size:40px;line-height:1.25}
.games{font-weight:600;font-size:26px;color:var(--mint);margin-top:6px}
</style></head><body><div class="bg"></div><div class="shade"></div>
<div class="copy"><div class="logo">شلّة<span class="dots"><i style="background:var(--saffron)"></i><i style="background:var(--coral)"></i><i style="background:var(--mint)"></i></span></div>
<div class="tag">ألعاب السهرة مع الشلّة</div>
<div class="games">برا السالفة • المافيا • صراحة ومين فينا</div></div></body></html>`

const SHOTS = [
  { file: '01-home', glow: 'var(--saffron)', title: 'ألعاب السهرة كلها في موبايل واحد', sub: 'برا السالفة • المافيا • صراحة ومين فينا' },
  { file: '12-outsider-reveal-out', glow: 'var(--coral)', title: 'واحد بس برا السالفة… اكشفوه!', sub: '٨٨٣ كلمة في ٢٤ قسم مصري وخليجي' },
  { file: '22-mafia-night', glow: 'var(--lavender)', title: 'المافيا براوي بصوت عربي', sub: 'الراوي بيدير الليل… والكل يلعب' },
  { file: '21-mafia-role', glow: 'var(--crimson)', title: 'كروت أدوار مرسومة', sub: 'مافيا • طبيب • محقق • قنّاص • مهرّج' },
  { file: '31-truth-card', glow: 'var(--mint)', title: 'صراحة ومين فينا', sub: '٤٢٠ سؤال يولّعوا القعدة' },
  { file: '17-outsider-guess', glow: 'var(--saffron)', title: 'من ٣ لـ ٢٠ لاعب', sub: 'مرّر الموبايل والعب… من غير إنترنت' },
]

const shotHtml = (s) => `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>${FONTS}
body{width:1080px;height:1920px;overflow:hidden;position:relative;
  background:radial-gradient(900px 700px at 50% 30%, color-mix(in srgb, ${s.glow} 30%, transparent), transparent 70%), var(--night)}
.head{position:absolute;top:120px;left:70px;right:70px;text-align:center}
.title{font-family:Lalezar;font-size:92px;line-height:1.15;color:var(--text);text-wrap:balance}
.sub{margin-top:18px;font-weight:600;font-size:42px;color:var(--muted)}
.phone{position:absolute;left:50%;top:470px;width:700px;height:1515px;transform:translateX(-50%);
  border-radius:78px;padding:16px;background:#0d0820;box-shadow:0 0 0 3px rgba(255,255,255,.10),0 40px 120px rgba(0,0,0,.55),0 0 160px color-mix(in srgb, ${s.glow} 35%, transparent)}
.phone img{width:100%;height:100%;object-fit:cover;object-position:top;border-radius:64px;display:block}
</style></head><body><div class="head"><div class="title">${s.title}</div><div class="sub">${s.sub}</div></div>
<div class="phone"><img src="${u(`qa-hd/${s.file}.png`)}"></div></body></html>`

const browser = await chromium.launch()
const page = await browser.newPage({ deviceScaleFactor: 1 })

async function render(name, html, w, h, dest) {
  const f = resolve(tmp, `${name}.html`)
  writeFileSync(f, html)
  await page.setViewportSize({ width: w, height: h })
  await page.goto(pathToFileURL(f).href)
  await page.evaluate(() => document.fonts.ready)
  await page.waitForTimeout(300)
  await page.screenshot({ path: dest, clip: { x: 0, y: 0, width: w, height: h } })
  console.log('→', dest)
}

await render('feature', feature, 1024, 500, resolve(out, 'feature-graphic.png'))
let i = 1
for (const s of SHOTS) {
  await render(`shot-${i}`, shotHtml(s), 1080, 1920, resolve(out, 'screenshots', `0${i}-${s.file.replace(/^\d+b?-/, '')}.png`))
  i++
}
await browser.close()
