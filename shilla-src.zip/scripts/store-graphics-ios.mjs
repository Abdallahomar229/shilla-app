// يرسم صور المتجر بالخطوط الحقيقية (العربي بيتشكّل صح في كروميوم):
//   store/screenshots-ios/0N-*.png (1290×2796) — لقطات آب ستور (آيفون 6.9 بوصة)
// node scripts/store-graphics.mjs   (محتاج qa-hd/ من: DPR=3 QA_DIR=qa-hd node scripts/qa.mjs)
import { writeFileSync, mkdirSync } from 'node:fs'
import { resolve, dirname } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { chromium } = require('playwright')
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const out = resolve(root, 'store')
const tmp = resolve(out, '_tmp')
mkdirSync(resolve(out, 'screenshots-ios'), { recursive: true })
mkdirSync(tmp, { recursive: true })

const u = (p) => pathToFileURL(resolve(root, p)).href
const FONTS = `
@font-face{font-family:Lalezar;src:url(${u('src/assets/fonts/lalezar-arabic-400-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:400;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-400-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:600;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-600-normal.woff2')}) format('woff2')}
@font-face{font-family:Baloo;font-weight:800;src:url(${u('src/assets/fonts/baloo-bhaijaan-2-arabic-800-normal.woff2')}) format('woff2')}
:root{--night:#1A1033;--saffron:#FFC531;--coral:#FF6B5B;--mint:#3FE0C5;--crimson:#E8344E;--lavender:#B9A8FF;--text:#FFF7EA;--muted:#BDB2DF}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--night)}
body{font-family:Baloo,sans-serif;color:var(--text);direction:rtl}
.dots{display:inline-flex;gap:.12em;vertical-align:top;margin-inline-start:.08em}
.dots i{display:block;width:.17em;height:.17em;border-radius:50%}
`

const SHOTS = [
  { file: '01-home', glow: 'var(--saffron)', title: 'ألعاب السهرة كلها في موبايل واحد', sub: 'برا السالفة • المافيا • صراحة ومين فينا' },
  { file: '12-outsider-reveal-out', glow: 'var(--coral)', title: 'واحد بس برا السالفة… اكشفوه!', sub: '٨٨٣ كلمة في ٢٤ قسم مصري وخليجي' },
  { file: '22-mafia-night', glow: 'var(--lavender)', title: 'المافيا براوي بصوت عربي', sub: 'الراوي بيدير الليل… والكل يلعب' },
  { file: '21-mafia-role', glow: 'var(--crimson)', title: 'كروت أدوار مرسومة', sub: 'مافيا • طبيب • محقق • قنّاص • مهرّج' },
  { file: '31-truth-card', glow: 'var(--mint)', title: 'صراحة ومين فينا', sub: '٤٢٠ سؤال يولّعوا القعدة' },
  { file: '17-outsider-guess', glow: 'var(--saffron)', title: 'من ٣ لـ ٢٠ لاعب', sub: 'مرّر الموبايل والعب… من غير إنترنت' },
]

const shotHtml = (s) => `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>${FONTS}
body{width:1290px;height:2796px;overflow:hidden;position:relative;
  background:radial-gradient(1100px 900px at 50% 28%, color-mix(in srgb, ${s.glow} 30%, transparent), transparent 70%), var(--night)}
.head{position:absolute;top:190px;left:80px;right:80px;text-align:center}
.title{font-family:Lalezar;font-size:116px;line-height:1.15;color:var(--text);text-wrap:balance}
.sub{margin-top:26px;font-weight:600;font-size:52px;color:var(--muted)}
.phone{position:absolute;left:50%;top:700px;width:960px;height:2077px;transform:translateX(-50%);
  border-radius:120px;padding:22px;background:#0d0820;box-shadow:0 0 0 4px rgba(255,255,255,.10),0 50px 150px rgba(0,0,0,.55),0 0 200px color-mix(in srgb, ${s.glow} 35%, transparent)}
.phone img{width:100%;height:100%;object-fit:cover;object-position:top;border-radius:98px;display:block}
</style></head><body><div class="head"><div class="title">${s.title}</div><div class="sub">${s.sub}</div></div>
<div class="phone"><img src="${u(`qa-hd/${s.file}.png`)}"></div></body></html>`

const browser = await chromium.launch()
const page = await browser.newPage({ deviceScaleFactor: 1 })
let i = 1
for (const s of SHOTS) {
  const f = resolve(tmp, `ios-shot-${i}.html`)
  writeFileSync(f, shotHtml(s))
  await page.setViewportSize({ width: 1290, height: 2796 })
  await page.goto(pathToFileURL(f).href)
  await page.evaluate(() => document.fonts.ready)
  await page.waitForTimeout(300)
  const dest = resolve(out, 'screenshots-ios', `0${i}-${s.file.replace(/^\d+b?-/, '')}.png`)
  await page.screenshot({ path: dest, clip: { x: 0, y: 0, width: 1290, height: 2796 } })
  console.log('→', dest)
  i++
}
await browser.close()
