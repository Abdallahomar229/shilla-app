// QA آلي: يلعب كل الألعاب على مقاس موبايل ويتأكد إن مفيش أخطاء في الكونسول
// node scripts/qa.mjs            (بيستخدم dist/)
// node scripts/qa.mjs --preview  (بيختبر preview/shilla.html جوه هيكل زي الـArtifact)
import { createServer } from 'node:http'
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { resolve, dirname, extname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { chromium } = require('playwright')

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const previewMode = process.argv.includes('--preview')
// --native: يختبر بناء أندرويد (android/build/assets/www) مع جسر ShillaNative مزيّف
const nativeMode = process.argv.includes('--native')
const qaDir = resolve(root, process.env.QA_DIR || 'qa')

// جسر مزيّف بنفس شكل MainActivity.Bridge: بيسجّل الجمل اللي اتقالت ويرد «خلصت» بعد شوية
const FAKE_BRIDGE = `
  window.__nativeLog = { spoken: [], vibrations: 0, stops: 0, opened: 0 };
  window.ShillaNative = {
    ttsStatus: () => Number(sessionStorage.getItem('__fakeTts') || 1),
    speak: (text, rate, id) => { window.__nativeLog.spoken.push(text); setTimeout(() => window.__shillaTtsDone && window.__shillaTtsDone(id), 40); },
    stop: () => { window.__nativeLog.stops++; },
    vibrate: (ms) => { window.__nativeLog.vibrations++; },
    openTtsSettings: () => { window.__nativeLog.opened++; },
    platform: () => 'android',
    billing: (action, payload, cb) => {
      const reply = (o) => setTimeout(() => window.__shillaBilling && window.__shillaBilling(cb, JSON.stringify(o)), 60);
      if (action === 'offerings') return reply({ ok: true, available: true, plans: [
        { id: 'weekly', price: '٤٩٫٩٩ ج.م.' }, { id: 'yearly', price: '٣٩٩٫٩٩ ج.م.' }, { id: 'lifetime', price: '٦٩٩٫٩٩ ج.م.' } ] });
      if (action === 'purchase') { sessionStorage.setItem('__fakeEnt', '1'); setTimeout(() => window.__shillaEntitlement && window.__shillaEntitlement(true), 30); return reply({ ok: true, entitled: true }); }
      if (action === 'restore') { const ent = sessionStorage.getItem('__fakeEnt') === '1'; setTimeout(() => window.__shillaEntitlement && window.__shillaEntitlement(ent), 30); return reply({ ok: true, entitled: ent }); }
      reply({ ok: false, reason: 'bad_action' });
    },
  };
`
mkdirSync(qaDir, { recursive: true })

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' }

function serve() {
  const base = nativeMode ? resolve(root, 'android/app/src/main/assets/www') : resolve(root, 'dist')
  const wrapper = () => {
    const body = readFileSync(resolve(root, 'preview/shilla.html'), 'utf8')
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>${body}</body></html>`
  }
  const server = createServer((req, res) => {
    const url = decodeURIComponent((req.url || '/').split('?')[0])
    if (previewMode) {
      res.writeHead(200, { 'content-type': TYPES['.html'] })
      res.end(wrapper())
      return
    }
    let file = join(base, url === '/' ? 'index.html' : url)
    if (!existsSync(file)) file = join(base, 'index.html')
    res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream' })
    res.end(readFileSync(file))
  })
  return new Promise((r) => server.listen(0, '127.0.0.1', () => r(server)))
}

const errors = []
const log = (...a) => console.log('•', ...a)

async function main() {
  const server = await serve()
  const port = server.address().port
  const browser = await chromium.launch()
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: Number(process.env.DPR || 1), hasTouch: true, isMobile: true, locale: 'ar' })
  if (nativeMode) await ctx.addInitScript(FAKE_BRIDGE)
  const page = await ctx.newPage()
  page.on('console', (m) => {
    if (m.type() === 'error' || m.type() === 'warning') errors.push(`[console.${m.type()}] ${m.text()}`)
  })
  page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`))

  await page.goto(`http://127.0.0.1:${port}/`)
  await page.waitForSelector('.game-card')
  await page.waitForTimeout(700)

  const top = () => page.locator('.layer.top')
  const btn = (name, exact = false) => top().getByRole('button', { name, exact })
  const click = async (name, exact = false) => {
    await btn(name, exact).first().click()
    await page.waitForTimeout(120)
  }
  const shot = async (name) => {
    await page.waitForTimeout(650)
    await page.screenshot({ path: resolve(qaDir, `${name}.png`) })
  }
  const visible = async (name, exact = false) => (await btn(name, exact).count()) > 0 && (await btn(name, exact).first().isVisible())
  const noHScroll = async (label) => {
    const over = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)
    if (over > 1) errors.push(`[layout] horizontal overflow ${over}px on ${label}`)
  }

  // ── الرئيسية
  await shot('01-home')
  await noHScroll('home')
  log('home ok')

  // ── اللاعيبة: نضيف ٣ (المجموع ٧)
  await top().locator('.players-row').click()
  for (const n of ['خالد', 'منى', 'يوسف']) {
    await top().locator('#new-player').fill(n)
    await click('ضيف')
  }
  const count = await top().locator('.player-row').count()
  if (count !== 7) errors.push(`[players] expected 7 got ${count}`)
  await top().locator('.player-row').nth(6).getByRole('button', { name: /لفوق/ }).click()
  await shot('02-players')
  await noHScroll('players')
  await click('تمام')
  log('players ok', count)

  // ── الإعدادات: وضع التجربة + مسح البيانات (إلغاء)
  await page.getByRole('button', { name: 'الإعدادات' }).click()
  await page.waitForTimeout(200)
  await top().locator('#set-test-plus').click()
  await top().locator('#set-sfx').click()
  await top().locator('#set-sfx').click()
  await top().getByRole('button', { name: 'مسح البيانات' }).click()
  await page.waitForTimeout(250)
  await page.getByRole('dialog').getByRole('button', { name: 'لأ، سيبها' }).click()
  await shot('03-settings')
  await noHScroll('settings')
  await top().getByRole('button', { name: 'رجوع' }).click()
  await page.waitForTimeout(300)
  log('settings ok')

  // ── شلّة بلس
  await page.locator('.plus-chip').click()
  await page.waitForTimeout(250)
  await top().getByRole('radio', { name: /مدى الحياة/ }).click()
  await click('اشترك في شلّة بلس')
  await shot('04-paywall')
  await noHScroll('paywall')
  // في نسخة أندرويد (الجسر المزيّف) الشراء بينجح ويقفل الشاشة لوحده
  if (await top().getByRole('button', { name: 'اقفل' }).count()) await top().getByRole('button', { name: 'اقفل' }).click()
  await page.waitForTimeout(300)
  if (!(await page.locator('.layer.top .game-card').count())) errors.push('[paywall] close did not return home')
  log('paywall ok')

  // ── برا السالفة
  await top().locator('.game-outsider').click()
  await page.waitForTimeout(250)
  await top().getByRole('button', { name: /أكلات مصرية/ }).click()
  await top().getByRole('button', { name: /^حيوانات/ }).click()
  await top().getByRole('radio', { name: 'دقيقة', exact: true }).click()
  await top().getByRole('radio', { name: 'اتنين' }).click()
  await top().getByRole('radio', { name: 'واحد' }).click()
  await shot('10-outsider-setup')
  await noHScroll('outsider setup')
  await click('ابدأ الجولة')
  let shotWord = false
  let shotOut = false
  for (let i = 0; i < 7; i++) {
    await click('اكشف', true)
    const out = (await top().locator('.reveal-card.is-out').count()) > 0
    if (out && !shotOut) {
      await shot('12-outsider-reveal-out')
      shotOut = true
    }
    if (!out && !shotWord) {
      await shot('11-outsider-reveal-word')
      shotWord = true
    }
    await top().locator('.actions .btn').first().click()
    await page.waitForTimeout(120)
  }
  await shot('13-outsider-questions')
  for (let i = 0; i < 6; i++) await click('التالي')
  await click('جولة أسئلة كمان')
  await click('التالي')
  await click('نصوّت على طول')
  for (let i = 0; i < 7; i++) {
    await click('صوّت', true)
    if (i === 0) await shot('14-outsider-vote-pass')
    await top().locator('.vote-btn').nth(i % 3).click()
    if (i === 0) await shot('14b-outsider-vote')
    await click('تأكيد التصويت')
  }
  await shot('15-outsider-results')
  await click('اكشف اللي برا السالفة')
  await shot('16-outsider-unmask')
  await top().locator('.actions .btn').first().click()
  await page.waitForTimeout(150)
  await top().locator('.guess-btn').first().click()
  await shot('17-outsider-guess')
  await click('شوف النقط')
  await shot('18-outsider-score')
  await noHScroll('outsider score')
  await click('جولة جديدة')
  await page.waitForTimeout(200)
  if (!(await visible('اكشف', true))) errors.push('[outsider] new round did not start')
  // الرجوع أثناء اللعب لازم يسأل
  await page.goBack()
  await page.waitForTimeout(350)
  const dlg = page.getByRole('dialog')
  if (!(await dlg.count())) errors.push('[guard] back during game did not ask')
  else {
    await shot('19-exit-confirm')
    await dlg.getByRole('button', { name: 'أيوه، اخرج' }).click()
    await page.waitForTimeout(500)
  }
  if (!(await page.locator('.layer.top .game-card').count())) errors.push('[guard] confirm exit did not return home')
  log('outsider ok')

  // ── المافيا: نشيل لاعب (٦)
  await top().locator('.players-row').click()
  await top().locator('.player-row').last().getByRole('button', { name: /امسح/ }).click()
  await click('تمام')
  await top().locator('.game-mafia').click()
  await page.waitForTimeout(250)
  await top().locator('#role-jester').click()
  await top().locator('#role-jester').click()
  await shot('20-mafia-setup')
  await noHScroll('mafia setup')
  await click('وزّع الأدوار')
  for (let i = 0; i < 6; i++) {
    await click('اكشف دوري')
    if (i === 0) await shot('21-mafia-role')
    await top().locator('.actions .btn').first().click()
    await page.waitForTimeout(120)
  }
  await shot('21b-mafia-ready')
  await click('ابدأ الليل')
  let ended = false
  let shotNight = false
  let shotAct = false
  let shotMorning = false
  let shotDay = false
  let shotResult = false
  for (let step = 0; step < 400 && !ended; step++) {
    if (await visible('النتيجة')) {
      await click('النتيجة')
      ended = true
      break
    }
    if (await visible('تمام، عرفت')) {
      if (!shotResult) {
        await shot('23b-mafia-detective')
        shotResult = true
      }
      await click('تمام، عرفت')
      continue
    }
    if (await visible('مش هضرب الليلة')) {
      await click('مش هضرب الليلة')
      continue
    }
    if ((await top().locator('.vote-grid.night').count()) > 0) {
      if (!shotAct) {
        await shot('23-mafia-night-act')
        shotAct = true
      }
      await top().locator('.vote-grid.night .vote-btn').first().click()
      await click('تأكيد', true)
      continue
    }
    if (await visible('التالي')) {
      if (!shotNight) {
        await shot('22-mafia-night')
        shotNight = true
      }
      await click('التالي')
      continue
    }
    if (await visible('يلا النقاش')) {
      if (!shotMorning) {
        await shot('24-mafia-morning')
        shotMorning = true
      }
      await click('يلا النقاش')
      continue
    }
    if (await visible('خلصنا نقاش')) {
      if (!shotDay) {
        await shot('25-mafia-day')
        shotDay = true
      }
      await click('وقّف')
      await click('كمّل')
      await click('خلصنا نقاش')
      continue
    }
    if ((await top().locator('.vote-grid:not(.night)').count()) > 0 && (await visible('تأكيد', true))) {
      await top().locator('.vote-grid .vote-btn').first().click()
      await click('تأكيد', true)
      continue
    }
    if (await visible('الليل')) {
      await click('الليل')
      continue
    }
    await page.waitForTimeout(500) // دور خرج: انتظار عشوائي ٥–٨ ثواني
  }
  if (!ended) errors.push('[mafia] game did not reach an end')
  await shot('26-mafia-end')
  await noHScroll('mafia end')
  await click('العب تاني')
  await page.waitForTimeout(200)
  if (!(await visible('اكشف دوري'))) errors.push('[mafia] play again did not deal roles')
  await page.goBack()
  await page.waitForTimeout(350)
  await page.getByRole('dialog').getByRole('button', { name: 'أيوه، اخرج' }).click()
  await page.waitForTimeout(500)
  log('mafia ok')

  // ── صراحة ومين فينا
  await top().locator('.game-truth').click()
  await page.waitForTimeout(250)
  await top().getByRole('radio', { name: 'صراحة' }).click()
  await shot('30-truth-packs')
  await top().getByRole('button', { name: /^للأصحاب/ }).click()
  await shot('31-truth-card')
  for (let i = 0; i < 4; i++) await click('التالي')
  await click('تخطّي')
  await noHScroll('truth card')
  await click('الباقات')
  await top().getByRole('radio', { name: 'مين فينا؟' }).click()
  await top().getByRole('button', { name: /^مين فينا؟/ }).first().click()
  await click('شاوروا')
  await page.waitForTimeout(900)
  await shot('32-who-count')
  await page.waitForTimeout(2000)
  for (let i = 0; i < 3; i++) await click('التالي')
  await shot('33-who-card')
  log('truth ok')

  let native = null
  if (nativeMode) {
    native = await page.evaluate(() => ({ ...window.__nativeLog, spoken: window.__nativeLog.spoken.length, sample: window.__nativeLog.spoken.slice(0, 3) }))
    log('native bridge', JSON.stringify(native))
    if (!native.spoken) errors.push('[native] الراوي منطقش ولا جملة عن طريق الجسر')
    if (!native.vibrations) errors.push('[native] الاهتزاز معداش على الجسر')
    // الدفع: الأسعار جاية من المتجر، والشراء بيفعّل «بلس» (نبدأ من غير اشتراك)
    await page.evaluate(() => sessionStorage.removeItem('__fakeEnt'))
    await page.goto(page.url().split('#')[0])
    await page.waitForSelector('.game-card')
    await page.locator('.plus-chip').first().click()
    await page.waitForSelector('.plan-price')
    await page.waitForTimeout(400)
    const prices = await page.$$eval('.plan-price', (els) => els.map((e) => e.textContent))
    if (!prices.some((p) => p.includes('ج.م'))) errors.push('[native] أسعار المتجر مظهرتش: ' + prices.join(' | '))
    await shot('41-native-paywall')
    await page.getByRole('button', { name: /اشترك في شلّة بلس/ }).click()
    await page.waitForTimeout(800)
    await page.locator('.plus-chip').first().click()
    const good = await page.locator('.pay-note.good').count()
    if (!good) errors.push('[native] «بلس» متفعّلش بعد الشراء')
    await shot('42-native-paid')
    // لو مفيش صوت عربي: لازم يظهر زرار تنزيل الصوت في الإعدادات ويشتغل
    await page.evaluate(() => sessionStorage.setItem('__fakeTts', '-1'))
    await page.goto(page.url().split('#')[0])
    await page.waitForSelector('.game-card')
    await page.getByRole('button', { name: 'الإعدادات' }).click()
    const dl = page.getByRole('button', { name: /نزّل الصوت العربي/ })
    await dl.waitFor({ timeout: 8000 }).catch(() => errors.push('[native] زرار تنزيل الصوت العربي مظهرش'))
    if (await dl.count()) {
      await dl.first().click()
      const opened = await page.evaluate(() => window.__nativeLog.opened)
      if (!opened) errors.push('[native] زرار تنزيل الصوت مفتحش الإعدادات')
      await shot('40-native-no-voice')
    }
  }

  await browser.close()
  server.close()

  const report = { previewMode, nativeMode, native, errors }
  writeFileSync(resolve(qaDir, nativeMode ? 'report-native.json' : previewMode ? 'report-preview.json' : 'report.json'), JSON.stringify(report, null, 2))
  if (errors.length) {
    console.log('\nERRORS:\n' + errors.join('\n'))
    process.exitCode = 1
  } else console.log('\nQA PASSED — 0 console errors')
}

main().catch((e) => {
  console.error(e)
  console.log(errors.join('\n'))
  process.exit(1)
})
