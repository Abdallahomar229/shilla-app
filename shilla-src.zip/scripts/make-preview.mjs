// يحوّل dist-single/index.html لصفحة معاينة تناسب «Artifact»:
// من غير doctype/html/head/body، وفي الأول <title> و meta viewport-fit-sides
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const src = readFileSync(resolve(root, 'dist-single/index.html'), 'utf8')

const styles = [...src.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/g)].map((m) => m[1])
const scripts = [...src.matchAll(/<script type="module"[^>]*>([\s\S]*?)<\/script>/g)].map((m) => m[1])

if (!styles.length || !scripts.length) {
  console.error('ملقيتش style أو script في dist-single/index.html')
  process.exit(1)
}

for (const s of scripts) {
  if (/<\/script/i.test(s)) {
    console.error('الكود فيه </script> وده هيبوّظ الصفحة')
    process.exit(1)
  }
}

const out = [
  '<title>شلّة</title>',
  '<meta name="claude:viewport-fit-sides" content="cover">',
  `<style>${styles.join('\n')}</style>`,
  '<div id="root"></div>',
  `<script type="module">${scripts.join('\n')}</script>`,
  '',
].join('\n')

mkdirSync(resolve(root, 'preview'), { recursive: true })
const dest = resolve(root, 'preview/shilla.html')
writeFileSync(dest, out)
console.log(`preview → ${dest} (${(Buffer.byteLength(out) / 1024).toFixed(0)} KB)`)
