#!/usr/bin/env bash
# يوقّع ملفات البناء السحابي (GitHub Actions) بمفتاح الرفع — المفتاح مبيطلعش على GitHub.
# الاستخدام: bash android/sign.sh <unsigned.aab> <unsigned.apk> <اسم الإصدار مثلاً 1.0.2>
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(dirname "$HERE")"
SDK="${ANDROID_SDK:-/opt/android-sdk}"
BT="$SDK/build-tools/36.1.0"
KS="$HERE/keystore/shilla-upload.jks"
PASS="$HERE/keystore/password.txt"
AAB_IN="$1"
APK_IN="$2"
NAME="shilla-$3"
OUT="$ROOT/release"
mkdir -p "$OUT"

cp "$AAB_IN" "$OUT/$NAME.aab"
jarsigner -keystore "$KS" -storepass:file "$PASS" -sigalg SHA256withRSA -digestalg SHA-256 "$OUT/$NAME.aab" upload > /dev/null
jarsigner -verify "$OUT/$NAME.aab" > /dev/null && echo "AAB signed: $OUT/$NAME.aab"

"$BT/zipalign" -p -f 4 "$APK_IN" "$OUT/.aligned.apk"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias upload --ks-pass "file:$PASS" --out "$OUT/$NAME.apk" "$OUT/.aligned.apk"
rm -f "$OUT/.aligned.apk" "$OUT/$NAME.apk.idsig"
"$BT/apksigner" verify "$OUT/$NAME.apk" && echo "APK signed: $OUT/$NAME.apk"
