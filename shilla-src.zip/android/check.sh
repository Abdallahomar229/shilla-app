#!/usr/bin/env bash
# فحص سريع إن كود الجافا بيتجمّع صح ضد Android 36 ومكتبة الدفع (من غير Gradle).
# البناء الحقيقي بيتم في GitHub Actions (.github/workflows/android.yml)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK:-/opt/android-sdk}"
JAR="$SDK/platforms/android-36/android.jar"
LIB="$HERE/build/check-libs"
OUT="$HERE/build/check-classes"
mkdir -p "$LIB" "$OUT"
BILLING=9.1.0
if [ ! -f "$LIB/billing-$BILLING.jar" ]; then
  curl -sS -o "$LIB/billing.aar" "https://dl.google.com/dl/android/maven2/com/android/billingclient/billing/$BILLING/billing-$BILLING.aar"
  (cd "$LIB" && unzip -q -o billing.aar classes.jar && mv classes.jar "billing-$BILLING.jar" && rm billing.aar)
fi
rm -rf "$OUT" && mkdir -p "$OUT"
javac -source 17 -target 17 -classpath "$JAR:$LIB/billing-$BILLING.jar" -encoding UTF-8 -Xlint:-options \
  -d "$OUT" $(find "$HERE/app/src/main/java" -name '*.java') 2>&1 | grep -v "JAVA_TOOL_OPTIONS" || true
ls "$OUT/com/shilla/games" | head -20
