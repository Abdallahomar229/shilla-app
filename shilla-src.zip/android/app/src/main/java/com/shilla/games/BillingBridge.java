package com.shilla.games;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * «شلّة بلس» عن طريق Google Play Billing.
 * الجافاسكريبت بتنادي: ShillaNative.billing(action, payloadJson, callbackId)
 * والنتيجة بترجع لـ window.__shillaBilling(callbackId, resultJson)
 *
 * المنتجات في Play Console:
 *   plus_weekly   — اشتراك أسبوعي
 *   plus_yearly   — اشتراك سنوي
 *   plus_lifetime — شراء مرة واحدة
 */
final class BillingBridge implements PurchasesUpdatedListener {

    static final String SUB_WEEKLY = "plus_weekly";
    static final String SUB_YEARLY = "plus_yearly";
    static final String LIFETIME = "plus_lifetime";
    static final List<String> SUBS = Arrays.asList(SUB_WEEKLY, SUB_YEARLY);
    static final List<String> ALL = Arrays.asList(SUB_WEEKLY, SUB_YEARLY, LIFETIME);

    interface Done {
        void run(boolean ok);
    }

    final MainActivity act;
    final BillingClient client;
    final Map<String, ProductDetails> details = new HashMap<String, ProductDetails>();
    final List<Done> waiting = new ArrayList<Done>();
    boolean connecting = false;
    /** الكولباك بتاع عملية الشراء اللي شغالة دلوقتي (واحدة بس في المرة) */
    String purchaseCb = null;

    BillingBridge(MainActivity a) {
        act = a;
        client = BillingClient.newBuilder(a.getApplicationContext())
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    static String planToProduct(String plan) {
        if ("weekly".equals(plan)) return SUB_WEEKLY;
        if ("yearly".equals(plan)) return SUB_YEARLY;
        if ("lifetime".equals(plan)) return LIFETIME;
        return null;
    }

    static String productToPlan(String product) {
        if (SUB_WEEKLY.equals(product)) return "weekly";
        if (SUB_YEARLY.equals(product)) return "yearly";
        if (LIFETIME.equals(product)) return "lifetime";
        return null;
    }

    // ───────── نقطة الدخول من الجافاسكريبت (على الـUI thread) ─────────
    void handle(String action, String payload, final String cb) {
        if ("offerings".equals(action)) {
            offerings(cb);
        } else if ("purchase".equals(action)) {
            String plan = null;
            try {
                plan = new JSONObject(payload == null ? "{}" : payload).optString("planId", null);
            } catch (Exception ignored) {
            }
            purchase(plan, cb);
        } else if ("restore".equals(action)) {
            restore(cb, true);
        } else {
            reply(cb, fail("bad_action", "حصلت مشكلة، جرّب تاني"));
        }
    }

    // ───────── الاتصال بجوجل بلاي ─────────
    void ensureReady(Done d) {
        if (client.isReady()) {
            d.run(true);
            return;
        }
        waiting.add(d);
        if (connecting) return;
        connecting = true;
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(final BillingResult result) {
                act.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        connecting = false;
                        boolean ok = result.getResponseCode() == BillingClient.BillingResponseCode.OK;
                        List<Done> list = new ArrayList<Done>(waiting);
                        waiting.clear();
                        for (Done w : list) w.run(ok);
                    }
                });
            }

            @Override
            public void onBillingServiceDisconnected() {
                act.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        connecting = false;
                        List<Done> list = new ArrayList<Done>(waiting);
                        waiting.clear();
                        for (Done w : list) w.run(false);
                    }
                });
            }
        });
    }

    // ───────── الأسعار ─────────
    void loadDetails(final Done d) {
        final int[] left = {2};
        final Done one = new Done() {
            @Override
            public void run(boolean ok) {
                left[0]--;
                if (left[0] == 0) d.run(!details.isEmpty());
            }
        };
        query(BillingClient.ProductType.SUBS, SUBS, one);
        query(BillingClient.ProductType.INAPP, Collections.singletonList(LIFETIME), one);
    }

    void query(String type, List<String> ids, final Done d) {
        List<QueryProductDetailsParams.Product> products = new ArrayList<QueryProductDetailsParams.Product>();
        for (String id : ids) {
            products.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(type).build());
        }
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(products).build();
        client.queryProductDetailsAsync(params, new ProductDetailsResponseListener() {
            @Override
            public void onProductDetailsResponse(final BillingResult result, final QueryProductDetailsResult res) {
                act.ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && res != null) {
                            for (ProductDetails pd : res.getProductDetailsList()) {
                                details.put(pd.getProductId(), pd);
                            }
                        }
                        d.run(true);
                    }
                });
            }
        });
    }

    /** العرض الأساسي للاشتراك (من غير عروض تجريبية) */
    static ProductDetails.SubscriptionOfferDetails baseOffer(ProductDetails pd) {
        List<ProductDetails.SubscriptionOfferDetails> offers = pd.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) return null;
        for (ProductDetails.SubscriptionOfferDetails o : offers) {
            if (o.getOfferId() == null) return o;
        }
        return offers.get(0);
    }

    static String priceOf(ProductDetails pd) {
        if (pd == null) return null;
        if (BillingClient.ProductType.SUBS.equals(pd.getProductType())) {
            ProductDetails.SubscriptionOfferDetails o = baseOffer(pd);
            if (o == null) return null;
            List<ProductDetails.PricingPhase> phases = o.getPricingPhases().getPricingPhaseList();
            if (phases == null || phases.isEmpty()) return null;
            return phases.get(phases.size() - 1).getFormattedPrice();
        }
        ProductDetails.OneTimePurchaseOfferDetails one = pd.getOneTimePurchaseOfferDetails();
        return one == null ? null : one.getFormattedPrice();
    }

    void offerings(final String cb) {
        ensureReady(new Done() {
            @Override
            public void run(boolean ok) {
                if (!ok) {
                    reply(cb, fail("unavailable", "متجر جوجل مش متاح دلوقتي"));
                    return;
                }
                loadDetails(new Done() {
                    @Override
                    public void run(boolean any) {
                        try {
                            JSONObject out = new JSONObject();
                            JSONArray plans = new JSONArray();
                            for (String id : ALL) {
                                JSONObject p = new JSONObject();
                                p.put("id", productToPlan(id));
                                String price = priceOf(details.get(id));
                                p.put("price", price == null ? JSONObject.NULL : price);
                                plans.put(p);
                            }
                            out.put("ok", true);
                            out.put("available", any);
                            out.put("plans", plans);
                            reply(cb, out);
                        } catch (Exception e) {
                            reply(cb, fail("error", "حصلت مشكلة، جرّب تاني"));
                        }
                    }
                });
            }
        });
    }

    // ───────── الشراء ─────────
    void purchase(final String plan, final String cb) {
        final String productId = planToProduct(plan);
        if (productId == null) {
            reply(cb, fail("bad_plan", "اختار خطة الأول"));
            return;
        }
        if (purchaseCb != null) {
            reply(cb, fail("busy", "فيه عملية شراء شغالة بالفعل"));
            return;
        }
        ensureReady(new Done() {
            @Override
            public void run(boolean ok) {
                if (!ok) {
                    reply(cb, fail("unavailable", "متجر جوجل مش متاح دلوقتي"));
                    return;
                }
                if (details.get(productId) != null) {
                    launch(productId, cb);
                } else {
                    loadDetails(new Done() {
                        @Override
                        public void run(boolean any) {
                            launch(productId, cb);
                        }
                    });
                }
            }
        });
    }

    void launch(String productId, String cb) {
        ProductDetails pd = details.get(productId);
        if (pd == null) {
            reply(cb, fail("unavailable", "الخطة دي مش متاحة دلوقتي"));
            return;
        }
        BillingFlowParams.ProductDetailsParams.Builder b =
                BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd);
        if (BillingClient.ProductType.SUBS.equals(pd.getProductType())) {
            ProductDetails.SubscriptionOfferDetails o = baseOffer(pd);
            if (o == null) {
                reply(cb, fail("unavailable", "الخطة دي مش متاحة دلوقتي"));
                return;
            }
            b.setOfferToken(o.getOfferToken());
        } else {
            ProductDetails.OneTimePurchaseOfferDetails one = pd.getOneTimePurchaseOfferDetails();
            if (one != null && one.getOfferToken() != null) b.setOfferToken(one.getOfferToken());
        }
        BillingFlowParams params = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(b.build()))
                .build();
        purchaseCb = cb;
        BillingResult r = client.launchBillingFlow(act, params);
        if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            purchaseCb = null;
            if (r.getResponseCode() == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                restore(cb, false);
            } else {
                reply(cb, fail("error", "الشراء ماتمّش، جرّب تاني"));
            }
        }
    }

    @Override
    public void onPurchasesUpdated(final BillingResult result, final List<Purchase> purchases) {
        act.ui.post(new Runnable() {
            @Override
            public void run() {
                String cb = purchaseCb;
                purchaseCb = null;
                int code = result.getResponseCode();
                if (code == BillingClient.BillingResponseCode.OK) {
                    int state = process(purchases);
                    if (state == 1) {
                        act.setEntitled(true);
                        if (cb != null) reply(cb, success(true));
                    } else if (state == 0) {
                        if (cb != null) reply(cb, fail("pending", "الدفع لسه بيتأكد… «بلس» هيتفعّل أول ما يخلص"));
                    } else if (cb != null) {
                        reply(cb, fail("error", "الشراء ماتمّش، جرّب تاني"));
                    }
                } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
                    if (cb != null) reply(cb, fail("cancel", "اتلغى الشراء"));
                } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                    if (cb != null) restore(cb, false);
                } else if (cb != null) {
                    reply(cb, fail("error", "الشراء ماتمّش، جرّب تاني"));
                }
            }
        });
    }

    /** 1 = فيه شراء مكتمل لـ«بلس»، 0 = فيه شراء معلّق، ‎-1 = مفيش */
    int process(List<Purchase> purchases) {
        int best = -1;
        if (purchases == null) return best;
        for (Purchase p : purchases) {
            boolean plus = false;
            for (String id : p.getProducts()) {
                if (ALL.contains(id)) plus = true;
            }
            if (!plus) continue;
            if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                best = 1;
                if (!p.isAcknowledged()) acknowledge(p);
            } else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING && best < 0) {
                best = 0;
            }
        }
        return best;
    }

    void acknowledge(Purchase p) {
        AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(p.getPurchaseToken())
                .build();
        client.acknowledgePurchase(params, new AcknowledgePurchaseResponseListener() {
            @Override
            public void onAcknowledgePurchaseResponse(BillingResult r) {
                // لو فشل هيتعاد في أول استرجاع جاي (جوجل بيدّي 3 أيام)
            }
        });
    }

    // ───────── الاسترجاع (وكمان فحص الاشتراك أول ما التطبيق يفتح) ─────────
    void restore(final String cb, final boolean announce) {
        ensureReady(new Done() {
            @Override
            public void run(boolean ok) {
                if (!ok) {
                    reply(cb, fail("unavailable", "متجر جوجل مش متاح دلوقتي"));
                    return;
                }
                final List<Purchase> all = new ArrayList<Purchase>();
                final int[] left = {2};
                final boolean[] failed = {false};
                PurchasesResponseListener collect = new PurchasesResponseListener() {
                    @Override
                    public void onQueryPurchasesResponse(final BillingResult r, final List<Purchase> list) {
                        act.ui.post(new Runnable() {
                            @Override
                            public void run() {
                                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                                    if (list != null) all.addAll(list);
                                } else {
                                    failed[0] = true;
                                }
                                left[0]--;
                                if (left[0] > 0) return;
                                if (failed[0]) {
                                    reply(cb, fail("error", "مقدرناش نوصل لمشترياتك دلوقتي"));
                                    return;
                                }
                                boolean entitled = process(all) == 1;
                                act.setEntitled(entitled);
                                reply(cb, success(entitled));
                            }
                        });
                    }
                };
                client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.SUBS).build(), collect);
                client.queryPurchasesAsync(QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.INAPP).build(), collect);
            }
        });
    }

    // ───────── مساعدات ─────────
    static JSONObject success(boolean entitled) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", true);
            o.put("entitled", entitled);
        } catch (Exception ignored) {
        }
        return o;
    }

    static JSONObject fail(String reason, String message) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", false);
            o.put("reason", reason);
            o.put("message", message);
        } catch (Exception ignored) {
        }
        return o;
    }

    void reply(String cb, JSONObject result) {
        if (cb == null) return;
        act.js("window.__shillaBilling&&window.__shillaBilling(" + JSONObject.quote(cb) + ","
                + JSONObject.quote(result.toString()) + ")");
    }

    void end() {
        try {
            client.endConnection();
        } catch (Exception ignored) {
        }
    }
}
