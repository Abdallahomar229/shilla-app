package com.shilla.games;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * «شلّة» — غلاف أندرويد بسيط:
 * WebView بيعرض اللعبة من ملفات التطبيق (من غير إنترنت) على عنوان https داخلي،
 * وجسر صغير للجافاسكريبت: نطق الراوي بالعربي، الاهتزاز، وفتح إعدادات الصوت.
 */
public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + HOST + "/index.html";
    static final int NIGHT = 0xFF1A1033;

    WebView web;
    TextToSpeech tts;
    BillingBridge billing;
    AdsBridge ads;
    /** 0 = لسه بيحمّل، 1 = جاهز بالعربي، ‎-1 = مفيش صوت عربي */
    volatile int ttsStatus = 0;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(NIGHT);
        web = new WebView(this);
        web.setBackgroundColor(NIGHT);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 30) {
            Api30.edgeToEdge(w, root);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setWebViewClient(new LocalClient());
        web.addJavascriptInterface(new Bridge(), "ShillaNative");

        initTts();
        billing = new BillingBridge(this);
        ads = new AdsBridge(this);
        if (Build.VERSION.SDK_INT >= 33) {
            Api33.registerBack(this);
        }

        if (state != null) {
            web.restoreState(state);
        }
        if (web.getUrl() == null) {
            web.loadUrl(START_URL);
        }
    }

    // ───────── الرجوع ─────────
    void handleBack() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            finish();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // أندرويد 12 وأقل (من 13 وطالع بيتعامل معاه Api33)
        handleBack();
    }

    // ───────── الراوي (نطق الكلام) ─────────
    void initTts() {
        ttsStatus = 0;
        try {
            tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    TextToSpeech t = tts;
                    if (status != TextToSpeech.SUCCESS || t == null) {
                        ttsStatus = -1;
                        return;
                    }
                    int result = TextToSpeech.LANG_NOT_SUPPORTED;
                    Locale[] prefs = {new Locale("ar", "EG"), new Locale("ar", "SA"), new Locale("ar")};
                    for (Locale l : prefs) {
                        try {
                            result = t.setLanguage(l);
                        } catch (Exception e) {
                            result = TextToSpeech.LANG_NOT_SUPPORTED;
                        }
                        if (result >= TextToSpeech.LANG_AVAILABLE) break;
                    }
                    ttsStatus = result >= TextToSpeech.LANG_AVAILABLE ? 1 : -1;
                }
            });
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String id) {
                }

                @Override
                public void onDone(String id) {
                    done(id);
                }

                @Override
                @SuppressWarnings("deprecation")
                public void onError(String id) {
                    done(id);
                }

                @Override
                public void onError(String id, int code) {
                    done(id);
                }

                @Override
                public void onStop(String id, boolean interrupted) {
                    done(id);
                }
            });
        } catch (Exception e) {
            ttsStatus = -1;
        }
    }

    void done(final String id) {
        if (id == null) return;
        js("window.__shillaTtsDone&&window.__shillaTtsDone(" + JSONObject.quote(id) + ")");
    }

    /** ينفّذ جافاسكريبت في اللعبة (من أي thread) */
    void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    /** يبلّغ اللعبة إن «شلّة بلس» اتفعّل أو اتلغى */
    void setEntitled(boolean on) {
        js("window.__shillaEntitlement&&window.__shillaEntitlement(" + (on ? "true" : "false") + ")");
    }

    /** يبلّغ اللعبة إن الإعلان خلص (اتقفل أو مظهرش) */
    void adDone(boolean shown) {
        js("window.__shillaAdDone&&window.__shillaAdDone(" + (shown ? "true" : "false") + ")");
    }

    final class Bridge {
        @JavascriptInterface
        public int ttsStatus() {
            return ttsStatus;
        }

        @JavascriptInterface
        public void speak(String text, float rate, String id) {
            TextToSpeech t = tts;
            if (t == null || ttsStatus != 1 || text == null || text.isEmpty()) {
                done(id);
                return;
            }
            try {
                t.setSpeechRate(rate > 0.1f ? rate : 1f);
                int r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
                if (r != TextToSpeech.SUCCESS) done(id);
            } catch (Exception e) {
                done(id);
            }
        }

        @JavascriptInterface
        public void stop() {
            TextToSpeech t = tts;
            if (t != null) {
                try {
                    t.stop();
                } catch (Exception ignored) {
                }
            }
        }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                int d = Math.max(1, Math.min(ms, 1000));
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(d);
                }
            } catch (Exception ignored) {
            }
        }

        /** يفتح إعدادات نطق الكلام عشان المستخدم ينزّل الصوت العربي */
        @JavascriptInterface
        public void openTtsSettings() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA));
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public String platform() {
            return "android";
        }

        /** action = preload | interstitial */
        @JavascriptInterface
        public void ads(final String action) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (ads == null) return;
                    if ("interstitial".equals(action)) ads.show();
                    else ads.start();
                }
            });
        }

        /** «شلّة بلس»: action = offerings | purchase | restore */
        @JavascriptInterface
        public void billing(final String action, final String payload, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (billing != null) billing.handle(action, payload, cb);
                }
            });
        }
    }

    // ───────── تحميل ملفات اللعبة من جوه التطبيق ─────────
    final class LocalClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u == null || !HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.isEmpty() || "/".equals(path)) path = "/index.html";
            if (path.contains("..")) return notFound();
            try {
                InputStream in = getAssets().open("www" + path);
                WebResourceResponse r = new WebResourceResponse(mime(path), "UTF-8", in);
                Map<String, String> h = new HashMap<String, String>();
                h.put("Cache-Control", "no-cache");
                r.setResponseHeaders(h);
                return r;
            } catch (IOException e) {
                return notFound();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u != null && HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
            }
            return true;
        }
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    static String mime(String p) {
        String l = p.toLowerCase(Locale.ROOT);
        if (l.endsWith(".html")) return "text/html";
        if (l.endsWith(".js") || l.endsWith(".mjs")) return "text/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".woff2")) return "font/woff2";
        if (l.endsWith(".woff")) return "font/woff";
        if (l.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    // ───────── دورة حياة الشاشة ─────────
    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
        TextToSpeech t = tts;
        if (t != null) {
            try {
                t.stop();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        // لو المستخدم راح نزّل الصوت العربي ورجع، نجرب تاني
        if (ttsStatus == -1) {
            TextToSpeech old = tts;
            tts = null;
            if (old != null) {
                try {
                    old.shutdown();
                } catch (Exception ignored) {
                }
            }
            initTts();
        }
    }

    @Override
    protected void onDestroy() {
        if (billing != null) {
            billing.end();
            billing = null;
        }
        TextToSpeech t = tts;
        tts = null;
        if (t != null) {
            try {
                t.shutdown();
            } catch (Exception ignored) {
            }
        }
        if (web != null) {
            web.removeJavascriptInterface("ShillaNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    // ───────── أكواد خاصة بإصدارات أندرويد الجديدة (في كلاسات منفصلة) ─────────
    @android.annotation.TargetApi(30)
    static final class Api30 {
        static void edgeToEdge(Window w, View root) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance(0,
                        android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                                | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    android.graphics.Insets i = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                    return WindowInsets.CONSUMED;
                }
            });
        }
    }

    @android.annotation.TargetApi(33)
    static final class Api33 {
        static void registerBack(final MainActivity a) {
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new android.window.OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            a.handleBack();
                        }
                    });
        }
    }
}
